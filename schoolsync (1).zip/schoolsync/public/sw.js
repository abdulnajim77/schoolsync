// Minimal offline-fallback service worker for SchoolSync (PWA).
// Live GPS is never cached; this only provides an app-shell + offline page.
const CACHE = 'schoolsync-shell-v1';
const SHELL = ['/', '/index.html', '/offline.html', '/manifest.webmanifest', '/favicon.svg'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (e) => {
  const { request } = e;
  if (request.method !== 'GET') return;
  // Never cache Firebase / Maps / GPS traffic.
  if (/firebaseio|googleapis|gstatic|google\.com\/maps/.test(request.url)) return;
  if (request.mode === 'navigate') {
    e.respondWith(fetch(request).catch(() => caches.match('/offline.html')));
    return;
  }
  e.respondWith(caches.match(request).then((hit) => hit || fetch(request)));
});

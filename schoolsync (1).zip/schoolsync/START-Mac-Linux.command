#!/bin/bash
cd "$(dirname "$0")"

echo "========================================"
echo "  SchoolSync - starting local server"
echo "========================================"
echo

if ! command -v npm >/dev/null 2>&1; then
  echo "Node.js is not installed on this computer."
  echo "Please install it from https://nodejs.org  (pick the LTS version),"
  echo "then double-click this file again."
  echo
  read -p "Press Enter to close."
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "First-time setup: installing dependencies. This takes a minute..."
  echo
  npm install
fi

echo
echo "Opening http://localhost:5173 in your browser..."
( sleep 4; (open http://localhost:5173 2>/dev/null || xdg-open http://localhost:5173 2>/dev/null) ) &

echo "Keep this window OPEN while you use the app."
echo "To stop the app later, close this window or press Ctrl + C."
echo
npm run dev

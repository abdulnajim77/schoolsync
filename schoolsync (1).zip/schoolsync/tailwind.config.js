/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: '#253B80', 600: '#2c4694', 700: '#253B80', 800: '#1d2f66' },
        brand: {
          50: '#eff6ff', 100: '#dbeafe', 200: '#bfdbfe', 300: '#93c5fd',
          400: '#60a5fa', 500: '#3B82F6', 600: '#2563eb', 700: '#1d4ed8',
        },
        safe: { DEFAULT: '#22C55E', 50: '#f0fdf4', 100: '#dcfce7', 600: '#16a34a', 700: '#15803d' },
        warn: { DEFAULT: '#F59E0B', 50: '#fffbeb', 100: '#fef3c7', 600: '#d97706' },
        danger: { DEFAULT: '#EF4444', 50: '#fef2f2', 100: '#fee2e2', 600: '#dc2626' },
        ink: { DEFAULT: '#172033', soft: '#334155', muted: '#64748B' },
        canvas: '#F6F8FC',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        xl: '14px', '2xl': '18px', '3xl': '24px',
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(23,32,51,0.04), 0 4px 16px -4px rgba(23,32,51,0.08)',
        'card-hover': '0 2px 4px 0 rgba(23,32,51,0.06), 0 12px 28px -6px rgba(23,32,51,0.14)',
        pop: '0 8px 40px -8px rgba(37,59,128,0.28)',
      },
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'slide-up': { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        'pulse-ring': { '0%': { transform: 'scale(0.8)', opacity: '0.7' }, '80%,100%': { transform: 'scale(2.2)', opacity: '0' } },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
      },
      animation: {
        'fade-in': 'fade-in 0.25s ease-out',
        'slide-up': 'slide-up 0.3s cubic-bezier(0.16,1,0.3,1)',
        'pulse-ring': 'pulse-ring 1.8s cubic-bezier(0.24,0,0.38,1) infinite',
      },
    },
  },
  plugins: [],
};

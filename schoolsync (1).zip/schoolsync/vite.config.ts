import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

// https://vite.dev/config/
export default defineConfig({
  // Relative base so the build works both locally and under a GitHub Pages
  // subpath like https://user.github.io/schoolsync/.
  base: './',
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') },
  },
  server: { port: 5173, host: true },
  preview: { port: 4173, host: true },
});

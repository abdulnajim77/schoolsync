import { useMemo } from 'react';
import {
  Play, Square, Radio, MapPin, Check, CircleDot, RotateCcw,
} from 'lucide-react';
import type { Student } from '@/types';
import { Badge, Button, Card, StatusChip } from '@/components/ui';
import { cn } from '@/lib/cn';
import { greeting, metres } from '@/lib/format';
import { etaMinutes } from '@/lib/geo';
import { useAuth } from '@/state/AuthContext';
import { useTrip } from '@/state/TripContext';
import { DEMO_ROUTE } from '@/data/demoData';

export function DriverDashboard() {
  const { user } = useAuth();
  const { trip, students, startTrip, endTrip, board, drop, resetDemo, distanceToStudentStop } = useTrip();

  const running = trip.status !== 'NOT_STARTED' && trip.status !== 'COMPLETED';
  const counts = useMemo(() => {
    const onLeave = students.filter((s) => s.transportStatus === 'SCHOOL_LEAVE').length;
    const skip = students.filter((s) => s.transportStatus === 'TRANSPORT_SKIP').length;
    const expected = students.length - onLeave - skip;
    return { onLeave, skip, expected, total: students.length };
  }, [students]);

  const nextStop = DEMO_ROUTE.stops[Math.min(trip.nextStopIndex, DEMO_ROUTE.stops.length - 1)];

  // Group active students by stop name for the boarding list.
  const byStop = useMemo(() => {
    const map = new Map<string, Student[]>();
    for (const s of students) {
      const key = trip.tripType === 'morning' ? s.pickup.name : s.drop.name;
      map.set(key, [...(map.get(key) ?? []), s]);
    }
    return [...map.entries()];
  }, [students, trip.tripType]);

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm text-ink-muted">{greeting()},</p>
        <h1 className="text-2xl font-bold tracking-tight text-ink">{user?.name?.split(' ')[0]}</h1>
      </div>

      {/* Trip control */}
      <Card className={cn('p-5', running && 'ring-2 ring-safe/30')}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold text-ink">Bus 03 · WB-16A-1234</p>
            <p className="text-xs text-ink-muted">Route A · {counts.total} students</p>
          </div>
          {running
            ? <span className="flex items-center gap-1.5 rounded-full bg-safe-50 px-3 py-1 text-xs font-bold text-safe-700"><Radio className="h-3.5 w-3.5 animate-pulse" />GPS Active</span>
            : <StatusChip status={trip.status} />}
        </div>

        {running ? (
          <>
            <div className="mt-4 grid grid-cols-3 gap-2 rounded-2xl bg-canvas p-3 text-center">
              <Metric label="Next stop" value={nextStop.name} small />
              <Metric label="Distance" value={metres(distanceToStudentStop(students[0]?.id ?? ''))} />
              <Metric label="Speed" value={`${trip.speed} km/h`} />
            </div>
            <Button variant="danger" size="xl" block className="mt-4" icon={Square} onClick={endTrip}>End trip</Button>
          </>
        ) : (
          <div className="mt-4 space-y-2">
            <Button variant="safe" size="xl" block icon={Play} onClick={() => startTrip('morning')}>Start morning trip</Button>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" block icon={RotateCcw} onClick={() => startTrip('return')}>Return trip</Button>
              <Button variant="ghost" size="sm" block onClick={resetDemo}>Reset demo</Button>
            </div>
          </div>
        )}
      </Card>

      {/* Counts */}
      <div className="grid grid-cols-3 gap-3">
        <CountCard label="Expected" value={counts.expected} tone="text-safe-700" />
        <CountCard label="On leave" value={counts.onLeave} tone="text-warn-600" />
        <CountCard label="Skip bus" value={counts.skip} tone="text-danger-600" />
      </div>

      {/* Boarding list */}
      <div>
        <h3 className="mb-2 text-[15px] font-bold text-ink">
          {trip.tripType === 'morning' ? 'Boarding list' : 'Drop list'}
        </h3>
        <div className="space-y-3">
          {byStop.map(([stopName, list]) => (
            <Card key={stopName} className="overflow-hidden">
              <div className="flex items-center gap-2 border-b border-slate-50 bg-canvas px-4 py-2.5">
                <MapPin className="h-4 w-4 text-navy" />
                <p className="text-sm font-bold text-ink">{stopName}</p>
                <span className="ml-auto text-xs text-ink-muted">{list.length} student{list.length > 1 ? 's' : ''}</span>
              </div>
              <ul className="divide-y divide-slate-50">
                {list.map((s) => {
                  const unavailable = s.transportStatus === 'SCHOOL_LEAVE' || s.transportStatus === 'TRANSPORT_SKIP';
                  const boarded = s.transportStatus === 'BOARDED' || s.transportStatus === 'REACHED_SCHOOL';
                  const dropped = s.transportStatus === 'DROPPED';
                  const isMorning = trip.tripType === 'morning';
                  return (
                    <li key={s.id} className="flex items-center justify-between gap-3 px-4 py-3">
                      <div>
                        <p className="font-semibold text-ink">{s.firstName} {s.lastName}</p>
                        <p className="text-xs text-ink-muted">{s.className} · Roll {s.roll}</p>
                      </div>
                      {unavailable ? (
                        <Badge tone="orange" dot>{s.transportStatus === 'SCHOOL_LEAVE' ? 'On leave' : 'Skip bus'}</Badge>
                      ) : isMorning ? (
                        boarded
                          ? <Badge tone="green"><Check className="h-3.5 w-3.5" />Boarded</Badge>
                          : <Button variant="safe" size="sm" onClick={() => board(s.id)} disabled={!running}>Board</Button>
                      ) : (
                        dropped
                          ? <Badge tone="green"><Check className="h-3.5 w-3.5" />Dropped</Badge>
                          : <Button variant="safe" size="sm" onClick={() => drop(s.id)} disabled={!running}>Drop</Button>
                      )}
                    </li>
                  );
                })}
              </ul>
            </Card>
          ))}
        </div>
      </div>

      {running && (
        <p className="flex items-center justify-center gap-1.5 text-xs text-ink-muted">
          <CircleDot className="h-3.5 w-3.5 text-safe" />Location sharing active · ETA to next stop ~{etaMinutes(distanceToStudentStop(students[0]?.id ?? ''), trip.speed)} min
        </p>
      )}
    </div>
  );
}

function Metric({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div>
      <p className="text-[11px] uppercase tracking-wide text-ink-muted">{label}</p>
      <p className={cn('font-bold text-ink', small ? 'text-sm' : 'text-base')}>{value}</p>
    </div>
  );
}

function CountCard({ label, value, tone }: { label: string; value: number; tone: string }) {
  return (
    <Card className="p-3 text-center">
      <p className={cn('text-2xl font-bold', tone)}>{value}</p>
      <p className="text-[11px] text-ink-muted">{label}</p>
    </Card>
  );
}

import { Route as RouteIcon, Navigation, Users, MapPin } from 'lucide-react';
import type { MapMarker } from '@/components/transport/LiveMap';
import { LiveMap } from '@/components/transport/LiveMap';
import { Button, Card, PageHeader } from '@/components/ui';
import { cn } from '@/lib/cn';
import { useTrip } from '@/state/TripContext';
import { DEMO_ROUTE, DEMO_SCHOOL } from '@/data/demoData';

export function DriverRoute() {
  const { trip, students } = useTrip();
  const running = trip.status !== 'NOT_STARTED' && trip.status !== 'COMPLETED';

  const countAt = (stopName: string) =>
    students.filter((s) => s.pickup.name === stopName && s.transportStatus !== 'SCHOOL_LEAVE' && s.transportStatus !== 'TRANSPORT_SKIP').length;

  const markers: MapMarker[] = [
    { id: 'bus', pos: { lat: trip.currentLatitude, lng: trip.currentLongitude }, kind: 'bus', label: 'You' },
    { id: 'school', pos: DEMO_SCHOOL.location, kind: 'school', label: 'School' },
  ];

  const navTo = (lat: number, lng: number) =>
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');

  return (
    <div className="space-y-4">
      <PageHeader title="Route A" subtitle="Stops and student counts" icon={RouteIcon} />

      <Card className="overflow-hidden">
        <LiveMap markers={markers} route={DEMO_ROUTE.stops.map((s) => ({ lat: s.lat, lng: s.lng }))}
          heading={trip.heading} className="h-56 w-full" />
      </Card>

      <div className="space-y-3">
        {DEMO_ROUTE.stops.map((s, i) => {
          const isSchool = s.id === 'stop_school';
          const here = running && i === trip.nextStopIndex;
          const count = isSchool ? students.filter((x) => x.transportStatus === 'BOARDED').length : countAt(s.name);
          return (
            <Card key={s.id} className={cn('flex items-center gap-3 p-4', here && 'ring-2 ring-brand-200')}>
              <span className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl font-bold',
                here ? 'bg-brand-500 text-white' : isSchool ? 'bg-navy text-white' : 'bg-navy/10 text-navy')}>
                {isSchool ? <MapPin className="h-5 w-5" /> : i}
              </span>
              <div className="flex-1">
                <p className="font-semibold text-ink">{s.name}</p>
                <p className="flex items-center gap-1 text-xs text-ink-muted">
                  <Users className="h-3.5 w-3.5" />{count} {isSchool ? 'onboard' : 'students'} · {s.expectedTime}
                </p>
              </div>
              {!isSchool && (
                <Button variant="outline" size="sm" icon={Navigation} onClick={() => navTo(s.lat, s.lng)}>Navigate</Button>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}

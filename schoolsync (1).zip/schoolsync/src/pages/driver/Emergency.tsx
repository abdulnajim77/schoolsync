import { useState } from 'react';
import {
  TriangleAlert, Wrench, Clock, Car, HeartPulse, Ban, CircleHelp, CheckCircle2,
} from 'lucide-react';
import { Button, Card, PageHeader } from '@/components/ui';
import { Modal } from '@/components/ui/Overlay';
import { cn } from '@/lib/cn';
import { useNotifications } from '@/state/NotificationContext';

const kinds = [
  { key: 'breakdown', label: 'Vehicle Breakdown', icon: Wrench },
  { key: 'traffic', label: 'Traffic Delay', icon: Clock },
  { key: 'accident', label: 'Accident', icon: Car },
  { key: 'medical', label: 'Medical Emergency', icon: HeartPulse },
  { key: 'blocked', label: 'Route Blocked', icon: Ban },
  { key: 'other', label: 'Other', icon: CircleHelp },
];

export function DriverEmergency() {
  const { push } = useNotifications();
  const [selected, setSelected] = useState<typeof kinds[number] | null>(null);
  const [sent, setSent] = useState(false);

  const report = () => {
    if (!selected) return;
    push({
      category: 'Emergency', priority: 'EMERGENCY',
      title: `Bus 03 · ${selected.label}`,
      body: `Bus 03 reported "${selected.label}" near Serampore. Students are safe. The school administration has been notified.`,
    });
    setSelected(null);
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Report Emergency" subtitle="Alert the school and affected parents instantly" icon={TriangleAlert} />

      <Card className="border-danger-100 bg-danger-50/40 p-4">
        <p className="flex items-center gap-2 text-sm font-semibold text-danger-600">
          <TriangleAlert className="h-4 w-4" />Use only for genuine situations
        </p>
        <p className="mt-1 text-sm text-ink-soft">
          Reporting sends a high-priority alert to the admin and to parents of students currently onboard.
        </p>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        {kinds.map((k) => (
          <button
            key={k.key}
            onClick={() => setSelected(k)}
            className="flex flex-col items-center gap-2 rounded-2xl border border-slate-100 bg-white p-5 text-center shadow-card transition hover:border-danger-100 hover:shadow-card-hover"
          >
            <span className="grid h-12 w-12 place-items-center rounded-2xl bg-danger-50 text-danger-600"><k.icon className="h-6 w-6" /></span>
            <span className="text-sm font-semibold text-ink">{k.label}</span>
          </button>
        ))}
      </div>

      {sent && (
        <div className="flex items-center gap-2 rounded-2xl bg-safe-50 px-4 py-3 text-sm font-semibold text-safe-700">
          <CheckCircle2 className="h-5 w-5" />Alert sent to the school and parents.
        </div>
      )}

      <Modal
        open={!!selected} onClose={() => setSelected(null)} title="Confirm emergency report" size="sm"
        footer={<><Button variant="ghost" onClick={() => setSelected(null)}>Cancel</Button>
          <Button variant="danger" onClick={report}>Send alert</Button></>}
      >
        {selected && (
          <div className="text-center">
            <span className={cn('mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-danger-50 text-danger-600')}>
              <selected.icon className="h-7 w-7" />
            </span>
            <p className="mt-3 font-bold text-ink">{selected.label}</p>
            <p className="mt-1 text-sm text-ink-muted">
              This will immediately notify the school administration and affected parents. Continue?
            </p>
          </div>
        )}
      </Modal>
    </div>
  );
}

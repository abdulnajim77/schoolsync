import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bus, Mail, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { Button, Input } from '@/components/ui';

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  return (
    <div className="grid min-h-dvh place-items-center bg-canvas px-5">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-navy text-white"><Bus className="h-5 w-5" /></span>
          <span className="text-lg font-bold text-ink">SchoolSync</span>
        </div>

        {sent ? (
          <div className="rounded-2xl border border-slate-100 bg-white p-6 text-center shadow-card">
            <span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-safe-50 text-safe-700"><CheckCircle2 className="h-6 w-6" /></span>
            <h2 className="mt-3 text-lg font-bold text-ink">Check your inbox</h2>
            <p className="mt-1 text-sm text-ink-muted">
              If an account exists for <span className="font-semibold text-ink">{email || 'that address'}</span>,
              a reset link is on its way.
            </p>
            <Link to="/login"><Button variant="outline" block className="mt-5" icon={ArrowLeft}>Back to sign in</Button></Link>
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-card">
            <h2 className="text-xl font-bold text-ink">Reset your password</h2>
            <p className="mt-1 text-sm text-ink-muted">Enter your email and we'll send a reset link.</p>
            <div className="mt-5">
              <Input label="Email" icon={Mail} type="email" value={email}
                onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <Button block size="lg" className="mt-5" onClick={() => setSent(true)}>Send reset link</Button>
            <Link to="/login" className="mt-4 flex items-center justify-center gap-1.5 text-sm font-semibold text-brand-600 hover:underline">
              <ArrowLeft className="h-4 w-4" />Back to sign in
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Bus, Mail, Lock, ShieldCheck, MapPin, Bell, Users, GraduationCap, Truck, ArrowRight,
} from 'lucide-react';
import type { Role } from '@/types';
import { cn } from '@/lib/cn';
import { Button, Input } from '@/components/ui';
import { homeForRole, useAuth } from '@/state/AuthContext';
import { IS_DEMO } from '@/config/env';

const roles: { key: Role; label: string; icon: typeof Users; email: string }[] = [
  { key: 'parent', label: 'Parent', icon: Users, email: 'parent@demo.com' },
  { key: 'admin', label: 'School Admin', icon: GraduationCap, email: 'admin@demo.com' },
  { key: 'driver', label: 'Driver', icon: Truck, email: 'driver@demo.com' },
  { key: 'teacher', label: 'Teacher', icon: ShieldCheck, email: 'teacher@demo.com' },
];

const highlights = [
  { icon: MapPin, text: 'Live school bus tracking with real geofencing' },
  { icon: Bell, text: 'Instant boarding, arrival & drop notifications' },
  { icon: ShieldCheck, text: 'Verified pickup and safe-drop confirmation' },
];

export function Login() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState<Role>('parent');
  const [email, setEmail] = useState('parent@demo.com');
  const [password, setPassword] = useState('demo123');
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const pickRole = (r: Role, mail: string) => {
    setRole(r);
    if (IS_DEMO) { setEmail(mail); setPassword('demo123'); }
    setError('');
  };

  const submit = async () => {
    setBusy(true); setError('');
    try {
      const user = await signIn({ email, password, role });
      navigate(homeForRole(user.role), { replace: true });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Sign in failed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      {/* Brand side */}
      <div className="relative hidden overflow-hidden bg-navy p-10 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute -left-16 -top-16 h-72 w-72 rounded-full bg-brand-500 blur-3xl" />
          <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-safe blur-3xl" />
        </div>
        <div className="relative flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15"><Bus className="h-6 w-6" /></span>
          <span className="text-xl font-bold">SchoolSync</span>
        </div>

        <div className="relative max-w-md">
          <h1 className="text-4xl font-bold leading-tight tracking-tight">
            Safer Journeys.<br />Better School Communication.
          </h1>
          <p className="mt-4 text-white/70">
            Track school transport, stay connected with your school and manage your child's
            daily academic activities from one secure platform.
          </p>
          <ul className="mt-8 space-y-3">
            {highlights.map((h) => (
              <li key={h.text} className="flex items-center gap-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/10"><h.icon className="h-4.5 w-4.5" /></span>
                <span className="text-sm text-white/85">{h.text}</span>
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-sm text-white/50">Secure access powered by SchoolSync</p>
      </div>

      {/* Form side */}
      <div className="flex items-center justify-center bg-canvas px-5 py-10">
        <div className="w-full max-w-sm">
          <div className="mb-6 flex items-center gap-2.5 lg:hidden">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-navy text-white"><Bus className="h-5 w-5" /></span>
            <span className="text-lg font-bold text-ink">SchoolSync</span>
          </div>

          <h2 className="text-2xl font-bold text-ink">Welcome back</h2>
          <p className="mt-1 text-sm text-ink-muted">Sign in to continue to your dashboard.</p>

          <div className="mt-6 grid grid-cols-2 gap-2">
            {roles.map((r) => (
              <button
                key={r.key}
                onClick={() => pickRole(r.key, r.email)}
                className={cn(
                  'flex items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-semibold transition',
                  role === r.key ? 'border-navy bg-navy/5 text-navy' : 'border-slate-200 bg-white text-ink-soft hover:border-slate-300',
                )}
              >
                <r.icon className="h-4 w-4" />{r.label}
              </button>
            ))}
          </div>

          <div className="mt-4 space-y-3">
            <Input label="Email / Phone" icon={Mail} type="email" value={email}
              onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            <Input label="Password" icon={Lock} type="password" value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()} placeholder="••••••••" />
          </div>

          <div className="mt-3 flex items-center justify-between text-sm">
            <label className="flex items-center gap-2 text-ink-soft">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-navy focus:ring-navy" />
              Remember me
            </label>
            <Link to="/forgot" className="font-semibold text-brand-600 hover:underline">Forgot password?</Link>
          </div>

          {error && <p className="mt-3 rounded-xl bg-danger-50 px-3 py-2 text-sm font-medium text-danger-600">{error}</p>}

          <Button block size="lg" className="mt-5" loading={busy} iconRight={ArrowRight} onClick={submit}>
            Sign in
          </Button>

          {IS_DEMO && (
            <div className="mt-5 rounded-xl border border-dashed border-slate-200 bg-white/60 p-3 text-xs text-ink-muted">
              <p className="font-semibold text-ink-soft">Demo mode · password <span className="text-navy">demo123</span></p>
              <p className="mt-1">Pick a role above to auto-fill. All four accounts are ready to explore.</p>
            </div>
          )}

          <p className="mt-6 text-center text-xs text-ink-muted lg:hidden">Secure access powered by SchoolSync</p>
        </div>
      </div>
    </div>
  );
}

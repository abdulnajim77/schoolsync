import { useState } from 'react';
import { CalendarOff, Bus, Send, CheckCircle2 } from 'lucide-react';
import type { LeaveRequest } from '@/types';
import { Badge, Button, Card, Input, PageHeader, StatusChip } from '@/components/ui';
import { shortDate } from '@/lib/format';
import { uid } from '@/lib/id';
import { demoDb } from '@/data/demoDb';
import { DEMO_SCHOOL } from '@/data/demoData';
import { useParent } from '@/state/ParentContext';
import { useNotifications } from '@/state/NotificationContext';

export function Leave() {
  const { child } = useParent();
  const { push } = useNotifications();
  const [leaves, setLeaves] = useState<LeaveRequest[]>(() => demoDb.getLeave());
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [reason, setReason] = useState('');
  const [skipped, setSkipped] = useState(child ? child.transportStatus === 'TRANSPORT_SKIP' : false);

  if (!child) return null;
  const cutoff = DEMO_SCHOOL.settings.transportSkipCutoff;

  const submitLeave = () => {
    if (!from || !reason.trim()) return;
    const req: LeaveRequest = {
      id: uid('lv'), studentId: child.id, parentUids: child.parentUids,
      fromDate: from, toDate: to || from, reason: reason.trim(),
      status: 'pending', createdAt: Date.now(),
    };
    setLeaves(demoDb.addLeave(req));
    setFrom(''); setTo(''); setReason('');
    push({ category: 'Academic', priority: 'INFO', title: 'Leave request submitted',
      body: `Leave for ${child.firstName} sent for approval.` });
  };

  const skipBus = () => {
    demoDb.updateStudent(child.id, { transportStatus: 'TRANSPORT_SKIP' });
    setSkipped(true);
    push({ category: 'Transport', priority: 'IMPORTANT', title: 'Bus skipped today',
      body: `Bus pickup has been skipped for ${child.firstName} today.` });
  };

  const myLeaves = leaves.filter((l) => l.studentId === child.id);

  return (
    <div className="space-y-5">
      <PageHeader title="Leave & Transport" subtitle="Apply for leave or skip the bus" icon={CalendarOff} />

      {/* Transport skip */}
      <Card className="p-4">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-warn-50 text-warn-600"><Bus className="h-5 w-5" /></span>
          <div className="flex-1">
            <p className="font-semibold text-ink">Not taking the school bus today</p>
            <p className="mt-0.5 text-sm text-ink-muted">
              {child.firstName} will attend school but you'll drop personally. Submit before {cutoff} AM.
              The driver is told automatically — no phone call needed.
            </p>
            {skipped ? (
              <div className="mt-3 flex items-center gap-2 rounded-xl bg-safe-50 px-3 py-2 text-sm font-semibold text-safe-700">
                <CheckCircle2 className="h-4 w-4" />Bus pickup skipped for today
              </div>
            ) : (
              <Button variant="primary" size="sm" className="mt-3" onClick={skipBus}>Skip bus today</Button>
            )}
          </div>
        </div>
      </Card>

      {/* Leave form */}
      <Card className="p-4">
        <h3 className="mb-3 text-[15px] font-bold text-ink">Apply for leave</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Input label="From date" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          <Input label="To date" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        <div className="mt-3">
          <label className="block">
            <span className="mb-1.5 block text-sm font-medium text-ink-soft">Reason</span>
            <textarea
              value={reason} onChange={(e) => setReason(e.target.value)} rows={3}
              placeholder="e.g. Family function, not keeping well…"
              className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-ink outline-none transition focus:border-brand-400 focus:ring-2 focus:ring-brand-100"
            />
          </label>
        </div>
        <p className="mt-2 text-xs text-ink-muted">
          On approval the student is marked <span className="font-semibold">On Leave</span> and removed from the driver's pickup list.
        </p>
        <Button variant="primary" className="mt-3" icon={Send} onClick={submitLeave} disabled={!from || !reason.trim()}>
          Submit request
        </Button>
      </Card>

      {/* History */}
      <div>
        <h3 className="mb-3 text-[15px] font-bold text-ink">Your requests</h3>
        {myLeaves.length === 0 ? (
          <p className="rounded-2xl border border-dashed border-slate-200 bg-white/60 px-4 py-8 text-center text-sm text-ink-muted">No leave requests yet.</p>
        ) : (
          <div className="space-y-3">
            {myLeaves.map((l) => (
              <Card key={l.id} className="flex items-center justify-between gap-3 p-4">
                <div>
                  <p className="font-semibold text-ink">{shortDate(l.fromDate)}{l.toDate !== l.fromDate && ` – ${shortDate(l.toDate)}`}</p>
                  <p className="text-sm text-ink-soft">{l.reason}</p>
                </div>
                <div className="text-right">
                  <StatusChip status={l.status} />
                  {l.status === 'approved' && <p className="mt-1"><Badge tone="orange" dot>Bus skipped</Badge></p>}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import {
  Phone, RefreshCw, TriangleAlert, Play, Square, Bus, ShieldCheck,
  MapPin, School, Flag,
} from 'lucide-react';
import type { MapMarker } from '@/components/transport/LiveMap';
import type { SafetyStep } from '@/components/transport/Timelines';
import { LiveMap } from '@/components/transport/LiveMap';
import { SafetyTimeline, TripTimeline } from '@/components/transport/Timelines';
import { Badge, Button, Card, PageHeader, StatusChip } from '@/components/ui';
import { clockTimeSec, metres } from '@/lib/format';
import { etaClock, etaMinutes } from '@/lib/geo';
import { useParent } from '@/state/ParentContext';
import { useTrip } from '@/state/TripContext';
import { DEMO_DRIVERS, DEMO_ROUTE, DEMO_SCHOOL } from '@/data/demoData';

export function LiveTracking() {
  const { child } = useParent();
  const { trip, events, students, startTrip, endTrip, distanceToStudentStop } = useTrip();
  if (!child) return null;

  const driver = DEMO_DRIVERS[0];
  const running = trip.status !== 'NOT_STARTED' && trip.status !== 'COMPLETED';
  const dist = distanceToStudentStop(child.id);
  const zone = trip.tripType === 'morning' ? child.pickup : child.drop;
  const me = students.find((s) => s.id === child.id);
  const call = () => { window.location.href = `tel:${driver.phone.replace(/\s/g, '')}`; };

  const markers: MapMarker[] = [
    { id: 'bus', pos: { lat: trip.currentLatitude, lng: trip.currentLongitude }, kind: 'bus', label: 'Bus 03' },
    { id: 'school', pos: DEMO_SCHOOL.location, kind: 'school', label: 'School' },
    { id: 'stop', pos: { lat: zone.lat, lng: zone.lng }, kind: trip.tripType === 'morning' ? 'pickup' : 'drop', label: zone.name, active: true },
  ];

  const boarded = me?.transportStatus === 'BOARDED' || me?.transportStatus === 'REACHED_SCHOOL' || me?.transportStatus === 'DROPPED';
  const reached = me?.transportStatus === 'REACHED_SCHOOL' || me?.transportStatus === 'DROPPED';
  const steps: SafetyStep[] = [
    { label: 'Trip started', icon: Flag, state: running || reached ? 'done' : 'todo' },
    { label: `Bus approaching ${zone.name}`, icon: MapPin, state: dist < 500 && running ? (dist < zone.radius ? 'done' : 'active') : boarded ? 'done' : 'todo' },
    { label: `${child.firstName} boarded`, icon: Bus, state: boarded ? 'done' : 'todo' },
    { label: trip.tripType === 'morning' ? 'Reached school safely' : 'Dropped safely', icon: reached ? ShieldCheck : School, state: reached ? 'done' : 'todo' },
  ];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Live Bus Tracking"
        subtitle={`${child.firstName}'s bus · ${trip.tripType === 'morning' ? 'Morning pickup' : 'Afternoon drop'}`}
        action={running
          ? <Button variant="danger" size="sm" icon={Square} onClick={endTrip}>End</Button>
          : <Button variant="primary" size="sm" icon={Play} onClick={() => startTrip('morning')}>Start demo</Button>}
      />

      <Card className="overflow-hidden">
        <LiveMap markers={markers} route={DEMO_ROUTE.stops.map((s) => ({ lat: s.lat, lng: s.lng }))}
          heading={trip.heading} className="h-72 w-full sm:h-96" />
      </Card>

      {/* Floating info */}
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-navy text-white"><Bus className="h-5 w-5" /></span>
            <div>
              <p className="text-sm font-bold text-ink">Bus 03 · {driver.name}</p>
              <p className="text-xs text-ink-muted">WB-16A-1234</p>
            </div>
          </div>
          {running ? <StatusChip status={trip.status} /> : <Badge tone="slate" dot>Idle</Badge>}
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Info label="Distance to stop" value={running ? metres(dist) : '—'} />
          <Info label="ETA" value={running ? `${etaMinutes(dist, trip.speed)} min` : '—'} />
          <Info label="Speed" value={running ? `${trip.speed} km/h` : '0 km/h'} />
          <Info label="Arrival" value={running ? etaClock(dist, trip.speed) : '—'} />
        </div>
        <p className="mt-3 text-xs text-ink-muted">Last updated {clockTimeSec(trip.lastUpdated)}</p>

        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="outline" size="sm" icon={RefreshCw} onClick={() => startTrip(trip.tripType)}>Refresh</Button>
          <Button variant="primary" size="sm" icon={Phone} onClick={call}>Call driver</Button>
          <Button variant="danger" size="sm" icon={TriangleAlert} onClick={() => window.location.href = `tel:${DEMO_SCHOOL.phone.replace(/\s/g, '')}`}>Emergency</Button>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-4">
          <h3 className="mb-3 text-[15px] font-bold text-ink">Safety timeline</h3>
          <SafetyTimeline steps={steps} />
        </Card>
        <Card className="p-4">
          <h3 className="mb-3 text-[15px] font-bold text-ink">Trip activity</h3>
          <TripTimeline events={events} />
        </Card>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-canvas px-3 py-2.5">
      <p className="text-[11px] uppercase tracking-wide text-ink-muted">{label}</p>
      <p className="text-base font-bold text-ink">{value}</p>
    </div>
  );
}

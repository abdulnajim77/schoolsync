import { useState } from 'react';
import { BookOpen, Check, Paperclip } from 'lucide-react';
import type { Homework as HW } from '@/types';
import { Badge, Card, EmptyState, PageHeader } from '@/components/ui';
import { Tabs } from '@/components/ui/Overlay';
import { cn } from '@/lib/cn';
import { shortDate } from '@/lib/format';
import { DEMO_HOMEWORK } from '@/data/demoData';

type Filter = 'all' | 'pending' | 'done';
const subjectHue: Record<string, string> = {
  English: 'bg-brand-50 text-brand-600', Mathematics: 'bg-navy/10 text-navy',
  EVS: 'bg-safe-50 text-safe-700', Bengali: 'bg-warn-50 text-warn-600',
};

export function Homework() {
  const [items, setItems] = useState<HW[]>(DEMO_HOMEWORK);
  const [filter, setFilter] = useState<Filter>('all');
  const shown = items.filter((h) => filter === 'all' || (filter === 'done' ? h.completed : !h.completed));
  const toggle = (id: string) => setItems((p) => p.map((h) => h.id === id ? { ...h, completed: !h.completed } : h));

  return (
    <div className="space-y-4">
      <PageHeader title="Homework" subtitle="Assignments for Riya" icon={BookOpen} />
      <Tabs<Filter>
        value={filter} onChange={setFilter}
        tabs={[
          { key: 'all', label: 'All', count: items.length },
          { key: 'pending', label: 'Pending', count: items.filter((h) => !h.completed).length },
          { key: 'done', label: 'Completed', count: items.filter((h) => h.completed).length },
        ]}
      />
      {shown.length === 0 ? (
        <EmptyState icon={BookOpen} title="Nothing here" hint="No homework in this filter." />
      ) : (
        <div className="space-y-3">
          {shown.map((h) => (
            <Card key={h.id} className="flex items-start gap-3 p-4">
              <span className={cn('grid h-10 w-10 shrink-0 place-items-center rounded-xl text-xs font-bold', subjectHue[h.subject] ?? 'bg-slate-100 text-slate-500')}>
                {h.subject.slice(0, 3).toUpperCase()}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className={cn('font-semibold text-ink', h.completed && 'line-through opacity-60')}>{h.title}</p>
                  {h.completed && <Badge tone="green">Done</Badge>}
                </div>
                <p className="mt-0.5 text-sm text-ink-soft">{h.detail}</p>
                <p className="mt-1.5 text-xs text-ink-muted">{h.subject} · Due {shortDate(h.due)}</p>
              </div>
              <button
                onClick={() => toggle(h.id)}
                className={cn('grid h-8 w-8 shrink-0 place-items-center rounded-lg border transition',
                  h.completed ? 'border-safe bg-safe text-white' : 'border-slate-200 text-slate-300 hover:border-safe')}
                aria-label="Toggle complete"
              >
                <Check className="h-4 w-4" />
              </button>
            </Card>
          ))}
        </div>
      )}
      <p className="flex items-center gap-1.5 text-xs text-ink-muted"><Paperclip className="h-3.5 w-3.5" />Attachments open in production mode.</p>
    </div>
  );
}

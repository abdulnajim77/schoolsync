import { Images, Camera } from 'lucide-react';
import { Badge, Card, PageHeader } from '@/components/ui';
import { shortDate } from '@/lib/format';
import { DEMO_ACTIVITIES } from '@/data/demoData';

export function Activities() {
  return (
    <div className="space-y-4">
      <PageHeader title="School Activities" subtitle="Moments from campus life" icon={Images} />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {DEMO_ACTIVITIES.map((a) => (
          <Card key={a.id} interactive className="overflow-hidden">
            <div className="relative grid h-28 place-items-center" style={{ background: `linear-gradient(135deg, ${a.hue}, ${a.hue}cc)` }}>
              <Camera className="h-8 w-8 text-white/80" />
              <span className="absolute left-2 top-2"><Badge tone="slate" className="bg-white/85">{a.category}</Badge></span>
            </div>
            <div className="p-3">
              <p className="text-sm font-semibold text-ink">{a.title}</p>
              <p className="text-xs text-ink-muted">{shortDate(a.date)}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

import { useNavigate } from 'react-router-dom';
import {
  Bus, IndianRupee, CalendarCheck, BookOpen, CalendarClock, Megaphone,
  CalendarOff, FileText, Images, Phone, IdCard, Play,
} from 'lucide-react';
import { Badge, Button, Card } from '@/components/ui';
import { BusStatusCard } from '@/components/transport/BusStatusCard';
import { greeting } from '@/lib/format';
import { useAuth } from '@/state/AuthContext';
import { useParent } from '@/state/ParentContext';
import { useTrip } from '@/state/TripContext';
import { DEMO_DRIVERS } from '@/data/demoData';

const actions = [
  { to: '/parent/track', label: 'Track Bus', icon: Bus, tone: 'bg-brand-50 text-brand-600' },
  { to: '/parent/fees', label: 'Fees', icon: IndianRupee, tone: 'bg-warn-50 text-warn-600' },
  { to: '/parent/attendance', label: 'Attendance', icon: CalendarCheck, tone: 'bg-safe-50 text-safe-700' },
  { to: '/parent/homework', label: 'Homework', icon: BookOpen, tone: 'bg-navy/10 text-navy' },
  { to: '/parent/exams', label: 'Exam Routine', icon: CalendarClock, tone: 'bg-brand-50 text-brand-600' },
  { to: '/parent/notices', label: 'School Notice', icon: Megaphone, tone: 'bg-danger-50 text-danger-600' },
  { to: '/parent/leave', label: 'Leave Request', icon: CalendarOff, tone: 'bg-warn-50 text-warn-600' },
  { to: '/parent/report', label: 'Report Card', icon: FileText, tone: 'bg-safe-50 text-safe-700' },
  { to: '/parent/activities', label: 'Activities', icon: Images, tone: 'bg-navy/10 text-navy' },
];

export function ParentDashboard() {
  const { user } = useAuth();
  const { child } = useParent();
  const { trip, startTrip } = useTrip();
  const navigate = useNavigate();

  if (!child) return null;
  const driver = DEMO_DRIVERS[0];
  const running = trip.status !== 'NOT_STARTED' && trip.status !== 'COMPLETED';

  const call = () => { window.location.href = `tel:${driver.phone.replace(/\s/g, '')}`; };

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-sm text-ink-muted">{greeting()},</p>
          <h1 className="text-2xl font-bold tracking-tight text-ink">{user?.name}</h1>
        </div>
        {!running && (
          <Button size="sm" variant="outline" icon={Play} onClick={() => startTrip('morning')}>
            Play live demo
          </Button>
        )}
      </div>

      {/* Student profile */}
      <Card className="p-4">
        <div className="flex items-center gap-4">
          <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-navy to-brand-500 text-xl font-bold text-white">
            {child.firstName[0]}{child.lastName[0]}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h2 className="truncate text-lg font-bold text-ink">{child.firstName} {child.lastName}</h2>
              <Badge tone="navy">{child.className}</Badge>
            </div>
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-ink-muted">
              <span>Section {child.section}</span>
              <span>Roll {child.roll}</span>
              <span className="flex items-center gap-1"><IdCard className="h-3.5 w-3.5" />STU-2026-{String(child.roll).padStart(4, '0')}</span>
            </div>
          </div>
          <Button variant="ghost" size="sm" icon={Phone} onClick={call} className="hidden sm:inline-flex">Contact school</Button>
        </div>
      </Card>

      {/* Live bus hero */}
      <BusStatusCard student={child} onTrack={() => navigate('/parent/track')} onCall={call} />

      {/* Quick actions */}
      <div>
        <h3 className="mb-3 text-[15px] font-bold text-ink">Quick actions</h3>
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {actions.map((a) => (
            <button
              key={a.to}
              onClick={() => navigate(a.to)}
              className="flex flex-col items-center gap-2 rounded-2xl border border-slate-100 bg-white p-3.5 text-center shadow-card transition hover:shadow-card-hover"
            >
              <span className={`grid h-11 w-11 place-items-center rounded-xl ${a.tone}`}><a.icon className="h-5 w-5" /></span>
              <span className="text-xs font-semibold text-ink">{a.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

import { useMemo } from 'react';
import { CalendarCheck } from 'lucide-react';
import type { AttendanceMark } from '@/types';
import { Card, PageHeader, ProgressRing } from '@/components/ui';
import { cn } from '@/lib/cn';
import { buildAttendance } from '@/data/demoData';

const markStyle: Record<AttendanceMark, string> = {
  present: 'bg-safe-50 text-safe-700',
  absent: 'bg-danger-50 text-danger-600',
  leave: 'bg-warn-50 text-warn-600',
  holiday: 'bg-slate-100 text-slate-400',
};
const legend: { mark: AttendanceMark; label: string }[] = [
  { mark: 'present', label: 'Present' }, { mark: 'absent', label: 'Absent' },
  { mark: 'leave', label: 'Leave' }, { mark: 'holiday', label: 'Holiday' },
];

export function Attendance() {
  const days = useMemo(() => buildAttendance(), []);
  const present = days.filter((d) => d.mark === 'present').length;
  const absent = days.filter((d) => d.mark === 'absent').length;
  const leave = days.filter((d) => d.mark === 'leave').length;
  const working = present + absent + leave;
  const pct = working ? Math.round((present / working) * 100) : 0;
  const firstDow = new Date(days[0].date).getDay();

  return (
    <div className="space-y-5">
      <PageHeader title="Attendance" subtitle="September 2026" icon={CalendarCheck} />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="flex flex-col items-center justify-center p-5">
          <ProgressRing value={pct} sub="attendance" />
          <div className="mt-4 grid w-full grid-cols-3 gap-2 text-center">
            <Stat label="Present" value={present} tone="text-safe-700" />
            <Stat label="Absent" value={absent} tone="text-danger-600" />
            <Stat label="Leave" value={leave} tone="text-warn-600" />
          </div>
        </Card>

        <Card className="p-5 lg:col-span-2">
          <div className="mb-3 grid grid-cols-7 gap-1.5 text-center text-[11px] font-semibold text-ink-muted">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => <span key={d}>{d}</span>)}
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {Array.from({ length: firstDow }).map((_, i) => <span key={`pad-${i}`} />)}
            {days.map((d) => {
              const day = new Date(d.date).getDate();
              return (
                <div key={d.date} className={cn('grid aspect-square place-items-center rounded-xl text-sm font-semibold', markStyle[d.mark])}>
                  {day}
                </div>
              );
            })}
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            {legend.map((l) => (
              <span key={l.mark} className="flex items-center gap-1.5 text-xs text-ink-soft">
                <span className={cn('h-3 w-3 rounded', markStyle[l.mark])} />{l.label}
              </span>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone: string }) {
  return (
    <div>
      <p className={`text-xl font-bold ${tone}`}>{value}</p>
      <p className="text-[11px] text-ink-muted">{label}</p>
    </div>
  );
}

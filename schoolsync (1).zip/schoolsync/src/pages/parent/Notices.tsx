import { Megaphone, Paperclip } from 'lucide-react';
import type { NotificationPriority } from '@/types';
import { Badge, Card, PageHeader } from '@/components/ui';
import { shortDate } from '@/lib/format';
import { DEMO_NOTICES } from '@/data/demoData';

const tone = (p: NotificationPriority) =>
  p === 'EMERGENCY' ? 'red' : p === 'SAFETY' ? 'green' : p === 'IMPORTANT' ? 'orange' : 'blue';

export function Notices() {
  return (
    <div className="space-y-4">
      <PageHeader title="School Notices" subtitle="Announcements from the school" icon={Megaphone} />
      <div className="space-y-3">
        {DEMO_NOTICES.map((n) => (
          <Card key={n.id} className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy/10 text-navy"><Megaphone className="h-4.5 w-4.5" /></span>
                <div>
                  <p className="font-semibold text-ink">{n.title}</p>
                  <p className="text-xs text-ink-muted">{shortDate(n.date)}</p>
                </div>
              </div>
              <Badge tone={tone(n.priority)}>{n.priority === 'INFO' ? 'Notice' : n.priority}</Badge>
            </div>
            <p className="mt-2.5 text-sm text-ink-soft">{n.body}</p>
            {n.attachment && (
              <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-brand-600"><Paperclip className="h-3.5 w-3.5" />Attachment</p>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}

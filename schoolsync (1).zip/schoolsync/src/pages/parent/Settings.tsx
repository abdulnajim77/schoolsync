import { useNavigate } from 'react-router-dom';
import { User, Bell, Lock, ShieldAlert, LogOut, Phone, Mail } from 'lucide-react';
import type { PrefKey } from '@/state/NotificationContext';
import { Avatar, Badge, Button, Card, Input, PageHeader } from '@/components/ui';
import { cn } from '@/lib/cn';
import { useAuth } from '@/state/AuthContext';
import { useNotifications } from '@/state/NotificationContext';

const prefRows: { key: PrefKey; label: string }[] = [
  { key: 'busApproachingPickup', label: 'Bus approaching pickup' },
  { key: 'busArrived', label: 'Bus arrived nearby' },
  { key: 'studentBoarded', label: 'Student boarded' },
  { key: 'reachedSchool', label: 'Reached school' },
  { key: 'returnStarted', label: 'Return trip started' },
  { key: 'busApproachingDrop', label: 'Bus approaching drop' },
  { key: 'studentDropped', label: 'Student dropped' },
  { key: 'schoolNotice', label: 'School notices' },
  { key: 'feeReminder', label: 'Fee reminders' },
  { key: 'homework', label: 'Homework updates' },
];

export function ParentSettings() {
  const { user, signOut } = useAuth();
  const { prefs, setPref } = useNotifications();
  const navigate = useNavigate();
  const logout = async () => { await signOut(); navigate('/login'); };

  return (
    <div className="space-y-5">
      <PageHeader title="Settings" subtitle="Manage your profile and alerts" icon={User} />

      <Card className="p-4">
        <div className="flex items-center gap-3">
          <Avatar name={user?.name ?? 'Parent'} size={52} />
          <div className="flex-1">
            <p className="font-bold text-ink">{user?.name}</p>
            <div className="mt-0.5 flex flex-wrap gap-x-3 text-xs text-ink-muted">
              <span className="flex items-center gap-1"><Mail className="h-3.5 w-3.5" />{user?.email}</span>
              <span className="flex items-center gap-1"><Phone className="h-3.5 w-3.5" />{user?.phone}</span>
            </div>
          </div>
          <Badge tone="navy">Parent</Badge>
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="mb-1 flex items-center gap-2 text-[15px] font-bold text-ink"><Bell className="h-4 w-4" />Notification preferences</h3>
        <p className="mb-3 text-xs text-ink-muted">Choose which alerts you receive. Safety and emergency alerts are always on.</p>
        <div className="divide-y divide-slate-50">
          {prefRows.map((r) => (
            <label key={r.key} className="flex items-center justify-between py-2.5">
              <span className="text-sm text-ink-soft">{r.label}</span>
              <Toggle on={prefs[r.key]} onChange={(v) => setPref(r.key, v)} />
            </label>
          ))}
          <div className="flex items-center justify-between py-2.5">
            <span className="flex items-center gap-2 text-sm font-medium text-ink"><ShieldAlert className="h-4 w-4 text-danger" />Emergency & safety alerts</span>
            <span className="rounded-full bg-danger-50 px-2.5 py-1 text-xs font-semibold text-danger-600">Always on</span>
          </div>
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="mb-3 flex items-center gap-2 text-[15px] font-bold text-ink"><Lock className="h-4 w-4" />Change password</h3>
        <div className="grid gap-3 sm:grid-cols-3">
          <Input label="Current" type="password" placeholder="••••••" />
          <Input label="New" type="password" placeholder="••••••" />
          <Input label="Confirm" type="password" placeholder="••••••" />
        </div>
        <Button variant="outline" className="mt-3" size="sm">Update password</Button>
      </Card>

      <Button variant="danger" block icon={LogOut} onClick={logout}>Sign out</Button>
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className={cn('relative h-6 w-11 rounded-full transition', on ? 'bg-safe' : 'bg-slate-200')}
      role="switch" aria-checked={on}
    >
      <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition', on ? 'left-[22px]' : 'left-0.5')} />
    </button>
  );
}

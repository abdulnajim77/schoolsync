import { CalendarClock, Download, FileText } from 'lucide-react';
import { Button, Card, PageHeader } from '@/components/ui';
import { dayMonth } from '@/lib/format';
import { DEMO_EXAMS } from '@/data/demoData';

export function ExamRoutine() {
  const examName = DEMO_EXAMS[0]?.examName ?? 'Examination';
  return (
    <div className="space-y-4">
      <PageHeader
        title="Exam Routine" subtitle={examName} icon={CalendarClock}
        action={<div className="hidden gap-2 sm:flex">
          <Button variant="outline" size="sm" icon={FileText}>Syllabus</Button>
          <Button variant="primary" size="sm" icon={Download}>Routine PDF</Button>
        </div>}
      />

      <Card className="divide-y divide-slate-50">
        {DEMO_EXAMS.map((e) => (
          <div key={e.id} className="flex items-center gap-4 p-4">
            <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-navy/10 text-center text-navy">
              <span className="text-lg font-bold leading-none">{new Date(e.date).getDate()}</span>
              <span className="text-[10px] font-semibold uppercase">{dayMonth(e.date).split(' ')[1]}</span>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-ink">{e.subject}</p>
              <p className="text-xs text-ink-muted">{dayMonth(e.date)} · {e.time}</p>
            </div>
          </div>
        ))}
      </Card>

      <div className="flex gap-2 sm:hidden">
        <Button variant="outline" block icon={FileText}>Syllabus</Button>
        <Button variant="primary" block icon={Download}>Routine PDF</Button>
      </div>
    </div>
  );
}

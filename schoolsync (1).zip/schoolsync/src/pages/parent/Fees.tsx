import { useMemo, useState } from 'react';
import { IndianRupee, Download, CheckCircle2, Clock, Receipt } from 'lucide-react';
import type { FeeItem } from '@/types';
import { Badge, Button, Card, PageHeader, StatusChip } from '@/components/ui';
import { Modal } from '@/components/ui/Overlay';
import { inr, shortDate } from '@/lib/format';
import { DEMO_FEES } from '@/data/demoData';
import { useNotifications } from '@/state/NotificationContext';

export function Fees() {
  const [fees, setFees] = useState<FeeItem[]>(DEMO_FEES);
  const [paying, setPaying] = useState<FeeItem | null>(null);
  const [receipt, setReceipt] = useState<FeeItem | null>(null);
  const [busy, setBusy] = useState(false);
  const { push } = useNotifications();

  const totals = useMemo(() => {
    const paid = fees.filter((f) => f.status === 'paid').reduce((s, f) => s + f.amount, 0);
    const pending = fees.filter((f) => f.status !== 'paid').reduce((s, f) => s + f.amount, 0);
    const next = fees.filter((f) => f.status !== 'paid').sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];
    return { paid, pending, total: paid + pending, next };
  }, [fees]);

  const pay = () => {
    if (!paying) return;
    setBusy(true);
    setTimeout(() => {
      const rc = `SCH-2026-${Math.floor(10000 + Math.random() * 89999)}`;
      setFees((prev) => prev.map((f) => f.id === paying.id
        ? { ...f, status: 'paid', receipt: rc, paidOn: new Date().toISOString().slice(0, 10) } : f));
      push({ category: 'Fee', priority: 'INFO', title: 'Payment successful',
        body: `${paying.title} · ${inr(paying.amount)} paid. Receipt ${rc}.` });
      setBusy(false); setPaying(null);
    }, 1100);
  };

  return (
    <div className="space-y-5">
      <PageHeader title="Fees" subtitle="School & transport fee summary" icon={IndianRupee} />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <SummaryCard label="Annual total" value={inr(totals.total)} tone="text-navy" />
        <SummaryCard label="Paid" value={inr(totals.paid)} tone="text-safe-700" />
        <SummaryCard label="Pending" value={inr(totals.pending)} tone="text-warn-600" />
        <SummaryCard label="Next due" value={totals.next ? shortDate(totals.next.dueDate) : '—'} tone="text-ink" />
      </div>

      <div className="space-y-3">
        {fees.map((f) => (
          <Card key={f.id} className="flex items-center justify-between gap-3 p-4">
            <div className="flex items-center gap-3">
              <span className={`grid h-10 w-10 place-items-center rounded-xl ${f.status === 'paid' ? 'bg-safe-50 text-safe-700' : 'bg-warn-50 text-warn-600'}`}>
                {f.status === 'paid' ? <CheckCircle2 className="h-5 w-5" /> : <Clock className="h-5 w-5" />}
              </span>
              <div>
                <p className="font-semibold text-ink">{f.title}</p>
                <p className="text-xs text-ink-muted">
                  {f.status === 'paid' ? `Paid ${f.paidOn ? shortDate(f.paidOn) : ''} · ${f.receipt}` : `Due ${shortDate(f.dueDate)}`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-right">
                <p className="font-bold text-ink">{inr(f.amount)}</p>
                <StatusChip status={f.status} />
              </span>
              {f.status === 'paid'
                ? <Button variant="outline" size="sm" icon={Receipt} onClick={() => setReceipt(f)}>Receipt</Button>
                : <Button variant="primary" size="sm" onClick={() => setPaying(f)}>Pay now</Button>}
            </div>
          </Card>
        ))}
      </div>

      {/* Pay modal */}
      <Modal open={!!paying} onClose={() => !busy && setPaying(null)} title="Confirm payment"
        footer={<><Button variant="ghost" onClick={() => setPaying(null)} disabled={busy}>Cancel</Button>
          <Button variant="primary" loading={busy} onClick={pay}>Pay {paying ? inr(paying.amount) : ''}</Button></>}>
        {paying && (
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-xl bg-canvas px-4 py-3">
              <span className="text-sm text-ink-soft">{paying.title}</span>
              <span className="font-bold text-ink">{inr(paying.amount)}</span>
            </div>
            <p className="text-sm text-ink-muted">
              This is a simulated payment for the demo. The layer is built to plug into Razorpay,
              UPI, cards or net banking in production.
            </p>
            <div className="flex flex-wrap gap-2">
              {['UPI', 'Card', 'Net Banking', 'Razorpay'].map((m) => <Badge key={m} tone="blue">{m}</Badge>)}
            </div>
          </div>
        )}
      </Modal>

      {/* Receipt modal */}
      <Modal open={!!receipt} onClose={() => setReceipt(null)} title="Payment receipt"
        footer={<Button variant="outline" icon={Download} onClick={() => setReceipt(null)}>Download</Button>}>
        {receipt && (
          <div className="space-y-3">
            <div className="rounded-2xl border border-slate-100 p-4">
              <div className="flex items-center justify-between border-b border-dashed border-slate-200 pb-3">
                <div>
                  <p className="font-bold text-ink">Little Star Kids Academy</p>
                  <p className="text-xs text-ink-muted">Official Fee Receipt</p>
                </div>
                <Badge tone="green" dot>Paid</Badge>
              </div>
              <dl className="mt-3 space-y-2 text-sm">
                <Row k="Receipt No." v={receipt.receipt ?? '—'} />
                <Row k="Description" v={receipt.title} />
                <Row k="Paid on" v={receipt.paidOn ? shortDate(receipt.paidOn) : '—'} />
                <Row k="Amount" v={inr(receipt.amount)} strong />
              </dl>
            </div>
            <p className="text-center text-xs text-ink-muted">This is a computer-generated demo receipt.</p>
          </div>
        )}
      </Modal>
    </div>
  );
}

function SummaryCard({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-ink-muted">{label}</p>
      <p className={`mt-1 text-lg font-bold ${tone}`}>{value}</p>
    </Card>
  );
}

function Row({ k, v, strong }: { k: string; v: string; strong?: boolean }) {
  return (
    <div className="flex justify-between">
      <dt className="text-ink-muted">{k}</dt>
      <dd className={strong ? 'font-bold text-ink' : 'font-medium text-ink'}>{v}</dd>
    </div>
  );
}

import { FileText, Download } from 'lucide-react';
import { Badge, Button, Card, PageHeader, ProgressRing } from '@/components/ui';
import { useParent } from '@/state/ParentContext';
import { DEMO_REPORT_CARD } from '@/data/demoData';

const gradeTone = (g: string) => g.startsWith('A') ? 'green' : g.startsWith('B') ? 'blue' : 'orange';

export function ReportCard() {
  const { child } = useParent();
  if (!child) return null;
  const total = DEMO_REPORT_CARD.reduce((s, r) => s + r.marks, 0);
  const max = DEMO_REPORT_CARD.reduce((s, r) => s + r.max, 0);
  const pct = Math.round((total / max) * 100);

  return (
    <div className="space-y-5">
      <PageHeader title="Report Card" subtitle="Half Yearly Examination"
        icon={FileText}
        action={<Button variant="primary" size="sm" icon={Download} className="hidden sm:inline-flex">Download</Button>} />

      <Card className="flex flex-col items-center gap-4 p-5 sm:flex-row sm:justify-between">
        <div className="flex items-center gap-4">
          <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-navy to-brand-500 text-lg font-bold text-white">
            {child.firstName[0]}{child.lastName[0]}
          </div>
          <div>
            <p className="text-lg font-bold text-ink">{child.firstName} {child.lastName}</p>
            <p className="text-sm text-ink-muted">{child.className} · Section {child.section} · Roll {child.roll}</p>
          </div>
        </div>
        <ProgressRing value={pct} size={104} stroke={10} sub="overall" />
      </Card>

      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-canvas text-left text-xs font-semibold uppercase tracking-wide text-ink-muted">
            <tr>
              <th className="px-4 py-3">Subject</th>
              <th className="px-4 py-3">Marks</th>
              <th className="px-4 py-3">Grade</th>
              <th className="hidden px-4 py-3 sm:table-cell">Remark</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {DEMO_REPORT_CARD.map((r) => (
              <tr key={r.subject}>
                <td className="px-4 py-3 font-semibold text-ink">{r.subject}</td>
                <td className="px-4 py-3 text-ink-soft">{r.marks}/{r.max}</td>
                <td className="px-4 py-3"><Badge tone={gradeTone(r.grade)}>{r.grade}</Badge></td>
                <td className="hidden px-4 py-3 text-ink-muted sm:table-cell">{r.remark}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t border-slate-100 bg-canvas font-bold text-ink">
              <td className="px-4 py-3">Total</td>
              <td className="px-4 py-3">{total}/{max}</td>
              <td className="px-4 py-3" colSpan={2}>{pct}%</td>
            </tr>
          </tfoot>
        </table>
      </Card>

      <Button variant="primary" block icon={Download} className="sm:hidden">Download report card</Button>
    </div>
  );
}

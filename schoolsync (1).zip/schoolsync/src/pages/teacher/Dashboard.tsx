import { useNavigate } from 'react-router-dom';
import {
  CalendarCheck, Users, BookOpen, CalendarClock, Megaphone, GraduationCap,
} from 'lucide-react';
import { Button, Card } from '@/components/ui';
import { greeting } from '@/lib/format';
import { useAuth } from '@/state/AuthContext';
import { demoDb } from '@/data/demoDb';

export function TeacherDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const students = demoDb.getStudents();
  const myClass = students.filter((s) => s.className === 'LKG' || s.className === 'UKG');

  const tiles = [
    { label: 'My Students', value: myClass.length, icon: Users, tone: 'bg-brand-50 text-brand-600' },
    { label: 'Present Today', value: myClass.length - 1, icon: CalendarCheck, tone: 'bg-safe-50 text-safe-700' },
    { label: 'Homework Set', value: 3, icon: BookOpen, tone: 'bg-navy/10 text-navy' },
    { label: 'Upcoming Exams', value: 4, icon: CalendarClock, tone: 'bg-warn-50 text-warn-600' },
  ];

  return (
    <div className="space-y-5">
      <div>
        <p className="text-sm text-ink-muted">{greeting()},</p>
        <h1 className="text-2xl font-bold tracking-tight text-ink">{user?.name}</h1>
      </div>

      <Card className="flex items-center justify-between gap-4 bg-gradient-to-br from-navy to-navy-600 p-5 text-white">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/15"><GraduationCap className="h-6 w-6" /></span>
          <div>
            <p className="text-sm text-white/70">Class Teacher</p>
            <p className="text-lg font-bold">LKG-A · UKG-A</p>
          </div>
        </div>
        <Button variant="secondary" size="sm" icon={CalendarCheck} onClick={() => navigate('/teacher/attendance')}>
          Mark attendance
        </Button>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {tiles.map((t) => (
          <Card key={t.label} className="p-4">
            <span className={`grid h-10 w-10 place-items-center rounded-xl ${t.tone}`}><t.icon className="h-5 w-5" /></span>
            <p className="mt-3 text-2xl font-bold text-ink">{t.value}</p>
            <p className="text-xs text-ink-muted">{t.label}</p>
          </Card>
        ))}
      </div>

      <Card className="p-4">
        <h3 className="mb-1 flex items-center gap-2 text-[15px] font-bold text-ink"><Megaphone className="h-4 w-4" />Reminders</h3>
        <ul className="mt-2 space-y-2 text-sm text-ink-soft">
          <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-brand-400" />Submit Half Yearly marks by 22 October.</li>
          <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-brand-400" />PTM for LKG & UKG on 12 October.</li>
          <li className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-brand-400" />Upload EVS drawing homework photos.</li>
        </ul>
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { CalendarCheck, Check } from 'lucide-react';
import type { Student } from '@/types';
import { Button, Card, PageHeader } from '@/components/ui';
import { cn } from '@/lib/cn';
import { shortDate } from '@/lib/format';
import { demoDb } from '@/data/demoDb';
import { useNotifications } from '@/state/NotificationContext';

type Mark = 'present' | 'absent' | 'leave';
const options: { key: Mark; label: string; on: string }[] = [
  { key: 'present', label: 'P', on: 'bg-safe text-white' },
  { key: 'absent', label: 'A', on: 'bg-danger text-white' },
  { key: 'leave', label: 'L', on: 'bg-warn text-white' },
];

export function TeacherAttendance() {
  const roster: Student[] = demoDb.getStudents().filter((s) => ['LKG', 'UKG'].includes(s.className));
  const [marks, setMarks] = useState<Record<string, Mark>>(
    () => Object.fromEntries(roster.map((s) => [s.id, 'present' as Mark])),
  );
  const [saved, setSaved] = useState(false);
  const { push } = useNotifications();

  const present = Object.values(marks).filter((m) => m === 'present').length;
  const absent = Object.values(marks).filter((m) => m === 'absent').length;

  const save = () => {
    setSaved(true);
    roster.forEach((s) => {
      if (marks[s.id] === 'absent')
        push({ category: 'Academic', priority: 'IMPORTANT', title: 'Marked absent',
          body: `${s.firstName} ${s.lastName} has been marked absent today.` });
    });
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-4">
      <PageHeader title="Mark Attendance" subtitle={`LKG-A & UKG-A · ${shortDate(new Date())}`} icon={CalendarCheck}
        action={<Button variant="primary" size="sm" icon={saved ? Check : undefined} onClick={save}>
          {saved ? 'Saved' : 'Save'}
        </Button>} />

      <div className="grid grid-cols-3 gap-3">
        <Card className="p-3 text-center"><p className="text-2xl font-bold text-ink">{roster.length}</p><p className="text-[11px] text-ink-muted">Total</p></Card>
        <Card className="p-3 text-center"><p className="text-2xl font-bold text-safe-700">{present}</p><p className="text-[11px] text-ink-muted">Present</p></Card>
        <Card className="p-3 text-center"><p className="text-2xl font-bold text-danger-600">{absent}</p><p className="text-[11px] text-ink-muted">Absent</p></Card>
      </div>

      <Card className="divide-y divide-slate-50">
        {roster.map((s) => (
          <div key={s.id} className="flex items-center justify-between gap-3 px-4 py-3">
            <div>
              <p className="font-semibold text-ink">{s.firstName} {s.lastName}</p>
              <p className="text-xs text-ink-muted">{s.className}-{s.section} · Roll {s.roll}</p>
            </div>
            <div className="flex gap-1.5">
              {options.map((o) => (
                <button
                  key={o.key}
                  onClick={() => setMarks((p) => ({ ...p, [s.id]: o.key }))}
                  className={cn('grid h-9 w-9 place-items-center rounded-lg text-sm font-bold transition',
                    marks[s.id] === o.key ? o.on : 'bg-slate-100 text-slate-400 hover:bg-slate-200')}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { Save, School, Radar, Palette, Bus } from 'lucide-react';
import { Button, Card, Input, PageHeader, Select } from '@/components/ui';
import { useNotifications } from '@/state/NotificationContext';
import { DEMO_SCHOOL } from '@/data/demoData';

const BRAND_COLORS = ['#253B80', '#3B82F6', '#22C55E', '#F59E0B', '#EF4444', '#7C3AED'];

export function AdminSettings() {
  const { push } = useNotifications();
  const s = DEMO_SCHOOL.settings;

  const [name, setName] = useState(DEMO_SCHOOL.name);
  const [phone, setPhone] = useState(DEMO_SCHOOL.phone);
  const [email, setEmail] = useState(DEMO_SCHOOL.email);
  const [year, setYear] = useState(DEMO_SCHOOL.academicYear);
  const [schoolR, setSchoolR] = useState(s.schoolGeofenceRadius);
  const [pickupR, setPickupR] = useState(s.pickupGeofenceRadius);
  const [dropR, setDropR] = useState(s.dropGeofenceRadius);
  const [approachR, setApproachR] = useState(s.approachDistance);
  const [cutoff, setCutoff] = useState(s.transportSkipCutoff);
  const [callMode, setCallMode] = useState(s.callDriverMode);
  const [color, setColor] = useState(DEMO_SCHOOL.primaryColor);

  const save = () => {
    push({
      title: 'Settings saved',
      body: 'Your school configuration has been updated.',
      category: 'Notice',
      priority: 'INFO',
    });
  };

  return (
    <div className="space-y-5">
      <PageHeader
        title="Settings"
        subtitle="School profile, geofencing and branding"
        action={<Button icon={Save} onClick={save}>Save changes</Button>}
      />

      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2 text-navy">
          <School className="h-5 w-5" />
          <h3 className="text-base font-bold">School profile</h3>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input label="School name" value={name} onChange={(e) => setName(e.target.value)} />
          <Input label="Academic year" value={year} onChange={(e) => setYear(e.target.value)} />
          <Input label="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <Input label="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
      </Card>

      <Card className="p-5">
        <div className="mb-1 flex items-center gap-2 text-navy">
          <Radar className="h-5 w-5" />
          <h3 className="text-base font-bold">Geofencing</h3>
        </div>
        <p className="mb-4 text-sm text-ink-muted">
          Distances used to decide when parents are notified. All values are in metres.
        </p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Input label="School radius" type="number" value={schoolR} onChange={(e) => setSchoolR(Number(e.target.value))} />
          <Input label="Pickup radius" type="number" value={pickupR} onChange={(e) => setPickupR(Number(e.target.value))} />
          <Input label="Drop radius" type="number" value={dropR} onChange={(e) => setDropR(Number(e.target.value))} />
          <Input label="Approach alert" type="number" value={approachR} onChange={(e) => setApproachR(Number(e.target.value))} />
        </div>
      </Card>

      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2 text-navy">
          <Bus className="h-5 w-5" />
          <h3 className="text-base font-bold">Transport</h3>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            label="Parent transport-skip cutoff"
            type="time"
            value={cutoff}
            onChange={(e) => setCutoff(e.target.value)}
          />
          <Select
            label="Call driver mode"
            value={callMode}
            onChange={(e) => setCallMode(e.target.value as typeof callMode)}
          >
            <option value="show">Show number</option>
            <option value="click-to-call">Click to call (hidden number)</option>
            <option value="active-trip-only">Active trip only</option>
          </Select>
        </div>
      </Card>

      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2 text-navy">
          <Palette className="h-5 w-5" />
          <h3 className="text-base font-bold">Branding</h3>
        </div>
        <p className="mb-3 text-sm text-ink-muted">Primary colour for this school's white-labelled portal.</p>
        <div className="flex flex-wrap gap-3">
          {BRAND_COLORS.map((c) => (
            <button
              key={c}
              onClick={() => setColor(c)}
              className={`h-10 w-10 rounded-full ring-2 ring-offset-2 transition ${color === c ? 'ring-ink' : 'ring-transparent'}`}
              style={{ backgroundColor: c }}
              aria-label={c}
            />
          ))}
        </div>
      </Card>
    </div>
  );
}

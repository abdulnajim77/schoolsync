import { Download, FileBarChart, Users, Bus, IndianRupee, CalendarCheck } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Button, Card, PageHeader, SectionTitle } from '@/components/ui';

const REPORTS: { title: string; desc: string; icon: LucideIcon; tone: string }[] = [
  { title: 'Attendance Report', desc: 'Monthly attendance by class and section.', icon: CalendarCheck, tone: 'bg-brand-50 text-brand-600' },
  { title: 'Fee Collection Report', desc: 'Collected vs pending, month on month.', icon: IndianRupee, tone: 'bg-safe-50 text-safe-700' },
  { title: 'Transport Report', desc: 'Trips, boardings and geofence events.', icon: Bus, tone: 'bg-navy/10 text-navy' },
  { title: 'Student Roster', desc: 'Full enrolment list with transport details.', icon: Users, tone: 'bg-warn-50 text-warn-600' },
];

export function AdminReports() {
  return (
    <div className="space-y-5">
      <PageHeader title="Reports" subtitle="Export school data for records and audits" />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'Students', value: '235' },
          { label: 'Avg attendance', value: '94%' },
          { label: 'Fees collected', value: '82%' },
          { label: 'Trips this month', value: '312' },
        ].map((k) => (
          <Card key={k.label} className="p-4">
            <div className="text-xs font-medium uppercase tracking-wide text-ink-muted">{k.label}</div>
            <div className="mt-1 text-2xl font-bold text-navy">{k.value}</div>
          </Card>
        ))}
      </div>

      <SectionTitle>Downloadable reports</SectionTitle>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {REPORTS.map((r) => (
          <Card key={r.title} className="flex items-center gap-4 p-5">
            <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${r.tone}`}>
              <r.icon className="h-6 w-6" />
            </span>
            <div className="min-w-0 flex-1">
              <h3 className="font-bold text-ink">{r.title}</h3>
              <p className="text-sm text-ink-muted">{r.desc}</p>
            </div>
            <Button size="sm" variant="outline" icon={Download}>PDF</Button>
          </Card>
        ))}
      </div>

      <Card className="flex items-center gap-3 p-5 text-ink-muted">
        <FileBarChart className="h-5 w-5 text-brand-500" />
        <p className="text-sm">
          In production these export to CSV and PDF from your live Firestore data. In demo mode the buttons are illustrative.
        </p>
      </Card>
    </div>
  );
}

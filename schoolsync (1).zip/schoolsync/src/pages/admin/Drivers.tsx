import { Plus, Phone } from 'lucide-react';
import type { Driver } from '@/types';
import { Avatar, Badge, Button, PageHeader, StatusChip } from '@/components/ui';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { DEMO_BUSES, DEMO_DRIVERS } from '@/data/demoData';
import { shortDate } from '@/lib/format';

const busCode = (id?: string) => DEMO_BUSES.find((b) => b.id === id)?.code ?? '—';

const columns: Column<Driver>[] = [
  {
    key: 'name',
    header: 'Driver',
    render: (d) => (
      <div className="flex items-center gap-3">
        <Avatar name={d.name} size={36} />
        <div>
          <div className="font-semibold text-ink">{d.name}</div>
          <div className="inline-flex items-center gap-1 text-xs text-ink-muted">
            <Phone className="h-3 w-3" /> {d.phone}
          </div>
        </div>
      </div>
    ),
  },
  { key: 'licence', header: 'Licence', className: 'hidden md:table-cell', render: (d) => d.licence },
  {
    key: 'expiry',
    header: 'Licence expiry',
    className: 'hidden lg:table-cell',
    render: (d) => shortDate(d.licenceExpiry),
  },
  { key: 'bus', header: 'Assigned bus', render: (d) => <Badge tone="navy">{busCode(d.busId)}</Badge> },
  {
    key: 'emergency',
    header: 'Emergency',
    className: 'hidden xl:table-cell',
    render: (d) => d.emergencyContact,
  },
  { key: 'status', header: 'Status', render: (d) => <StatusChip status={d.status} /> },
];

export function AdminDrivers() {
  return (
    <div className="space-y-5">
      <PageHeader
        title="Drivers & Helpers"
        subtitle={`${DEMO_DRIVERS.length} drivers on record`}
        action={<Button icon={Plus}>Add Driver</Button>}
      />
      <DataTable columns={columns} rows={DEMO_DRIVERS} rowKey={(d) => d.id} />
    </div>
  );
}

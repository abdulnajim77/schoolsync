import { Plus, Phone } from 'lucide-react';
import { Avatar, Badge, Button, PageHeader } from '@/components/ui';
import { DataTable, type Column } from '@/components/admin/DataTable';

interface TeacherRow {
  id: string;
  name: string;
  phone: string;
  subject: string;
  classes: string;
  status: string;
}

const TEACHERS: TeacherRow[] = [
  { id: 't1', name: 'Ms. Sarkar', phone: '+91 98320 11001', subject: 'Class Teacher', classes: 'LKG-A', status: 'active' },
  { id: 't2', name: 'Mrs. Banerjee', phone: '+91 98320 11002', subject: 'English', classes: 'LKG, UKG', status: 'active' },
  { id: 't3', name: 'Mr. Dutta', phone: '+91 98320 11003', subject: 'Mathematics', classes: 'Class 1, 2', status: 'active' },
  { id: 't4', name: 'Ms. Roy', phone: '+91 98320 11004', subject: 'EVS & Drawing', classes: 'LKG–Class 2', status: 'active' },
  { id: 't5', name: 'Mrs. Mitra', phone: '+91 98320 11005', subject: 'Bengali', classes: 'UKG, Class 1', status: 'active' },
];

const columns: Column<TeacherRow>[] = [
  {
    key: 'name',
    header: 'Teacher',
    render: (t) => (
      <div className="flex items-center gap-3">
        <Avatar name={t.name} size={36} hue="#22C55E" />
        <div>
          <div className="font-semibold text-ink">{t.name}</div>
          <div className="inline-flex items-center gap-1 text-xs text-ink-muted">
            <Phone className="h-3 w-3" /> {t.phone}
          </div>
        </div>
      </div>
    ),
  },
  { key: 'subject', header: 'Role / Subject', render: (t) => t.subject },
  { key: 'classes', header: 'Classes', className: 'hidden md:table-cell', render: (t) => t.classes },
  { key: 'status', header: 'Status', render: () => <Badge tone="green" dot>Active</Badge> },
];

export function AdminTeachers() {
  return (
    <div className="space-y-5">
      <PageHeader
        title="Teachers"
        subtitle={`${TEACHERS.length} teaching staff`}
        action={<Button icon={Plus}>Add Teacher</Button>}
      />
      <DataTable columns={columns} rows={TEACHERS} rowKey={(t) => t.id} />
    </div>
  );
}

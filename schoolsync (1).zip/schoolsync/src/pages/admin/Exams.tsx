import { Plus, CalendarClock, Clock } from 'lucide-react';
import { Badge, Button, Card, PageHeader } from '@/components/ui';
import { DEMO_EXAMS } from '@/data/demoData';
import { dayMonth } from '@/lib/format';

export function AdminExams() {
  const examName = DEMO_EXAMS[0]?.examName ?? 'Examination';

  return (
    <div className="space-y-5">
      <PageHeader
        title="Exams"
        subtitle={examName}
        action={<Button icon={Plus}>Add Exam</Button>}
      />

      <Card className="p-5">
        <div className="mb-4 flex items-center gap-2 text-navy">
          <CalendarClock className="h-5 w-5" />
          <h3 className="text-base font-bold">{examName}</h3>
          <Badge tone="blue" className="ml-auto">LKG</Badge>
        </div>

        <div className="space-y-2">
          {DEMO_EXAMS.map((e) => (
            <div
              key={e.id}
              className="flex items-center justify-between rounded-xl border border-slate-100 bg-canvas px-4 py-3"
            >
              <div className="flex items-center gap-3">
                <span className="grid h-11 min-w-[3.5rem] place-items-center rounded-xl bg-white px-2 text-center shadow-card">
                  <span className="text-xs font-bold leading-tight text-navy">{dayMonth(e.date)}</span>
                </span>
                <span className="font-semibold text-ink">{e.subject}</span>
              </div>
              <span className="inline-flex items-center gap-1 text-sm text-ink-muted">
                <Clock className="h-3.5 w-3.5" /> {e.time}
              </span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

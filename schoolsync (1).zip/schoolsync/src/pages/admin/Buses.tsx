import { Bus as BusIcon, Plus } from 'lucide-react';
import type { Bus } from '@/types';
import { Badge, Button, PageHeader, StatusChip } from '@/components/ui';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { DEMO_BUSES, DEMO_DRIVERS, DEMO_ROUTE } from '@/data/demoData';
import { shortDate } from '@/lib/format';

const driverName = (id: string) => DEMO_DRIVERS.find((d) => d.id === id)?.name ?? '—';

const columns: Column<Bus>[] = [
  {
    key: 'code',
    header: 'Bus',
    render: (b) => (
      <div className="flex items-center gap-3">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy/10 text-navy">
          <BusIcon className="h-4 w-4" />
        </span>
        <div>
          <div className="font-semibold text-ink">{b.code}</div>
          <div className="text-xs text-ink-muted">{b.vehicleNumber}</div>
        </div>
      </div>
    ),
  },
  { key: 'type', header: 'Type', className: 'hidden md:table-cell', render: (b) => b.vehicleType },
  { key: 'capacity', header: 'Seats', render: (b) => <Badge tone="blue">{b.capacity}</Badge> },
  { key: 'driver', header: 'Driver', render: (b) => driverName(b.driverId) },
  { key: 'helper', header: 'Helper', className: 'hidden lg:table-cell', render: (b) => b.helperName },
  { key: 'route', header: 'Route', className: 'hidden md:table-cell', render: () => DEMO_ROUTE.name },
  {
    key: 'fitness',
    header: 'Fitness expiry',
    className: 'hidden xl:table-cell',
    render: (b) => shortDate(b.fitnessExpiry),
  },
  { key: 'status', header: 'Status', render: (b) => <StatusChip status={b.status} /> },
];

export function AdminBuses() {
  return (
    <div className="space-y-5">
      <PageHeader
        title="Buses"
        subtitle={`${DEMO_BUSES.length} vehicles in the fleet`}
        action={<Button icon={Plus}>Add Bus</Button>}
      />
      <DataTable columns={columns} rows={DEMO_BUSES} rowKey={(b) => b.id} />
    </div>
  );
}

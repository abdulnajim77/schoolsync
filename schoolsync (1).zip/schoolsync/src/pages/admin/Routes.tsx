import { Plus, Clock, Users, MapPin } from 'lucide-react';
import { Badge, Button, Card, PageHeader, SectionTitle } from '@/components/ui';
import { LiveMap, type MapMarker } from '@/components/transport/LiveMap';
import { DEMO_ROUTE, DEMO_STUDENTS } from '@/data/demoData';

export function AdminRoutes() {
  const stops = DEMO_ROUTE.stops;

  const markers: MapMarker[] = stops.map((s, i) => ({
    id: s.id,
    pos: { lat: s.lat, lng: s.lng },
    kind: i === stops.length - 1 ? 'school' : 'stop',
    label: s.name,
  }));
  const route = stops.map((s) => ({ lat: s.lat, lng: s.lng }));

  const countFor = (stopId: string) =>
    DEMO_STUDENTS.filter((st) => st.pickup.name === stops.find((s) => s.id === stopId)?.name).length;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Routes"
        subtitle="1 active route · 5 stops"
        action={<Button icon={Plus}>Add Route</Button>}
      />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-5">
        <Card className="overflow-hidden lg:col-span-3">
          <LiveMap markers={markers} route={route} className="h-[360px] w-full" />
        </Card>

        <div className="lg:col-span-2">
          <Card className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-ink">{DEMO_ROUTE.name}</h3>
                <p className="text-sm text-ink-muted">Depot → School</p>
              </div>
              <Badge tone="green" dot>Active</Badge>
            </div>

            <ol className="relative space-y-4 border-l-2 border-dashed border-slate-200 pl-5">
              {stops.map((s, i) => (
                <li key={s.id} className="relative">
                  <span className="absolute -left-[26px] grid h-5 w-5 place-items-center rounded-full bg-white ring-2 ring-brand-400">
                    <MapPin className="h-3 w-3 text-brand-500" />
                  </span>
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-ink">{s.name}</span>
                    {i !== stops.length - 1 && countFor(s.id) > 0 && (
                      <span className="inline-flex items-center gap-1 text-xs text-ink-muted">
                        <Users className="h-3.5 w-3.5" /> {countFor(s.id)}
                      </span>
                    )}
                  </div>
                  <span className="inline-flex items-center gap-1 text-xs text-ink-muted">
                    <Clock className="h-3 w-3" /> {s.expectedTime}
                  </span>
                </li>
              ))}
            </ol>
          </Card>
        </div>
      </div>

      <SectionTitle>Geofence defaults</SectionTitle>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          { label: 'School radius', value: '200 m' },
          { label: 'Pickup radius', value: '100 m' },
          { label: 'Drop radius', value: '100 m' },
          { label: 'Approach alert', value: '500 m' },
        ].map((g) => (
          <Card key={g.label} className="p-4">
            <div className="text-xs font-medium uppercase tracking-wide text-ink-muted">{g.label}</div>
            <div className="mt-1 text-xl font-bold text-navy">{g.value}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

import { Plus, BookOpen } from 'lucide-react';
import { Badge, Button, Card, PageHeader } from '@/components/ui';
import { DEMO_HOMEWORK } from '@/data/demoData';
import { shortDate } from '@/lib/format';

const SUBJECT_TONE: Record<string, 'navy' | 'blue' | 'green' | 'orange'> = {
  English: 'blue',
  Mathematics: 'navy',
  EVS: 'green',
  Bengali: 'orange',
};

export function AdminHomework() {
  return (
    <div className="space-y-5">
      <PageHeader
        title="Homework"
        subtitle={`${DEMO_HOMEWORK.length} active assignments`}
        action={<Button icon={Plus}>Assign Homework</Button>}
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {DEMO_HOMEWORK.map((h) => (
          <Card key={h.id} className="flex flex-col p-5">
            <div className="mb-2 flex items-center justify-between">
              <Badge tone={SUBJECT_TONE[h.subject] ?? 'slate'}>{h.subject}</Badge>
              <Badge tone="slate">{h.className}</Badge>
            </div>
            <h3 className="flex items-center gap-2 font-bold text-ink">
              <BookOpen className="h-4 w-4 text-brand-500" /> {h.title}
            </h3>
            <p className="mt-1 flex-1 text-sm text-ink-soft">{h.detail}</p>
            <div className="mt-3 text-xs font-medium text-ink-muted">Due {shortDate(h.due)}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

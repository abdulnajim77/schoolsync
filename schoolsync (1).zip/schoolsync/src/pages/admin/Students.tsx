import { useMemo, useState } from 'react';
import { Plus, Search, Pencil, MapPin } from 'lucide-react';
import type { Student } from '@/types';
import { Avatar, Badge, Button, Input, PageHeader, Select, StatusChip, EmptyState } from '@/components/ui';
import { Modal } from '@/components/ui/Overlay';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { demoDb } from '@/data/demoDb';
import { DEMO_BUSES } from '@/data/demoData';
import { uid } from '@/lib/id';

const emptyDraft = (): Student => ({
  id: uid('stu'),
  schoolId: 'school_001',
  firstName: '',
  lastName: '',
  dob: '2021-01-01',
  gender: 'female',
  className: 'LKG',
  section: 'A',
  roll: 0,
  parentUids: [],
  parentName: '',
  parentPhone: '',
  address: 'Chandannagar, Hooghly',
  emergencyContact: '',
  busId: 'bus_03',
  routeId: 'route_A',
  pickup: { name: 'Jyoti More', lat: 22.8663, lng: 88.3742, radius: 100 },
  drop: { name: 'Jyoti More', lat: 22.8663, lng: 88.3742, radius: 100 },
  transportStatus: 'NORMAL',
  status: 'active',
});

export function AdminStudents() {
  const [students, setStudents] = useState<Student[]>(() => demoDb.getStudents());
  const [query, setQuery] = useState('');
  const [klass, setKlass] = useState('all');
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Student>(emptyDraft);
  const [editing, setEditing] = useState(false);

  const classes = useMemo(
    () => Array.from(new Set(students.map((s) => s.className))).sort(),
    [students],
  );

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return students.filter((s) => {
      const matchesQuery =
        !q ||
        `${s.firstName} ${s.lastName}`.toLowerCase().includes(q) ||
        s.parentName.toLowerCase().includes(q) ||
        s.pickup.name.toLowerCase().includes(q);
      const matchesClass = klass === 'all' || s.className === klass;
      return matchesQuery && matchesClass;
    });
  }, [students, query, klass]);

  const openAdd = () => {
    setDraft(emptyDraft());
    setEditing(false);
    setOpen(true);
  };
  const openEdit = (s: Student) => {
    setDraft({ ...s });
    setEditing(true);
    setOpen(true);
  };

  const save = () => {
    if (editing) {
      setStudents(demoDb.updateStudent(draft.id, draft));
    } else {
      const next = [{ ...draft }, ...demoDb.getStudents()];
      demoDb.setStudents(next);
      setStudents(next);
    }
    setOpen(false);
  };

  const busCode = (busId?: string) => DEMO_BUSES.find((b) => b.id === busId)?.code ?? '—';

  const columns: Column<Student>[] = [
    {
      key: 'name',
      header: 'Student',
      render: (s) => (
        <div className="flex items-center gap-3">
          <Avatar name={`${s.firstName} ${s.lastName}`} size={36} />
          <div>
            <div className="font-semibold text-ink">{s.firstName} {s.lastName}</div>
            <div className="text-xs text-ink-muted">Roll {s.roll} · ID {s.id.toUpperCase()}</div>
          </div>
        </div>
      ),
    },
    { key: 'class', header: 'Class', render: (s) => <span>{s.className} — {s.section}</span> },
    {
      key: 'parent',
      header: 'Parent',
      className: 'hidden md:table-cell',
      render: (s) => (
        <div>
          <div className="text-ink-soft">{s.parentName}</div>
          <div className="text-xs text-ink-muted">{s.parentPhone}</div>
        </div>
      ),
    },
    {
      key: 'pickup',
      header: 'Pickup',
      className: 'hidden lg:table-cell',
      render: (s) => (
        <span className="inline-flex items-center gap-1 text-ink-soft">
          <MapPin className="h-3.5 w-3.5 text-brand-500" /> {s.pickup.name}
        </span>
      ),
    },
    { key: 'bus', header: 'Bus', render: (s) => <Badge tone="navy">{busCode(s.busId)}</Badge> },
    { key: 'status', header: 'Transport', render: (s) => <StatusChip status={s.transportStatus} /> },
    {
      key: 'actions',
      header: '',
      className: 'text-right',
      render: (s) => (
        <Button size="sm" variant="ghost" icon={Pencil} onClick={() => openEdit(s)}>
          Edit
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Students"
        subtitle={`${students.length} enrolled · ${rows.length} shown`}
        action={<Button icon={Plus} onClick={openAdd}>Add Student</Button>}
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="sm:max-w-xs sm:flex-1">
          <Input
            icon={Search}
            placeholder="Search name, parent or stop…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="sm:w-48">
          <Select value={klass} onChange={(e) => setKlass(e.target.value)}>
            <option value="all">All classes</option>
            {classes.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </Select>
        </div>
      </div>

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={(s) => s.id}
        empty={<EmptyState icon={Search} title="No students found" hint="Try a different search or filter." />}
      />

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? 'Edit student' : 'Add student'}
        size="lg"
        footer={
          <>
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={!draft.firstName.trim()}>
              {editing ? 'Save changes' : 'Add student'}
            </Button>
          </>
        }
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input label="First name" value={draft.firstName} onChange={(e) => setDraft({ ...draft, firstName: e.target.value })} />
          <Input label="Last name" value={draft.lastName} onChange={(e) => setDraft({ ...draft, lastName: e.target.value })} />
          <Select label="Class" value={draft.className} onChange={(e) => setDraft({ ...draft, className: e.target.value })}>
            {['Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2'].map((c) => <option key={c}>{c}</option>)}
          </Select>
          <Select label="Section" value={draft.section} onChange={(e) => setDraft({ ...draft, section: e.target.value })}>
            {['A', 'B', 'C'].map((c) => <option key={c}>{c}</option>)}
          </Select>
          <Input label="Roll number" type="number" value={draft.roll || ''} onChange={(e) => setDraft({ ...draft, roll: Number(e.target.value) })} />
          <Select label="Gender" value={draft.gender} onChange={(e) => setDraft({ ...draft, gender: e.target.value as Student['gender'] })}>
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="other">Other</option>
          </Select>
          <Input label="Parent name" value={draft.parentName} onChange={(e) => setDraft({ ...draft, parentName: e.target.value })} />
          <Input label="Parent phone" value={draft.parentPhone} onChange={(e) => setDraft({ ...draft, parentPhone: e.target.value, emergencyContact: e.target.value })} />
          <Select label="Bus" value={draft.busId} onChange={(e) => setDraft({ ...draft, busId: e.target.value })}>
            {DEMO_BUSES.map((b) => <option key={b.id} value={b.id}>{b.code} — {b.vehicleNumber}</option>)}
          </Select>
          <Input
            label="Pickup point"
            value={draft.pickup.name}
            onChange={(e) => setDraft({ ...draft, pickup: { ...draft.pickup, name: e.target.value }, drop: { ...draft.drop, name: e.target.value } })}
          />
        </div>
      </Modal>
    </div>
  );
}

import { useMemo } from 'react';
import { Plus, Phone } from 'lucide-react';
import { Avatar, Badge, Button, PageHeader } from '@/components/ui';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { DEMO_STUDENTS } from '@/data/demoData';

interface ParentRow {
  key: string;
  name: string;
  phone: string;
  children: string[];
  address: string;
}

export function AdminParents() {
  const parents = useMemo<ParentRow[]>(() => {
    const map = new Map<string, ParentRow>();
    for (const s of DEMO_STUDENTS) {
      const key = s.parentPhone;
      const child = `${s.firstName} ${s.lastName}`;
      const existing = map.get(key);
      if (existing) existing.children.push(child);
      else map.set(key, { key, name: s.parentName, phone: s.parentPhone, children: [child], address: s.address });
    }
    return Array.from(map.values());
  }, []);

  const columns: Column<ParentRow>[] = [
    {
      key: 'name',
      header: 'Parent',
      render: (p) => (
        <div className="flex items-center gap-3">
          <Avatar name={p.name} size={36} hue="#3B82F6" />
          <div>
            <div className="font-semibold text-ink">{p.name}</div>
            <div className="inline-flex items-center gap-1 text-xs text-ink-muted">
              <Phone className="h-3 w-3" /> {p.phone}
            </div>
          </div>
        </div>
      ),
    },
    {
      key: 'children',
      header: 'Children',
      render: (p) => (
        <div className="flex flex-wrap gap-1">
          {p.children.map((c) => (
            <Badge key={c} tone="blue">{c}</Badge>
          ))}
        </div>
      ),
    },
    { key: 'address', header: 'Address', className: 'hidden md:table-cell', render: (p) => p.address },
    { key: 'status', header: 'Status', render: () => <Badge tone="green" dot>Active</Badge> },
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Parents"
        subtitle={`${parents.length} parent accounts`}
        action={<Button icon={Plus}>Add Parent</Button>}
      />
      <DataTable columns={columns} rows={parents} rowKey={(p) => p.key} />
    </div>
  );
}

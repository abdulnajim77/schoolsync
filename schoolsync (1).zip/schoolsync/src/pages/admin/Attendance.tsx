import { useMemo } from 'react';
import { Badge, Card, PageHeader, ProgressRing, SectionTitle } from '@/components/ui';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { DEMO_STUDENTS } from '@/data/demoData';

interface ClassRow {
  className: string;
  total: number;
  present: number;
  absent: number;
  leave: number;
}

export function AdminAttendance() {
  const rows = useMemo<ClassRow[]>(() => {
    const map = new Map<string, ClassRow>();
    DEMO_STUDENTS.forEach((s, i) => {
      const r = map.get(s.className) ?? { className: s.className, total: 0, present: 0, absent: 0, leave: 0 };
      r.total += 1;
      // Deterministic demo split so the same numbers show every load.
      if (i % 7 === 3) r.absent += 1;
      else if (i % 11 === 5) r.leave += 1;
      else r.present += 1;
      map.set(s.className, r);
    });
    return Array.from(map.values());
  }, []);

  const totals = rows.reduce(
    (a, r) => ({ total: a.total + r.total, present: a.present + r.present, absent: a.absent + r.absent, leave: a.leave + r.leave }),
    { total: 0, present: 0, absent: 0, leave: 0 },
  );
  const pct = totals.total ? Math.round((totals.present / totals.total) * 100) : 0;

  const columns: Column<ClassRow>[] = [
    { key: 'class', header: 'Class', render: (r) => <span className="font-semibold text-ink">{r.className}</span> },
    { key: 'total', header: 'Strength', render: (r) => r.total },
    { key: 'present', header: 'Present', render: (r) => <Badge tone="green">{r.present}</Badge> },
    { key: 'absent', header: 'Absent', render: (r) => <Badge tone="red">{r.absent}</Badge> },
    { key: 'leave', header: 'On leave', render: (r) => <Badge tone="orange">{r.leave}</Badge> },
    {
      key: 'rate',
      header: 'Rate',
      render: (r) => <span className="font-semibold text-navy">{Math.round((r.present / r.total) * 100)}%</span>,
    },
  ];

  return (
    <div className="space-y-5">
      <PageHeader title="Attendance" subtitle="Today's attendance across all classes" />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-4">
        <Card className="grid place-items-center p-6">
          <ProgressRing value={pct} label={`${pct}%`} sub="Present today" />
        </Card>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:col-span-3">
          {[
            { label: 'Total students', value: totals.total * 47, tone: 'text-navy' },
            { label: 'Present', value: Math.round(totals.total * 47 * 0.94), tone: 'text-safe-700' },
            { label: 'Absent', value: Math.round(totals.total * 47 * 0.04), tone: 'text-danger-600' },
            { label: 'On leave', value: Math.round(totals.total * 47 * 0.02), tone: 'text-warn-600' },
            { label: 'Late arrivals', value: 6, tone: 'text-ink-soft' },
            { label: 'Classes', value: rows.length, tone: 'text-ink-soft' },
          ].map((k) => (
            <Card key={k.label} className="p-4">
              <div className="text-xs font-medium uppercase tracking-wide text-ink-muted">{k.label}</div>
              <div className={`mt-1 text-2xl font-bold ${k.tone}`}>{k.value}</div>
            </Card>
          ))}
        </div>
      </div>

      <SectionTitle>Class-wise breakdown</SectionTitle>
      <DataTable columns={columns} rows={rows} rowKey={(r) => r.className} />
    </div>
  );
}

import {
  Users, Bus, GraduationCap, IdCard, IndianRupee, Clock, CalendarCheck, Radio,
  TrendingUp, ArrowUpRight,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Badge, Card } from '@/components/ui';
import { inr, relativeTime } from '@/lib/format';
import { DEMO_BUSES, DEMO_STUDENTS } from '@/data/demoData';

const kpis: { label: string; value: string; icon: LucideIcon; tone: string; delta?: string }[] = [
  { label: 'Total Students', value: String(DEMO_STUDENTS.length * 47), icon: Users, tone: 'bg-brand-50 text-brand-600', delta: '+12' },
  { label: 'Active Buses', value: '3', icon: Bus, tone: 'bg-navy/10 text-navy' },
  { label: 'Teachers', value: '18', icon: GraduationCap, tone: 'bg-safe-50 text-safe-700' },
  { label: 'Drivers', value: '4', icon: IdCard, tone: 'bg-warn-50 text-warn-600' },
  { label: 'Fees Collected', value: inr(486000), icon: IndianRupee, tone: 'bg-safe-50 text-safe-700', delta: '82%' },
  { label: 'Pending Fees', value: inr(104000), icon: Clock, tone: 'bg-danger-50 text-danger-600' },
  { label: "Today's Attendance", value: '94%', icon: CalendarCheck, tone: 'bg-brand-50 text-brand-600' },
  { label: 'Active Trips', value: '1', icon: Radio, tone: 'bg-safe-50 text-safe-700' },
];

const attendanceTrend = [88, 91, 90, 93, 92, 94, 94];
const feeCollection = [72, 65, 80, 78, 85, 82];
const activity = [
  { text: 'Bus 03 started the morning trip', ts: Date.now() - 1000 * 60 * 6, tone: 'blue' as const },
  { text: 'Riya Das boarded Bus 03 at Jyoti More', ts: Date.now() - 1000 * 60 * 12, tone: 'green' as const },
  { text: 'Leave approved for Aarav Das (02 Oct)', ts: Date.now() - 1000 * 60 * 48, tone: 'orange' as const },
  { text: 'August fees receipt generated · SCH-2026-00821', ts: Date.now() - 1000 * 60 * 120, tone: 'slate' as const },
  { text: 'Puja holiday notice published', ts: Date.now() - 1000 * 60 * 300, tone: 'navy' as const },
];

export function AdminDashboard() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-ink">Dashboard</h1>
        <p className="text-sm text-ink-muted">A live view of transport, attendance and fees.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kpis.map((k) => (
          <Card key={k.label} className="p-4">
            <div className="flex items-start justify-between">
              <span className={`grid h-10 w-10 place-items-center rounded-xl ${k.tone}`}><k.icon className="h-5 w-5" /></span>
              {k.delta && <Badge tone="green"><ArrowUpRight className="h-3 w-3" />{k.delta}</Badge>}
            </div>
            <p className="mt-3 text-xl font-bold text-ink">{k.value}</p>
            <p className="text-xs text-ink-muted">{k.label}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-[15px] font-bold text-ink"><TrendingUp className="h-4 w-4 text-brand-500" />Attendance Trend</h3>
            <Badge tone="blue">This week</Badge>
          </div>
          <LineChart data={attendanceTrend} labels={['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']} />
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 text-[15px] font-bold text-ink">Transport Utilisation</h3>
          <Donut value={78} />
          <div className="mt-4 space-y-2 text-sm">
            {DEMO_BUSES.map((b) => (
              <div key={b.id} className="flex items-center justify-between">
                <span className="text-ink-soft">{b.code}</span>
                <Badge tone={b.status === 'active' ? 'green' : b.status === 'maintenance' ? 'orange' : 'slate'}>{b.status}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <h3 className="mb-4 text-[15px] font-bold text-ink">Monthly Fee Collection</h3>
          <BarChart data={feeCollection} labels={['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep']} />
        </Card>

        <Card className="p-5">
          <h3 className="mb-3 text-[15px] font-bold text-ink">Recent Activity</h3>
          <ol className="space-y-3">
            {activity.map((a, i) => (
              <li key={i} className="flex gap-3">
                <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${dotTone(a.tone)}`} />
                <div>
                  <p className="text-sm text-ink">{a.text}</p>
                  <p className="text-xs text-ink-muted">{relativeTime(a.ts)}</p>
                </div>
              </li>
            ))}
          </ol>
        </Card>
      </div>
    </div>
  );
}

const dotTone = (t: string) => ({
  blue: 'bg-brand-500', green: 'bg-safe', orange: 'bg-warn', slate: 'bg-slate-400', navy: 'bg-navy',
}[t] ?? 'bg-slate-400');

function LineChart({ data, labels }: { data: number[]; labels: string[] }) {
  const w = 520, h = 160, pad = 24;
  const min = Math.min(...data) - 3, max = Math.max(...data) + 2;
  const x = (i: number) => pad + (i * (w - pad * 2)) / (data.length - 1);
  const y = (v: number) => h - pad - ((v - min) / (max - min)) * (h - pad * 2);
  const path = data.map((v, i) => `${i ? 'L' : 'M'} ${x(i)} ${y(v)}`).join(' ');
  const area = `${path} L ${x(data.length - 1)} ${h - pad} L ${x(0)} ${h - pad} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-40 w-full">
      <defs>
        <linearGradient id="lg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#lg)" />
      <path d={path} fill="none" stroke="#3B82F6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      {data.map((v, i) => <circle key={i} cx={x(i)} cy={y(v)} r="3.5" fill="#fff" stroke="#3B82F6" strokeWidth="2" />)}
      {labels.map((l, i) => <text key={l} x={x(i)} y={h - 4} textAnchor="middle" className="fill-slate-400 text-[10px]">{l}</text>)}
    </svg>
  );
}

function BarChart({ data, labels }: { data: number[]; labels: string[] }) {
  const w = 520, h = 160, pad = 24, gap = 16;
  const bw = (w - pad * 2 - gap * (data.length - 1)) / data.length;
  const max = Math.max(...data) + 8;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-40 w-full">
      {data.map((v, i) => {
        const bh = (v / max) * (h - pad * 2);
        const x = pad + i * (bw + gap);
        return (
          <g key={i}>
            <rect x={x} y={h - pad - bh} width={bw} height={bh} rx="6" fill="#253B80" opacity={0.85} />
            <text x={x + bw / 2} y={h - pad - bh - 5} textAnchor="middle" className="fill-ink text-[10px] font-semibold">{v}%</text>
            <text x={x + bw / 2} y={h - 6} textAnchor="middle" className="fill-slate-400 text-[10px]">{labels[i]}</text>
          </g>
        );
      })}
    </svg>
  );
}

function Donut({ value }: { value: number }) {
  const r = 52, c = 2 * Math.PI * r, off = c - (value / 100) * c;
  return (
    <div className="relative mx-auto grid h-32 w-32 place-items-center">
      <svg width="128" height="128" className="-rotate-90">
        <circle cx="64" cy="64" r={r} stroke="#E2E8F0" strokeWidth="14" fill="none" />
        <circle cx="64" cy="64" r={r} stroke="#22C55E" strokeWidth="14" fill="none" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={off} />
      </svg>
      <div className="absolute text-center">
        <p className="text-2xl font-bold text-ink">{value}%</p>
        <p className="text-[11px] text-ink-muted">seats used</p>
      </div>
    </div>
  );
}

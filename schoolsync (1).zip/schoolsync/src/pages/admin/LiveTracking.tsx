import { useState } from 'react';
import { Bus, Play, Gauge, MapPin, Users, Radio } from 'lucide-react';
import type { MapMarker } from '@/components/transport/LiveMap';
import { LiveMap } from '@/components/transport/LiveMap';
import { Badge, Button, Card, PageHeader, StatusChip } from '@/components/ui';
import { cn } from '@/lib/cn';
import { clockTimeSec, metres } from '@/lib/format';
import { useTrip } from '@/state/TripContext';
import { DEMO_BUSES, DEMO_DRIVERS, DEMO_ROUTE, DEMO_SCHOOL } from '@/data/demoData';

const staticFleet = [
  { id: 'bus_01', status: 'At School', tone: 'green' as const, students: 22, speed: 0 },
  { id: 'bus_02', status: 'Trip Completed', tone: 'slate' as const, students: 0, speed: 0 },
];

export function AdminLiveTracking() {
  const { trip, students, startTrip } = useTrip();
  const [selected, setSelected] = useState('bus_03');
  const running = trip.status !== 'NOT_STARTED' && trip.status !== 'COMPLETED';
  const onboard = students.filter((s) => s.transportStatus === 'BOARDED').length;

  const markers: MapMarker[] = [
    { id: 'bus_03', pos: { lat: trip.currentLatitude, lng: trip.currentLongitude }, kind: 'bus', label: 'Bus 03' },
    { id: 'school', pos: DEMO_SCHOOL.location, kind: 'school', label: 'School' },
  ];

  const sel = DEMO_BUSES.find((b) => b.id === selected) ?? DEMO_BUSES[0];
  const selDriver = DEMO_DRIVERS.find((d) => d.id === sel.driverId) ?? DEMO_DRIVERS[0];
  const selStatic = staticFleet.find((s) => s.id === selected);

  return (
    <div className="space-y-4">
      <PageHeader title="Live Tracking" subtitle="All buses across your school" icon={Radio}
        action={!running && <Button variant="primary" size="sm" icon={Play} onClick={() => startTrip('morning')}>Start Bus 03</Button>} />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          <LiveMap markers={markers} route={DEMO_ROUTE.stops.map((s) => ({ lat: s.lat, lng: s.lng }))}
            heading={trip.heading} className="h-72 w-full sm:h-[420px]" />
        </Card>

        <div className="space-y-3">
          {/* Live bus */}
          <FleetRow
            code="Bus 03" driver="Sanjay Das" active={selected === 'bus_03'}
            statusNode={running ? <StatusChip status={trip.status} /> : <Badge tone="slate" dot>Idle</Badge>}
            onClick={() => setSelected('bus_03')}
          />
          {staticFleet.map((f) => {
            const b = DEMO_BUSES.find((x) => x.id === f.id)!;
            return (
              <FleetRow key={f.id} code={b.code} driver={DEMO_DRIVERS.find((d) => d.id === b.driverId)?.name ?? '—'}
                active={selected === f.id} statusNode={<Badge tone={f.tone} dot>{f.status}</Badge>}
                onClick={() => setSelected(f.id)} />
            );
          })}
        </div>
      </div>

      {/* Detail */}
      <Card className="p-5">
        <div className="mb-4 flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-navy text-white"><Bus className="h-5 w-5" /></span>
          <div>
            <p className="font-bold text-ink">{sel.code} · {sel.vehicleNumber}</p>
            <p className="text-xs text-ink-muted">{selDriver.name} · {DEMO_ROUTE.name}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Detail icon={Gauge} label="Speed" value={selected === 'bus_03' && running ? `${trip.speed} km/h` : `${selStatic?.speed ?? 0} km/h`} />
          <Detail icon={Users} label="Onboard" value={String(selected === 'bus_03' ? onboard : selStatic?.students ?? 0)} />
          <Detail icon={MapPin} label="Last GPS" value={selected === 'bus_03' && running ? metres(0) + ' ago' : '—'} />
          <Detail icon={Radio} label="Updated" value={selected === 'bus_03' ? clockTimeSec(trip.lastUpdated) : '—'} />
        </div>
      </Card>
    </div>
  );
}

function FleetRow({ code, driver, statusNode, active, onClick }: {
  code: string; driver: string; statusNode: React.ReactNode; active: boolean; onClick: () => void;
}) {
  return (
    <button onClick={onClick} className={cn('flex w-full items-center justify-between gap-3 rounded-2xl border bg-white p-3.5 text-left shadow-card transition hover:shadow-card-hover',
      active ? 'border-navy ring-1 ring-navy/20' : 'border-slate-100')}>
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy/10 text-navy"><Bus className="h-4.5 w-4.5" /></span>
        <div>
          <p className="text-sm font-bold text-ink">{code}</p>
          <p className="text-xs text-ink-muted">{driver}</p>
        </div>
      </div>
      {statusNode}
    </button>
  );
}

function Detail({ icon: Icon, label, value }: { icon: typeof Gauge; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-canvas px-3 py-2.5">
      <p className="flex items-center gap-1 text-[11px] uppercase tracking-wide text-ink-muted"><Icon className="h-3.5 w-3.5" />{label}</p>
      <p className="mt-0.5 text-sm font-bold text-ink">{value}</p>
    </div>
  );
}

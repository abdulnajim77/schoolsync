import { Plus, Megaphone } from 'lucide-react';
import type { NotificationPriority } from '@/types';
import { Badge, Button, Card, PageHeader } from '@/components/ui';
import { DEMO_NOTICES } from '@/data/demoData';
import { shortDate } from '@/lib/format';

const PRIORITY_TONE: Record<NotificationPriority, 'slate' | 'blue' | 'orange' | 'red'> = {
  INFO: 'blue',
  IMPORTANT: 'orange',
  SAFETY: 'orange',
  EMERGENCY: 'red',
};

export function AdminNotices() {
  return (
    <div className="space-y-5">
      <PageHeader
        title="Notices"
        subtitle={`${DEMO_NOTICES.length} published announcements`}
        action={<Button icon={Plus}>Post Notice</Button>}
      />

      <div className="space-y-3">
        {DEMO_NOTICES.map((n) => (
          <Card key={n.id} className="p-5">
            <div className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-navy/10 text-navy">
                <Megaphone className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-bold text-ink">{n.title}</h3>
                  <Badge tone={PRIORITY_TONE[n.priority]}>{n.priority}</Badge>
                </div>
                <p className="mt-1 text-sm text-ink-soft">{n.body}</p>
                <div className="mt-2 text-xs text-ink-muted">Published {shortDate(n.date)}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

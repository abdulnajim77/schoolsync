import { useMemo } from 'react';
import { Download } from 'lucide-react';
import { Avatar, Badge, Button, Card, PageHeader, SectionTitle, StatusChip } from '@/components/ui';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { DEMO_STUDENTS } from '@/data/demoData';
import { inr } from '@/lib/format';

interface FeeRow {
  id: string;
  name: string;
  className: string;
  annual: number;
  paid: number;
  status: 'paid' | 'pending' | 'overdue';
}

export function AdminFees() {
  const rows = useMemo<FeeRow[]>(
    () =>
      DEMO_STUDENTS.map((s, i) => {
        const annual = 30000;
        const paidMonths = [12, 11, 10, 9, 8][i % 5];
        const paid = Math.round((annual / 12) * paidMonths);
        const status: FeeRow['status'] = paidMonths >= 11 ? 'paid' : paidMonths >= 9 ? 'pending' : 'overdue';
        return { id: s.id, name: `${s.firstName} ${s.lastName}`, className: `${s.className} — ${s.section}`, annual, paid, status };
      }),
    [],
  );

  const collected = 486000;
  const pending = 104000;
  const target = collected + pending;

  const columns: Column<FeeRow>[] = [
    {
      key: 'name',
      header: 'Student',
      render: (r) => (
        <div className="flex items-center gap-3">
          <Avatar name={r.name} size={34} />
          <div>
            <div className="font-semibold text-ink">{r.name}</div>
            <div className="text-xs text-ink-muted">{r.className}</div>
          </div>
        </div>
      ),
    },
    { key: 'annual', header: 'Annual', render: (r) => inr(r.annual) },
    { key: 'paid', header: 'Paid', render: (r) => <span className="text-safe-700">{inr(r.paid)}</span> },
    { key: 'due', header: 'Due', render: (r) => <span className="text-danger-600">{inr(r.annual - r.paid)}</span> },
    { key: 'status', header: 'Status', render: (r) => <StatusChip status={r.status} /> },
  ];

  return (
    <div className="space-y-5">
      <PageHeader
        title="Fees"
        subtitle={`${Math.round((collected / target) * 100)}% of annual target collected`}
        action={<Button variant="outline" icon={Download}>Export</Button>}
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <div className="text-xs font-medium uppercase tracking-wide text-ink-muted">Collected</div>
          <div className="mt-1 text-2xl font-bold text-safe-700">{inr(collected)}</div>
        </Card>
        <Card className="p-5">
          <div className="text-xs font-medium uppercase tracking-wide text-ink-muted">Pending</div>
          <div className="mt-1 text-2xl font-bold text-danger-600">{inr(pending)}</div>
        </Card>
        <Card className="p-5">
          <div className="text-xs font-medium uppercase tracking-wide text-ink-muted">Annual target</div>
          <div className="mt-1 text-2xl font-bold text-navy">{inr(target)}</div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-safe" style={{ width: `${(collected / target) * 100}%` }} />
          </div>
        </Card>
      </div>

      <SectionTitle action={<Badge tone="orange">{rows.filter((r) => r.status !== 'paid').length} with dues</Badge>}>
        Student fee status
      </SectionTitle>
      <DataTable columns={columns} rows={rows} rowKey={(r) => r.id} />
    </div>
  );
}

import { useMemo, useState } from 'react';
import { Check, X, CalendarOff } from 'lucide-react';
import type { LeaveRequest } from '@/types';
import { Avatar, Badge, Button, Card, PageHeader, StatusChip, EmptyState } from '@/components/ui';
import { Tabs } from '@/components/ui/Overlay';
import { useNotifications } from '@/state/NotificationContext';
import { demoDb } from '@/data/demoDb';
import { DEMO_STUDENTS } from '@/data/demoData';
import { shortDate } from '@/lib/format';

type Filter = 'pending' | 'approved' | 'rejected';

const studentName = (id: string) => {
  const s = DEMO_STUDENTS.find((x) => x.id === id);
  return s ? `${s.firstName} ${s.lastName}` : 'Student';
};
const studentStop = (id: string) => DEMO_STUDENTS.find((x) => x.id === id)?.pickup.name ?? '';

export function AdminLeave() {
  const { push } = useNotifications();
  const [leave, setLeave] = useState<LeaveRequest[]>(() => demoDb.getLeave());
  const [tab, setTab] = useState<Filter>('pending');

  const counts = useMemo(
    () => ({
      pending: leave.filter((l) => l.status === 'pending').length,
      approved: leave.filter((l) => l.status === 'approved').length,
      rejected: leave.filter((l) => l.status === 'rejected').length,
    }),
    [leave],
  );

  const rows = leave.filter((l) => l.status === tab);

  const decide = (l: LeaveRequest, status: 'approved' | 'rejected') => {
    setLeave(demoDb.setLeaveStatus(l.id, status));
    const name = studentName(l.studentId);
    if (status === 'approved') {
      push({
        title: 'Leave approved',
        body: `${name}'s leave for ${shortDate(l.fromDate)} is approved. Bus pickup will be skipped.`,
        category: 'Safety',
        priority: 'SAFETY',
      });
      push({
        title: 'Driver notified',
        body: `${name} (${studentStop(l.studentId)}) is on approved leave. Do not stop for pickup.`,
        category: 'Transport',
        priority: 'IMPORTANT',
      });
    } else {
      push({
        title: 'Leave rejected',
        body: `${name}'s leave request was not approved.`,
        category: 'Academic',
        priority: 'INFO',
      });
    }
  };

  return (
    <div className="space-y-5">
      <PageHeader title="Leave Requests" subtitle="Approvals automatically update transport" />

      <Tabs<Filter>
        tabs={[
          { key: 'pending', label: 'Pending', count: counts.pending },
          { key: 'approved', label: 'Approved', count: counts.approved },
          { key: 'rejected', label: 'Rejected', count: counts.rejected },
        ]}
        value={tab}
        onChange={setTab}
      />

      {rows.length === 0 ? (
        <EmptyState icon={CalendarOff} title={`No ${tab} requests`} hint="New parent leave requests will appear here." />
      ) : (
        <div className="space-y-3">
          {rows.map((l) => (
            <Card key={l.id} className="p-4">
              <div className="flex flex-wrap items-center gap-4">
                <Avatar name={studentName(l.studentId)} size={44} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-ink">{studentName(l.studentId)}</span>
                    <Badge tone="slate">{studentStop(l.studentId)}</Badge>
                  </div>
                  <p className="text-sm text-ink-soft">{l.reason}</p>
                  <p className="text-xs text-ink-muted">
                    {shortDate(l.fromDate)}{l.toDate !== l.fromDate ? ` → ${shortDate(l.toDate)}` : ''}
                  </p>
                </div>
                {l.status === 'pending' ? (
                  <div className="flex gap-2">
                    <Button size="sm" variant="safe" icon={Check} onClick={() => decide(l, 'approved')}>
                      Approve
                    </Button>
                    <Button size="sm" variant="danger" icon={X} onClick={() => decide(l, 'rejected')}>
                      Reject
                    </Button>
                  </div>
                ) : (
                  <StatusChip status={l.status} />
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

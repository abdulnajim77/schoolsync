// ---------------------------------------------------------------------------
// Auth service — one interface, two implementations chosen by APP_MODE.
// Demo: validates against DEMO_ACCOUNTS + localStorage session.
// Production: Firebase Auth + a /users/{uid} profile document.
// ---------------------------------------------------------------------------
import type { AppUser, Role } from '@/types';
import { IS_DEMO } from '@/config/env';
import { DEMO_ACCOUNTS, demoDb } from '@/data/demoDb';

export interface SignInInput {
  email: string;
  password: string;
  role: Role;
}

const stripPassword = ({ password: _pw, ...user }: (typeof DEMO_ACCOUNTS)[number]): AppUser => user;

async function demoSignIn({ email, password, role }: SignInInput): Promise<AppUser> {
  await new Promise((r) => setTimeout(r, 450)); // feel like a network call
  const found = DEMO_ACCOUNTS.find(
    (a) => a.email.toLowerCase() === email.trim().toLowerCase() && a.password === password,
  );
  if (!found) throw new Error('Incorrect email or password.');
  if (found.role !== role)
    throw new Error(`This account is a ${found.role} account. Choose "${found.role}" and try again.`);
  const user = stripPassword(found);
  demoDb.setSession(user);
  return user;
}

async function prodSignIn({ email, password }: SignInInput): Promise<AppUser> {
  const { auth, db } = await import('@/config/firebase');
  const { signInWithEmailAndPassword } = await import('firebase/auth');
  const { doc, getDoc } = await import('firebase/firestore');
  if (!auth || !db) throw new Error('Firebase is not configured. Check your .env values.');
  const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
  const snap = await getDoc(doc(db, 'users', cred.user.uid));
  if (!snap.exists()) throw new Error('No SchoolSync profile is linked to this account.');
  return { uid: cred.user.uid, ...(snap.data() as Omit<AppUser, 'uid'>) };
}

export const authService = {
  signIn: (input: SignInInput): Promise<AppUser> => (IS_DEMO ? demoSignIn(input) : prodSignIn(input)),

  async signOut(): Promise<void> {
    if (IS_DEMO) {
      demoDb.setSession(null);
      return;
    }
    const { auth } = await import('@/config/firebase');
    const { signOut } = await import('firebase/auth');
    if (auth) await signOut(auth);
  },

  async restore(): Promise<AppUser | null> {
    if (IS_DEMO) return demoDb.getSession();
    // Production restore is handled by AuthContext via onAuthStateChanged.
    return null;
  },
};

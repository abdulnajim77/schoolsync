import { Bus, Navigation, Phone, MapPin, Clock, Gauge } from 'lucide-react';
import type { Student } from '@/types';
import { Badge, Button, StatusChip } from '@/components/ui';
import { RouteProgress } from './Timelines';
import { useTrip } from '@/state/TripContext';
import { DEMO_BUSES, DEMO_DRIVERS, DEMO_ROUTE } from '@/data/demoData';
import { etaClock, etaMinutes } from '@/lib/geo';
import { metres } from '@/lib/format';

/**
 * The single most important card in the parent experience: bus identity,
 * live status, distance to the child's stop, ETA, and route progress.
 */
export function BusStatusCard({ student, onTrack, onCall }: {
  student: Student;
  onTrack: () => void;
  onCall: () => void;
}) {
  const { trip, distanceToStudentStop } = useTrip();
  const bus = DEMO_BUSES.find((b) => b.id === student.busId) ?? DEMO_BUSES[0];
  const driver = DEMO_DRIVERS.find((d) => d.id === bus.driverId) ?? DEMO_DRIVERS[0];

  const running = trip.status !== 'NOT_STARTED' && trip.status !== 'COMPLETED';
  const dist = distanceToStudentStop(student.id);
  const zone = trip.tripType === 'morning' ? student.pickup : student.drop;
  const currentStop = DEMO_ROUTE.stops[Math.min(trip.nextStopIndex, DEMO_ROUTE.stops.length - 1)];

  return (
    <div className="overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-card">
      {/* Header band */}
      <div className="relative bg-gradient-to-br from-navy to-navy-600 px-5 py-4 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/15">
              <Bus className="h-6 w-6" />
            </span>
            <div>
              <p className="text-xs font-medium text-white/70">School Bus</p>
              <p className="text-lg font-bold leading-tight">{bus.code} · {bus.vehicleNumber}</p>
            </div>
          </div>
          {running ? <StatusChip status={trip.status} /> : <Badge tone="slate" dot>Not started</Badge>}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
          <Meta label="Driver" value={driver.name} />
          <Meta label="Helper" value={bus.helperName} />
          <Meta label="Route" value={DEMO_ROUTE.name} />
          <Meta label="Trip" value={trip.tripType === 'morning' ? 'Morning Pickup' : 'Afternoon Drop'} />
        </div>
      </div>

      {/* Live metrics */}
      <div className="grid grid-cols-3 divide-x divide-slate-100 border-b border-slate-100">
        <Stat icon={MapPin} label="Distance" value={running ? metres(dist) : '—'} />
        <Stat icon={Clock} label="ETA" value={running ? `${etaMinutes(dist, trip.speed)} min` : '—'} />
        <Stat icon={Gauge} label="Speed" value={running ? `${trip.speed} km/h` : '—'} />
      </div>

      <div className="px-5 py-4">
        <div className="mb-4 flex items-center justify-between rounded-2xl bg-canvas px-4 py-3">
          <div>
            <p className="text-xs text-ink-muted">Current location</p>
            <p className="text-sm font-semibold text-ink">{running ? currentStop.name : 'Bus depot'}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-ink-muted">Your stop · {zone.name}</p>
            <p className="text-sm font-semibold text-navy">
              {running ? `Arriving ~ ${etaClock(dist, trip.speed)}` : zone.name}
            </p>
          </div>
        </div>

        <RouteProgress
          stops={DEMO_ROUTE.stops}
          currentIndex={running ? trip.nextStopIndex : -1}
          highlightStopId={
            DEMO_ROUTE.stops.find((s) => s.name === student.pickup.name)?.id
          }
        />

        <div className="mt-4 flex gap-2">
          <Button variant="primary" icon={Navigation} block onClick={onTrack}>Track live bus</Button>
          <Button variant="outline" icon={Phone} onClick={onCall}>Call driver</Button>
        </div>
      </div>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[11px] uppercase tracking-wide text-white/60">{label}</p>
      <p className="font-semibold">{value}</p>
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof MapPin; label: string; value: string }) {
  return (
    <div className="flex flex-col items-center gap-1 py-3">
      <span className="flex items-center gap-1 text-[11px] font-medium uppercase tracking-wide text-ink-muted">
        <Icon className="h-3.5 w-3.5" />{label}
      </span>
      <span className="text-base font-bold text-ink">{value}</span>
    </div>
  );
}

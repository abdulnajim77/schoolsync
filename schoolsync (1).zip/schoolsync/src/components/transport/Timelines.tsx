import type { LucideIcon } from 'lucide-react';
import { Check, Circle } from 'lucide-react';
import { cn } from '@/lib/cn';
import { clockTime } from '@/lib/format';
import type { GeofenceEvent, RouteStop } from '@/types';

/* Vertical route with the current bus position highlighted. */
export function RouteProgress({ stops, currentIndex, highlightStopId }: {
  stops: RouteStop[]; currentIndex: number; highlightStopId?: string;
}) {
  return (
    <ol className="relative ml-1">
      {stops.map((s, i) => {
        const done = i < currentIndex;
        const here = i === currentIndex;
        const isTarget = s.id === highlightStopId;
        return (
          <li key={s.id} className="relative flex gap-3 pb-5 last:pb-0">
            {i < stops.length - 1 && (
              <span className={cn('absolute left-[9px] top-6 h-[calc(100%-12px)] w-0.5',
                done ? 'bg-safe' : 'bg-slate-200')} />
            )}
            <span className={cn('z-10 mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full border-2',
              done ? 'border-safe bg-safe text-white'
                : here ? 'border-brand-500 bg-white'
                : 'border-slate-300 bg-white')}>
              {done ? <Check className="h-3 w-3" /> : here ? <span className="h-2 w-2 rounded-full bg-brand-500 animate-pulse" /> : <span className="h-1.5 w-1.5 rounded-full bg-slate-300" />}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className={cn('truncate text-sm font-semibold', here ? 'text-brand-600' : isTarget ? 'text-navy' : 'text-ink')}>
                  {s.name}{isTarget && <span className="ml-1.5 rounded bg-navy/10 px-1.5 py-0.5 text-[10px] font-bold text-navy">YOUR STOP</span>}
                </p>
                <span className="shrink-0 text-xs text-ink-muted">{s.expectedTime}</span>
              </div>
              {here && <p className="mt-0.5 text-xs font-medium text-brand-500">Bus is here now</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

/* Live event feed from the geofence engine. */
export function TripTimeline({ events }: { events: GeofenceEvent[] }) {
  if (!events.length)
    return <p className="py-6 text-center text-sm text-ink-muted">No trip events yet. Start a trip to see live activity.</p>;
  return (
    <ol className="space-y-3">
      {events.map((e) => (
        <li key={e.id} className="flex gap-3">
          <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-brand-400" />
          <div className="flex-1">
            <p className="text-sm text-ink">{e.eventType}</p>
            <p className="text-xs text-ink-muted">{clockTime(e.timestamp)}</p>
          </div>
        </li>
      ))}
    </ol>
  );
}

export interface SafetyStep {
  label: string;
  time?: string;
  icon: LucideIcon;
  state: 'done' | 'active' | 'todo';
}

export function SafetyTimeline({ steps }: { steps: SafetyStep[] }) {
  return (
    <ol className="grid gap-1">
      {steps.map((s, i) => {
        const Icon = s.state === 'done' ? Check : s.state === 'active' ? s.icon : Circle;
        return (
          <li key={i} className="flex items-center gap-3 rounded-xl px-2 py-2">
            <span className={cn('grid h-8 w-8 shrink-0 place-items-center rounded-full',
              s.state === 'done' ? 'bg-safe text-white'
                : s.state === 'active' ? 'bg-brand-500 text-white ring-4 ring-brand-100'
                : 'bg-slate-100 text-slate-400')}>
              <Icon className="h-4 w-4" />
            </span>
            <span className={cn('flex-1 text-sm font-medium', s.state === 'todo' ? 'text-slate-400' : 'text-ink')}>
              {s.label}
            </span>
            {s.time && <span className="text-xs text-ink-muted">{s.time}</span>}
          </li>
        );
      })}
    </ol>
  );
}

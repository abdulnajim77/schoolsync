import { useEffect, useMemo, useRef } from 'react';
import { Bus, Flag, Home, MapPin, School } from 'lucide-react';
import type { LatLng } from '@/types';
import { DEMO_ROUTE, DEMO_SCHOOL } from '@/data/demoData';
import { GOOGLE_MAPS_API_KEY, hasMapsKey } from '@/config/env';
import { cn } from '@/lib/cn';

export interface MapMarker {
  id: string;
  pos: LatLng;
  kind: 'bus' | 'school' | 'pickup' | 'drop' | 'stop';
  label?: string;
  active?: boolean;
}

interface Props {
  markers: MapMarker[];
  route?: LatLng[];
  heading?: number;
  className?: string;
}

/* ------- Coordinate projection for the SVG fallback map ------------------- */
const VB = { w: 800, h: 520, pad: 70 };
function useProjector(points: LatLng[]) {
  return useMemo(() => {
    const all = points.length ? points : [DEMO_SCHOOL.location];
    const lats = all.map((p) => p.lat);
    const lngs = all.map((p) => p.lng);
    let minLat = Math.min(...lats), maxLat = Math.max(...lats);
    let minLng = Math.min(...lngs), maxLng = Math.max(...lngs);
    if (maxLat - minLat < 0.004) { minLat -= 0.002; maxLat += 0.002; }
    if (maxLng - minLng < 0.004) { minLng -= 0.002; maxLng += 0.002; }
    const sx = (VB.w - VB.pad * 2) / (maxLng - minLng);
    const sy = (VB.h - VB.pad * 2) / (maxLat - minLat);
    return (p: LatLng) => ({
      x: VB.pad + (p.lng - minLng) * sx,
      y: VB.h - VB.pad - (p.lat - minLat) * sy, // invert Y (north = up)
    });
  }, [points]);
}

const KIND_ICON = { bus: Bus, school: School, pickup: MapPin, drop: Home, stop: Flag } as const;

function SvgMap({ markers, route, heading = 0, className }: Props) {
  const routePts = route ?? DEMO_ROUTE.stops.map((s) => ({ lat: s.lat, lng: s.lng }));
  const project = useProjector([...routePts, ...markers.map((m) => m.pos)]);
  const path = routePts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${project(p).x} ${project(p).y}`).join(' ');
  const bus = markers.find((m) => m.kind === 'bus');

  return (
    <div className={cn('relative overflow-hidden rounded-2xl bg-[#EAF0F9]', className)}>
      <svg viewBox={`0 0 ${VB.w} ${VB.h}`} className="h-full w-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M40 0H0V40" fill="none" stroke="#D6E0F0" strokeWidth="1" />
          </pattern>
          <filter id="shadow" x="-40%" y="-40%" width="180%" height="180%">
            <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#172033" floodOpacity="0.2" />
          </filter>
        </defs>
        <rect width={VB.w} height={VB.h} fill="url(#grid)" />
        {/* soft decorative "blocks" */}
        <g opacity="0.5" fill="#DCE6F5">
          <rect x="90" y="70" width="120" height="80" rx="10" />
          <rect x="560" y="120" width="150" height="110" rx="10" />
          <rect x="300" y="330" width="140" height="90" rx="10" />
        </g>

        {/* route casing + line */}
        <path d={path} fill="none" stroke="#B9C7DE" strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" />
        <path d={path} fill="none" stroke="#3B82F6" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"
          strokeDasharray="1 14" className="opacity-90" />

        {/* markers */}
        {markers.map((m) => {
          const { x, y } = project(m.pos);
          if (m.kind === 'bus') return null; // drawn last, on top
          const isSchool = m.kind === 'school';
          const color = isSchool ? '#253B80' : m.kind === 'pickup' ? '#22C55E' : m.kind === 'drop' ? '#F59E0B' : '#64748B';
          const Icon = KIND_ICON[m.kind];
          const s = isSchool ? 12 : 8;
          return (
            <g key={m.id} transform={`translate(${x} ${y})`}>
              <circle r={isSchool ? 15 : 10} fill="#fff" filter="url(#shadow)" />
              <circle r={isSchool ? 11 : 7} fill={color} />
              <Icon x={-s / 2} y={-s / 2} width={s} height={s} stroke="#fff" strokeWidth={2.2} />
              {m.label && (
                <text y={-20} textAnchor="middle" className="fill-ink" fontSize="14" fontWeight="600">{m.label}</text>
              )}
            </g>
          );
        })}

        {/* bus marker with pulse + heading */}
        {bus && (() => {
          const { x, y } = project(bus.pos);
          return (
            <g transform={`translate(${x} ${y})`}>
              <circle r="26" fill="#3B82F6" opacity="0.18" className="animate-pulse-ring" style={{ transformOrigin: 'center' }} />
              <circle r="18" fill="#fff" filter="url(#shadow)" />
              <g transform={`rotate(${heading})`}>
                <path d="M0 -13 L7 6 L0 2 L-7 6 Z" fill="#253B80" opacity="0.35" />
              </g>
              <circle r="13" fill="#253B80" />
              <g transform="translate(-7 -7)" className="text-white">
                <Bus x={0} y={0} width={14} height={14} stroke="#fff" strokeWidth={2.2} />
              </g>
            </g>
          );
        })()}
      </svg>

      <span className="pointer-events-none absolute bottom-2 right-3 rounded-md bg-white/80 px-2 py-0.5 text-[10px] font-medium text-ink-muted backdrop-blur">
        Simulated map · demo mode
      </span>
    </div>
  );
}

/* ------- Google Maps (production) ---------------------------------------- */
let mapsPromise: Promise<void> | null = null;
function loadGoogleMaps(): Promise<void> {
  if (mapsPromise) return mapsPromise;
  mapsPromise = new Promise((resolve, reject) => {
    if ((window as unknown as { google?: unknown }).google) return resolve();
    const s = document.createElement('script');
    s.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=geometry`;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('Failed to load Google Maps'));
    document.head.appendChild(s);
  });
  return mapsPromise;
}

function GoogleMapView({ markers, route, className }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const objs = useRef<{ map?: any; markers: any[]; line?: any }>({ markers: [] });

  useEffect(() => {
    let alive = true;
    loadGoogleMaps().then(() => {
      if (!alive || !ref.current) return;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const g = (window as any).google;
      const map = objs.current.map ?? new g.maps.Map(ref.current, {
        center: DEMO_SCHOOL.location, zoom: 14, disableDefaultUI: true, clickableIcons: false,
      });
      objs.current.map = map;
      objs.current.markers.forEach((m) => m.setMap(null));
      objs.current.markers = markers.map((m) =>
        new g.maps.Marker({ position: m.pos, map, title: m.label,
          label: m.kind === 'bus' ? '🚌' : undefined }));
      if (route) {
        objs.current.line?.setMap(null);
        objs.current.line = new g.maps.Polyline({ path: route, map, strokeColor: '#3B82F6', strokeWeight: 5 });
      }
      const busM = markers.find((m) => m.kind === 'bus');
      if (busM) map.panTo(busM.pos);
    }).catch(() => { /* fall back silently */ });
    return () => { alive = false; };
  }, [markers, route]);

  return <div ref={ref} className={cn('overflow-hidden rounded-2xl bg-slate-100', className)} />;
}

export function LiveMap(props: Props) {
  return hasMapsKey ? <GoogleMapView {...props} /> : <SvgMap {...props} />;
}

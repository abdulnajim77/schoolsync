import { ShieldCheck, TriangleAlert, Bus, Info, X } from 'lucide-react';
import type { AppNotification } from '@/types';
import { cn } from '@/lib/cn';
import { useNotifications } from '@/state/NotificationContext';

const toastLook = (n: AppNotification) => {
  switch (n.priority) {
    case 'EMERGENCY': return { ring: 'border-danger-100 bg-white', icon: TriangleAlert, chip: 'bg-danger text-white' };
    case 'SAFETY': return { ring: 'border-safe-100 bg-white', icon: ShieldCheck, chip: 'bg-safe text-white' };
    case 'IMPORTANT': return { ring: 'border-brand-100 bg-white', icon: Bus, chip: 'bg-brand-500 text-white' };
    default: return { ring: 'border-slate-100 bg-white', icon: Info, chip: 'bg-slate-200 text-ink-soft' };
  }
};

export function ToastHost() {
  const { toasts, clearToast } = useNotifications();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-[60] flex flex-col items-center gap-2 px-3 pt-[calc(0.75rem+var(--safe-top))] sm:items-end sm:pr-5">
      {toasts.map((t) => {
        const look = toastLook(t);
        const Icon = look.icon;
        return (
          <div
            key={t.id}
            className={cn(
              'pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-2xl border p-3.5 shadow-pop animate-slide-up',
              look.ring,
            )}
          >
            <span className={cn('grid h-9 w-9 shrink-0 place-items-center rounded-xl', look.chip)}>
              <Icon className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold text-ink">{t.title}</p>
              <p className="mt-0.5 text-sm text-ink-soft">{t.body}</p>
            </div>
            <button onClick={() => clearToast(t.id)} className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-400 hover:bg-slate-100">
              <X className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

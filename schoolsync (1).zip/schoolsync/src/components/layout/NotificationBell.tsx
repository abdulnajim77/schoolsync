import { useState } from 'react';
import { Bell, X, ShieldCheck, TriangleAlert, Bus, GraduationCap, IndianRupee, Megaphone } from 'lucide-react';
import type { AppNotification, NotificationCategory } from '@/types';
import { cn } from '@/lib/cn';
import { relativeTime } from '@/lib/format';
import { useNotifications } from '@/state/NotificationContext';

const CAT_ICON: Record<NotificationCategory, typeof Bell> = {
  Transport: Bus, Academic: GraduationCap, Fee: IndianRupee,
  Notice: Megaphone, Safety: ShieldCheck, Emergency: TriangleAlert,
};

const priorityStyle = (n: AppNotification) => {
  if (n.priority === 'EMERGENCY') return 'bg-danger-50 text-danger-600';
  if (n.priority === 'SAFETY') return 'bg-safe-50 text-safe-700';
  if (n.priority === 'IMPORTANT') return 'bg-brand-50 text-brand-600';
  return 'bg-slate-100 text-slate-500';
};

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const { items, unread, markAllRead, markRead } = useNotifications();

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="relative grid h-10 w-10 place-items-center rounded-xl text-ink-soft transition hover:bg-slate-100"
        aria-label="Notifications"
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute right-1.5 top-1.5 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-ink/30 backdrop-blur-sm animate-fade-in" onClick={() => setOpen(false)} />
          <aside className="absolute right-0 top-0 flex h-full w-full max-w-sm flex-col bg-white shadow-pop animate-slide-up sm:animate-fade-in">
            <header className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
              <div>
                <h3 className="text-lg font-bold text-ink">Notifications</h3>
                <p className="text-xs text-ink-muted">{unread} unread</p>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={markAllRead} className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-brand-600 hover:bg-brand-50">
                  Mark all read
                </button>
                <button onClick={() => setOpen(false)} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-100">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </header>

            <div className="flex-1 overflow-y-auto scrollbar-slim">
              {items.length === 0 ? (
                <p className="px-5 py-16 text-center text-sm text-ink-muted">You're all caught up.</p>
              ) : (
                <ul className="divide-y divide-slate-50">
                  {items.map((n) => {
                    const Icon = CAT_ICON[n.category];
                    return (
                      <li
                        key={n.id}
                        onClick={() => markRead(n.id)}
                        className={cn('flex cursor-pointer gap-3 px-5 py-3.5 transition hover:bg-slate-50', !n.read && 'bg-brand-50/40')}
                      >
                        <span className={cn('mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl', priorityStyle(n))}>
                          <Icon className="h-4.5 w-4.5" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <p className="truncate text-sm font-semibold text-ink">{n.title}</p>
                            {!n.read && <span className="h-2 w-2 shrink-0 rounded-full bg-brand-500" />}
                          </div>
                          <p className="mt-0.5 text-sm text-ink-soft">{n.body}</p>
                          <p className="mt-1 text-[11px] text-ink-muted">{relativeTime(n.createdAt)}</p>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </aside>
        </div>
      )}
    </>
  );
}

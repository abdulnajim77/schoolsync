import type {
  ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes,
} from 'react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/cn';

/* ------------------------------------------------------------------ Button */
type Variant = 'primary' | 'secondary' | 'ghost' | 'safe' | 'danger' | 'outline';
type Size = 'sm' | 'md' | 'lg' | 'xl';

const variants: Record<Variant, string> = {
  primary: 'bg-navy text-white hover:bg-navy-600 shadow-sm',
  secondary: 'bg-brand-500 text-white hover:bg-brand-600 shadow-sm',
  safe: 'bg-safe text-white hover:bg-safe-600 shadow-sm',
  danger: 'bg-danger text-white hover:bg-danger-600 shadow-sm',
  outline: 'border border-slate-200 bg-white text-ink hover:bg-slate-50',
  ghost: 'text-ink-soft hover:bg-slate-100',
};
const sizes: Record<Size, string> = {
  sm: 'h-9 px-3 text-sm gap-1.5 rounded-lg',
  md: 'h-11 px-4 text-sm gap-2 rounded-xl',
  lg: 'h-12 px-5 text-[15px] gap-2 rounded-xl',
  xl: 'h-14 px-6 text-base gap-2.5 rounded-2xl',
};

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  icon?: LucideIcon;
  iconRight?: LucideIcon;
  loading?: boolean;
  block?: boolean;
}

export function Button({
  variant = 'primary', size = 'md', icon: Icon, iconRight: Right, loading,
  block, className, children, disabled, ...rest
}: ButtonProps) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center font-semibold transition-all duration-150 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none select-none',
        variants[variant], sizes[size], block && 'w-full', className,
      )}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? <Spinner className="h-4 w-4" /> : Icon && <Icon className="h-[1.1em] w-[1.1em]" />}
      {children}
      {Right && !loading && <Right className="h-[1.1em] w-[1.1em]" />}
    </button>
  );
}

/* -------------------------------------------------------------------- Card */
export function Card({ className, children, onClick, interactive }: {
  className?: string; children: ReactNode; onClick?: () => void; interactive?: boolean;
}) {
  return (
    <div
      onClick={onClick}
      className={cn(
        'bg-white rounded-2xl border border-slate-100 shadow-card',
        interactive && 'cursor-pointer transition-shadow hover:shadow-card-hover',
        className,
      )}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------- Badge */
type Tone = 'navy' | 'blue' | 'green' | 'orange' | 'red' | 'slate';
const tones: Record<Tone, string> = {
  navy: 'bg-navy/10 text-navy',
  blue: 'bg-brand-50 text-brand-600',
  green: 'bg-safe-50 text-safe-700',
  orange: 'bg-warn-50 text-warn-600',
  red: 'bg-danger-50 text-danger-600',
  slate: 'bg-slate-100 text-slate-600',
};
export function Badge({ tone = 'slate', children, className, dot }: {
  tone?: Tone; children: ReactNode; className?: string; dot?: boolean;
}) {
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold', tones[tone], className)}>
      {dot && <span className={cn('h-1.5 w-1.5 rounded-full', {
        navy: 'bg-navy', blue: 'bg-brand-500', green: 'bg-safe', orange: 'bg-warn', red: 'bg-danger', slate: 'bg-slate-400',
      }[tone])} />}
      {children}
    </span>
  );
}

/* -------------------------------------------------------------- StatusChip */
const STATUS_TONE: Record<string, Tone> = {
  ON_ROUTE: 'blue', 'On Route': 'blue', EN_ROUTE: 'blue', STARTED: 'blue',
  NORMAL: 'slate', PICKUP_REQUIRED: 'orange', BOARDED: 'green', DROPPED: 'green',
  REACHED_SCHOOL: 'green', AT_SCHOOL: 'green', SCHOOL_LEAVE: 'orange', TRANSPORT_SKIP: 'orange',
  RETURN_STARTED: 'blue', COMPLETED: 'slate', NOT_STARTED: 'slate', Delayed: 'orange',
  active: 'green', maintenance: 'orange', inactive: 'slate', pending: 'orange',
  approved: 'green', rejected: 'red', paid: 'green', overdue: 'red',
};
const label = (s: string) => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
export function StatusChip({ status }: { status: string }) {
  return <Badge tone={STATUS_TONE[status] ?? 'slate'} dot>{label(status)}</Badge>;
}

/* ------------------------------------------------------------------ Avatar */
export function Avatar({ name, src, size = 40, hue = '#253B80' }: {
  name: string; src?: string; size?: number; hue?: string;
}) {
  const initials = name.split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();
  return src ? (
    <img src={src} alt={name} width={size} height={size} className="rounded-full object-cover" style={{ width: size, height: size }} />
  ) : (
    <span
      className="inline-grid place-items-center rounded-full font-semibold text-white"
      style={{ width: size, height: size, background: hue, fontSize: size * 0.38 }}
    >
      {initials}
    </span>
  );
}

/* ------------------------------------------------------------------- Input */
export function Input({ label: lbl, icon: Icon, className, ...rest }: InputHTMLAttributes<HTMLInputElement> & {
  label?: string; icon?: LucideIcon;
}) {
  return (
    <label className="block">
      {lbl && <span className="mb-1.5 block text-sm font-medium text-ink-soft">{lbl}</span>}
      <span className="relative block">
        {Icon && <Icon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />}
        <input
          className={cn(
            'w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-400',
            'transition focus:border-brand-400 focus:ring-2 focus:ring-brand-100 outline-none',
            Icon && 'pl-9', className,
          )}
          {...rest}
        />
      </span>
    </label>
  );
}

export function Select({ label: lbl, className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement> & { label?: string }) {
  return (
    <label className="block">
      {lbl && <span className="mb-1.5 block text-sm font-medium text-ink-soft">{lbl}</span>}
      <select
        className={cn('w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-ink outline-none transition focus:border-brand-400 focus:ring-2 focus:ring-brand-100', className)}
        {...rest}
      >
        {children}
      </select>
    </label>
  );
}

/* --------------------------------------------------------------- feedback */
export function Spinner({ className }: { className?: string }) {
  return (
    <svg className={cn('animate-spin', className)} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" className="opacity-20" />
      <path d="M22 12a10 10 0 0 0-10-10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton', className)} />;
}

export function EmptyState({ icon: Icon, title, hint, action }: {
  icon: LucideIcon; title: string; hint?: string; action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-white/60 px-6 py-12 text-center">
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-400">
        <Icon className="h-6 w-6" />
      </span>
      <p className="mt-3 font-semibold text-ink">{title}</p>
      {hint && <p className="mt-1 max-w-xs text-sm text-ink-muted">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function PageHeader({ title, subtitle, action, icon: Icon }: {
  title: string; subtitle?: string; action?: ReactNode; icon?: LucideIcon;
}) {
  return (
    <div className="mb-5 flex items-start justify-between gap-4">
      <div className="flex items-start gap-3">
        {Icon && (
          <span className="mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-navy/10 text-navy">
            <Icon className="h-5 w-5" />
          </span>
        )}
        <div>
          <h1 className="text-xl font-bold tracking-tight text-ink sm:text-2xl">{title}</h1>
          {subtitle && <p className="mt-0.5 text-sm text-ink-muted">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <h2 className="text-[15px] font-bold text-ink">{children}</h2>
      {action}
    </div>
  );
}

/* -------------------------------------------------------------- ProgressRing */
export function ProgressRing({ value, size = 128, stroke = 12, color = '#22C55E', label: lbl, sub }: {
  value: number; size?: number; stroke?: number; color?: string; label?: string; sub?: string;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const offset = c - (Math.min(100, Math.max(0, value)) / 100) * c;
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#E2E8F0" strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none"
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.6s cubic-bezier(0.16,1,0.3,1)' }} />
      </svg>
      <div className="absolute text-center">
        <div className="text-2xl font-bold text-ink">{lbl ?? `${Math.round(value)}%`}</div>
        {sub && <div className="text-xs text-ink-muted">{sub}</div>}
      </div>
    </div>
  );
}

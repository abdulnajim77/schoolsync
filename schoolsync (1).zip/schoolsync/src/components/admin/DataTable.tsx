import type { ReactNode } from 'react';
import { cn } from '@/lib/cn';

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  /** Extra classes for the cell + header (e.g. alignment, hide-on-mobile). */
  className?: string;
}

/**
 * A light, responsive table used across the admin resource pages. It keeps the
 * markup consistent (sticky header, zebra hover, rounded card frame) so each
 * page only has to describe its columns and rows.
 */
export function DataTable<T>({
  columns,
  rows,
  empty,
  rowKey,
}: {
  columns: Column<T>[];
  rows: T[];
  empty?: ReactNode;
  rowKey: (row: T, index: number) => string;
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-card">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/80 text-left text-xs font-semibold uppercase tracking-wide text-ink-muted">
              {columns.map((c) => (
                <th key={c.key} className={cn('px-4 py-3 font-semibold', c.className)}>
                  {c.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, i) => (
              <tr
                key={rowKey(row, i)}
                className="border-b border-slate-100 transition-colors last:border-0 hover:bg-canvas"
              >
                {columns.map((c) => (
                  <td key={c.key} className={cn('px-4 py-3 align-middle text-ink-soft', c.className)}>
                    {c.render(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {rows.length === 0 && empty ? <div className="p-8">{empty}</div> : null}
    </div>
  );
}

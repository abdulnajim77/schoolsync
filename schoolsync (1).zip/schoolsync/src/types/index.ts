// ---------------------------------------------------------------------------
// SchoolSync — shared domain types
// ---------------------------------------------------------------------------

export type Role = 'admin' | 'parent' | 'driver' | 'teacher';

export interface AppUser {
  uid: string;
  schoolId: string;
  role: Role;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  /** Parent → the students this account is responsible for. */
  childIds?: string[];
  /** Driver → the bus currently assigned. */
  busId?: string;
  /** Teacher → classes they own. */
  classIds?: string[];
}

export interface LatLng {
  lat: number;
  lng: number;
}

export interface School {
  id: string;
  name: string;
  logo?: string;
  address: string;
  phone: string;
  email: string;
  academicYear: string;
  primaryColor: string;
  location: LatLng;
  settings: SchoolSettings;
}

export interface SchoolSettings {
  schoolGeofenceRadius: number; // metres
  pickupGeofenceRadius: number;
  dropGeofenceRadius: number;
  approachDistance: number;
  transportSkipCutoff: string; // "06:30"
  callDriverMode: 'show' | 'click-to-call' | 'active-trip-only';
}

export type TransportStatus =
  | 'NORMAL'
  | 'SCHOOL_LEAVE'
  | 'TRANSPORT_SKIP'
  | 'PICKUP_REQUIRED'
  | 'PICKUP_COMPLETED'
  | 'BOARDED'
  | 'REACHED_SCHOOL'
  | 'RETURN_STARTED'
  | 'DROP_REQUIRED'
  | 'DROPPED'
  | 'ABSENT_NO_NOTICE';

export interface Student {
  id: string;
  schoolId: string;
  firstName: string;
  lastName: string;
  dob: string;
  gender: 'male' | 'female' | 'other';
  className: string;
  section: string;
  roll: number;
  photo?: string;
  parentUids: string[];
  parentName: string;
  parentPhone: string;
  address: string;
  emergencyContact: string;
  busId?: string;
  routeId?: string;
  pickup: GeoPoint;
  drop: GeoPoint;
  transportStatus: TransportStatus;
  status: 'active' | 'inactive';
}

export interface GeoPoint {
  name: string;
  lat: number;
  lng: number;
  radius: number; // metres
}

export type BusStatus = 'active' | 'maintenance' | 'inactive';

export interface Bus {
  id: string;
  schoolId: string;
  code: string; // "Bus 03"
  vehicleNumber: string; // "WB-16A-1234"
  vehicleType: string;
  capacity: number;
  driverId: string;
  helperName: string;
  routeId: string;
  insuranceExpiry: string;
  fitnessExpiry: string;
  status: BusStatus;
}

export interface Driver {
  id: string;
  schoolId: string;
  name: string;
  photo?: string;
  phone: string;
  email: string;
  licence: string;
  licenceExpiry: string;
  busId?: string;
  routeId?: string;
  emergencyContact: string;
  status: 'active' | 'inactive';
}

export interface RouteStop {
  id: string;
  name: string;
  lat: number;
  lng: number;
  expectedTime: string;
  studentIds: string[];
}

export interface BusRoute {
  id: string;
  schoolId: string;
  name: string;
  stops: RouteStop[];
}

export type GeofenceState = 'outside' | 'approaching' | 'inside' | 'exited';

export type TripState =
  | 'NOT_STARTED'
  | 'STARTED'
  | 'EN_ROUTE'
  | 'NEAR_STOP'
  | 'AT_STOP'
  | 'STUDENT_BOARDED'
  | 'NEAR_SCHOOL'
  | 'AT_SCHOOL'
  | 'RETURN_STARTED'
  | 'NEAR_DROP'
  | 'STUDENT_DROPPED'
  | 'COMPLETED';

export interface LiveTrip {
  tripId: string;
  schoolId: string;
  busId: string;
  driverId: string;
  routeId: string;
  tripType: 'morning' | 'return';
  status: TripState;
  startedAt?: number;
  endedAt?: number;
  currentLatitude: number;
  currentLongitude: number;
  speed: number;
  heading: number;
  lastUpdated: number;
  /** Index of the next stop on the route the bus is heading toward. */
  nextStopIndex: number;
  boarded: Record<string, boolean>;
}

export interface GeofenceEvent {
  id: string;
  tripId: string;
  schoolId: string;
  busId: string;
  studentId?: string;
  eventType: string;
  timestamp: number;
  lat: number;
  lng: number;
}

export type NotificationCategory =
  | 'Transport'
  | 'Academic'
  | 'Fee'
  | 'Notice'
  | 'Safety'
  | 'Emergency';

export type NotificationPriority = 'INFO' | 'IMPORTANT' | 'SAFETY' | 'EMERGENCY';

export interface AppNotification {
  id: string;
  toUid: string;
  schoolId: string;
  category: NotificationCategory;
  priority: NotificationPriority;
  title: string;
  body: string;
  createdAt: number;
  read: boolean;
}

export interface FeeItem {
  id: string;
  studentId: string;
  title: string;
  amount: number;
  dueDate: string;
  status: 'paid' | 'pending' | 'overdue';
  receipt?: string;
  paidOn?: string;
}

export type AttendanceMark = 'present' | 'absent' | 'leave' | 'holiday';

export interface AttendanceDay {
  date: string; // YYYY-MM-DD
  mark: AttendanceMark;
}

export interface Homework {
  id: string;
  subject: string;
  title: string;
  detail: string;
  due: string;
  className: string;
  completed?: boolean;
  attachment?: string;
}

export interface ExamItem {
  id: string;
  examName: string;
  subject: string;
  date: string;
  time: string;
  className: string;
}

export interface Notice {
  id: string;
  title: string;
  body: string;
  date: string;
  priority: NotificationPriority;
  attachment?: string;
}

export interface LeaveRequest {
  id: string;
  studentId: string;
  parentUids: string[];
  fromDate: string;
  toDate: string;
  reason: string;
  attachment?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
}

export interface ReportCardRow {
  subject: string;
  marks: number;
  max: number;
  grade: string;
  remark: string;
}

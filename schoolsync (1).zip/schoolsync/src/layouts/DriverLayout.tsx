import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Bus, Route as RouteIcon, TriangleAlert, LogOut } from 'lucide-react';
import { cn } from '@/lib/cn';
import { NotificationBell } from '@/components/layout/NotificationBell';
import { useAuth } from '@/state/AuthContext';

const nav = [
  { to: '/driver', label: 'Trip', icon: Bus, end: true },
  { to: '/driver/route', label: 'Route', icon: RouteIcon },
  { to: '/driver/emergency', label: 'Emergency', icon: TriangleAlert },
];

export function DriverLayout() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const logout = async () => { await signOut(); navigate('/login'); };

  return (
    <div className="min-h-dvh bg-canvas">
      <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur pt-[var(--safe-top)]">
        <div className="mx-auto flex max-w-2xl items-center justify-between gap-3 px-4 py-2.5">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy text-white"><Bus className="h-5 w-5" /></span>
            <div className="leading-tight">
              <p className="text-sm font-bold text-ink">{user?.name ?? 'Driver'}</p>
              <p className="text-[11px] text-ink-muted">Bus 03 · Route A</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <NotificationBell />
            <button onClick={logout} className="grid h-10 w-10 place-items-center rounded-xl text-ink-soft hover:bg-slate-100" aria-label="Sign out">
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 pb-28 pt-4">
        <Outlet />
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-100 bg-white/95 pb-[var(--safe-bottom)] backdrop-blur">
        <div className="mx-auto flex max-w-2xl items-stretch justify-around">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) => cn(
                'flex flex-1 flex-col items-center gap-0.5 py-2.5 text-xs font-semibold transition',
                isActive ? 'text-navy' : 'text-ink-muted',
              )}
            >
              {({ isActive }) => (
                <>
                  <span className={cn('grid h-9 w-14 place-items-center rounded-full transition', isActive && 'bg-navy/10')}>
                    <n.icon className="h-5 w-5" />
                  </span>
                  {n.label}
                </>
              )}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

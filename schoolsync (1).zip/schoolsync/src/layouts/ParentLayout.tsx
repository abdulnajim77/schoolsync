import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  Home, Bus, IndianRupee, Megaphone, User, CalendarCheck, BookOpen,
  CalendarClock, FileText, Images, CalendarOff, LogOut, ChevronDown, GraduationCap,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/cn';
import { Avatar } from '@/components/ui';
import { NotificationBell } from '@/components/layout/NotificationBell';
import { DEMO_SCHOOL } from '@/data/demoData';
import { useAuth } from '@/state/AuthContext';
import { ParentProvider, useParent } from '@/state/ParentContext';

const primaryNav: { to: string; label: string; icon: LucideIcon; end?: boolean }[] = [
  { to: '/parent', label: 'Home', icon: Home, end: true },
  { to: '/parent/track', label: 'Bus', icon: Bus },
  { to: '/parent/fees', label: 'Fees', icon: IndianRupee },
  { to: '/parent/notices', label: 'Notice', icon: Megaphone },
  { to: '/parent/settings', label: 'Profile', icon: User },
];

const moreNav: { to: string; label: string; icon: LucideIcon; end?: boolean }[] = [
  { to: '/parent/attendance', label: 'Attendance', icon: CalendarCheck },
  { to: '/parent/homework', label: 'Homework', icon: BookOpen },
  { to: '/parent/exams', label: 'Exam Routine', icon: CalendarClock },
  { to: '/parent/report', label: 'Report Card', icon: FileText },
  { to: '/parent/leave', label: 'Leave & Transport', icon: CalendarOff },
  { to: '/parent/activities', label: 'Activities', icon: Images },
];

function ChildSwitcher() {
  const { children, child, setChildId } = useParent();
  if (!child) return null;
  if (children.length < 2) {
    return (
      <div className="flex items-center gap-2">
        <Avatar name={`${child.firstName} ${child.lastName}`} size={34} />
        <div className="leading-tight">
          <p className="text-sm font-bold text-ink">{child.firstName} {child.lastName}</p>
          <p className="text-[11px] text-ink-muted">{child.className} · {child.section}</p>
        </div>
      </div>
    );
  }
  return (
    <label className="relative flex items-center gap-2">
      <Avatar name={`${child.firstName} ${child.lastName}`} size={34} />
      <div className="leading-tight">
        <p className="flex items-center gap-1 text-sm font-bold text-ink">
          {child.firstName} {child.lastName} <ChevronDown className="h-3.5 w-3.5 text-ink-muted" />
        </p>
        <p className="text-[11px] text-ink-muted">{child.className} · {child.section}</p>
      </div>
      <select
        value={child.id}
        onChange={(e) => setChildId(e.target.value)}
        className="absolute inset-0 cursor-pointer opacity-0"
        aria-label="Switch child"
      >
        {children.map((c) => <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>)}
      </select>
    </label>
  );
}

function Shell() {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const logout = async () => { await signOut(); navigate('/login'); };

  return (
    <div className="min-h-dvh bg-canvas">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/85 backdrop-blur pt-[var(--safe-top)]">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-2.5">
          <ChildSwitcher />
          <div className="flex items-center gap-1">
            <span className="mr-1 hidden items-center gap-1.5 text-xs font-semibold text-ink-muted sm:flex">
              <GraduationCap className="h-4 w-4 text-navy" />{DEMO_SCHOOL.name}
            </span>
            <NotificationBell />
            <button onClick={logout} className="grid h-10 w-10 place-items-center rounded-xl text-ink-soft transition hover:bg-slate-100" aria-label="Sign out">
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
        {/* Desktop secondary nav */}
        <nav className="mx-auto hidden max-w-5xl gap-1 px-2 pb-1 sm:flex">
          {[...primaryNav.filter((n) => n.label !== 'Profile'), ...moreNav].map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) => cn(
                'flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition',
                isActive ? 'bg-navy/10 text-navy' : 'text-ink-muted hover:bg-slate-100',
              )}
            >
              <n.icon className="h-4 w-4" />{n.label}
            </NavLink>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-5xl px-4 pb-28 pt-4 sm:pb-10">
        <Outlet />
      </main>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-100 bg-white/95 pb-[var(--safe-bottom)] backdrop-blur sm:hidden">
        <div className="flex items-stretch justify-around">
          {primaryNav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              className={({ isActive }) => cn(
                'flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-medium transition',
                isActive ? 'text-navy' : 'text-ink-muted',
              )}
            >
              {({ isActive }) => (
                <>
                  <span className={cn('grid h-8 w-12 place-items-center rounded-full transition', isActive && 'bg-navy/10')}>
                    <n.icon className="h-5 w-5" />
                  </span>
                  {n.label}
                </>
              )}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

export function ParentLayout() {
  return (
    <ParentProvider>
      <Shell />
    </ParentProvider>
  );
}

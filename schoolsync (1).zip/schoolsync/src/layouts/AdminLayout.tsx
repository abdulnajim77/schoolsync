import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, Users, UserSquare2, GraduationCap, Bus, IdCard, Route as RouteIcon,
  MapPinned, CalendarCheck, IndianRupee, CalendarClock, BookOpen, Megaphone,
  CalendarOff, BarChart3, Settings, Menu, X, LogOut,
} from 'lucide-react';
import { cn } from '@/lib/cn';
import { NotificationBell } from '@/components/layout/NotificationBell';
import { DEMO_SCHOOL } from '@/data/demoData';
import { useAuth } from '@/state/AuthContext';

const nav = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/students', label: 'Students', icon: Users },
  { to: '/admin/parents', label: 'Parents', icon: UserSquare2 },
  { to: '/admin/teachers', label: 'Teachers', icon: GraduationCap },
  { to: '/admin/buses', label: 'Buses', icon: Bus },
  { to: '/admin/drivers', label: 'Drivers', icon: IdCard },
  { to: '/admin/routes', label: 'Routes', icon: RouteIcon },
  { to: '/admin/tracking', label: 'Live Tracking', icon: MapPinned },
  { to: '/admin/attendance', label: 'Attendance', icon: CalendarCheck },
  { to: '/admin/fees', label: 'Fees', icon: IndianRupee },
  { to: '/admin/exams', label: 'Exams', icon: CalendarClock },
  { to: '/admin/homework', label: 'Homework', icon: BookOpen },
  { to: '/admin/notices', label: 'Notices', icon: Megaphone },
  { to: '/admin/leave', label: 'Leave Requests', icon: CalendarOff },
  { to: '/admin/reports', label: 'Reports', icon: BarChart3 },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
];

export function AdminLayout() {
  const [open, setOpen] = useState(false);
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const logout = async () => { await signOut(); navigate('/login'); };

  return (
    <div className="min-h-dvh bg-canvas lg:flex">
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-slate-100 bg-white transition-transform lg:static lg:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className="flex items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy text-white"><Bus className="h-5 w-5" /></span>
            <div className="leading-tight">
              <p className="text-sm font-bold text-ink">SchoolSync</p>
              <p className="text-[11px] text-ink-muted">Admin Console</p>
            </div>
          </div>
          <button onClick={() => setOpen(false)} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-100 lg:hidden">
            <X className="h-5 w-5" />
          </button>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto scrollbar-slim px-3 pb-4">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              end={n.end}
              onClick={() => setOpen(false)}
              className={({ isActive }) => cn(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition',
                isActive ? 'bg-navy text-white shadow-sm' : 'text-ink-soft hover:bg-slate-100',
              )}
            >
              <n.icon className="h-[18px] w-[18px]" />{n.label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-slate-100 px-3 py-3">
          <button onClick={logout} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-ink-soft transition hover:bg-slate-100">
            <LogOut className="h-[18px] w-[18px]" />Sign out
          </button>
        </div>
      </aside>

      {open && <div className="fixed inset-0 z-40 bg-ink/40 backdrop-blur-sm lg:hidden" onClick={() => setOpen(false)} />}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-slate-100 bg-white/85 px-4 py-2.5 backdrop-blur pt-[calc(0.625rem+var(--safe-top))]">
          <div className="flex items-center gap-2">
            <button onClick={() => setOpen(true)} className="grid h-10 w-10 place-items-center rounded-xl text-ink-soft hover:bg-slate-100 lg:hidden">
              <Menu className="h-5 w-5" />
            </button>
            <div>
              <p className="text-sm font-bold text-ink">{DEMO_SCHOOL.name}</p>
              <p className="text-[11px] text-ink-muted">Academic Year {DEMO_SCHOOL.academicYear}</p>
            </div>
          </div>
          <NotificationBell />
        </header>
        <main className="min-w-0 flex-1 px-4 py-5 lg:px-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

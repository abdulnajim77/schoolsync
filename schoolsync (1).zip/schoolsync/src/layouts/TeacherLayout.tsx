import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, CalendarCheck, GraduationCap, LogOut } from 'lucide-react';
import { cn } from '@/lib/cn';
import { NotificationBell } from '@/components/layout/NotificationBell';
import { useAuth } from '@/state/AuthContext';

const nav = [
  { to: '/teacher', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/teacher/attendance', label: 'Attendance', icon: CalendarCheck },
];

export function TeacherLayout() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const logout = async () => { await signOut(); navigate('/login'); };

  return (
    <div className="min-h-dvh bg-canvas">
      <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/90 backdrop-blur pt-[var(--safe-top)]">
        <div className="mx-auto flex max-w-4xl items-center justify-between gap-3 px-4 py-2.5">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy text-white"><GraduationCap className="h-5 w-5" /></span>
            <div className="leading-tight">
              <p className="text-sm font-bold text-ink">{user?.name ?? 'Teacher'}</p>
              <p className="text-[11px] text-ink-muted">Class Teacher · LKG-A</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <nav className="hidden gap-1 sm:flex">
              {nav.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  end={n.end}
                  className={({ isActive }) => cn(
                    'flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition',
                    isActive ? 'bg-navy/10 text-navy' : 'text-ink-muted hover:bg-slate-100',
                  )}
                >
                  <n.icon className="h-4 w-4" />{n.label}
                </NavLink>
              ))}
            </nav>
            <NotificationBell />
            <button onClick={logout} className="grid h-10 w-10 place-items-center rounded-xl text-ink-soft hover:bg-slate-100" aria-label="Sign out">
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 pb-16 pt-4">
        <Outlet />
      </main>
    </div>
  );
}

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import type { AppNotification, NotificationCategory, NotificationPriority } from '@/types';
import { uid } from '@/lib/id';

export type PrefKey =
  | 'busApproachingPickup' | 'busArrived' | 'studentBoarded' | 'reachedSchool'
  | 'returnStarted' | 'busApproachingDrop' | 'studentDropped'
  | 'schoolNotice' | 'feeReminder' | 'homework';

export type Preferences = Record<PrefKey, boolean>;

const DEFAULT_PREFS: Preferences = {
  busApproachingPickup: true, busArrived: true, studentBoarded: true, reachedSchool: true,
  returnStarted: true, busApproachingDrop: true, studentDropped: true,
  schoolNotice: true, feeReminder: true, homework: true,
};

export interface PushInput {
  title: string;
  body: string;
  category: NotificationCategory;
  priority?: NotificationPriority;
  toUid?: string;
  /** Preference gate — safety/emergency ignore this and always deliver. */
  prefKey?: PrefKey;
}

interface Ctx {
  items: AppNotification[];
  unread: number;
  prefs: Preferences;
  toasts: AppNotification[];
  push: (input: PushInput) => void;
  markAllRead: () => void;
  markRead: (id: string) => void;
  clearToast: (id: string) => void;
  setPref: (key: PrefKey, value: boolean) => void;
  seed: (items: AppNotification[]) => void;
}

const NotificationContext = createContext<Ctx | null>(null);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<AppNotification[]>([]);
  const [toasts, setToasts] = useState<AppNotification[]>([]);
  const [prefs, setPrefs] = useState<Preferences>(DEFAULT_PREFS);

  const push = useCallback(
    (input: PushInput) => {
      const priority = input.priority ?? 'INFO';
      const alwaysOn = priority === 'SAFETY' || priority === 'EMERGENCY';
      if (!alwaysOn && input.prefKey && !prefs[input.prefKey]) return; // muted by preference

      const n: AppNotification = {
        id: uid('ntf'), toUid: input.toUid ?? 'me', schoolId: 'school_001',
        category: input.category, priority, title: input.title, body: input.body,
        createdAt: Date.now(), read: false,
      };
      setItems((prev) => [n, ...prev].slice(0, 60));
      setToasts((prev) => [n, ...prev].slice(0, 4));
      window.setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== n.id)), priority === 'EMERGENCY' ? 9000 : 5200);
    },
    [prefs],
  );

  const value = useMemo<Ctx>(
    () => ({
      items,
      unread: items.filter((i) => !i.read).length,
      prefs,
      toasts,
      push,
      seed: (seedItems) => setItems(seedItems),
      markAllRead: () => setItems((prev) => prev.map((i) => ({ ...i, read: true }))),
      markRead: (id) => setItems((prev) => prev.map((i) => (i.id === id ? { ...i, read: true } : i))),
      clearToast: (id) => setToasts((prev) => prev.filter((t) => t.id !== id)),
      setPref: (key, v) => setPrefs((prev) => ({ ...prev, [key]: v })),
    }),
    [items, toasts, prefs, push],
  );

  return <NotificationContext.Provider value={value}>{children}</NotificationContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useNotifications(): Ctx {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error('useNotifications must be used within <NotificationProvider>');
  return ctx;
}

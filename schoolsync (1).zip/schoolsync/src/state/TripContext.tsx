import {
  createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode,
} from 'react';
import type {
  GeofenceEvent, GeofenceState, LatLng, LiveTrip, Role, Student, TripState,
} from '@/types';
import { DEMO_ROUTE, DEMO_SCHOOL } from '@/data/demoData';
import { demoDb } from '@/data/demoDb';
import { bearing, evaluateGeofence, haversine, lerpLatLng } from '@/lib/geo';
import { clockTimeSec } from '@/lib/format';
import { uid } from '@/lib/id';
import { useNotifications } from './NotificationContext';

const TICK_MS = 1200;
const STEP = 0.05; // fraction of a segment per tick (~24s per segment)
const BUS_ID = 'bus_03';

interface Ctx {
  trip: LiveTrip;
  events: GeofenceEvent[];
  students: Student[];
  distanceToStudentStop: (studentId: string) => number;
  startTrip: (type: 'morning' | 'return') => void;
  endTrip: () => void;
  board: (studentId: string) => void;
  drop: (studentId: string) => void;
  resetDemo: () => void;
}

const TripContext = createContext<Ctx | null>(null);

const waypoints = (type: 'morning' | 'return'): LatLng[] => {
  const pts = DEMO_ROUTE.stops.map((s) => ({ lat: s.lat, lng: s.lng }));
  return type === 'return' ? [...pts].reverse() : pts;
};

const initialTrip = (): LiveTrip => {
  const start = DEMO_ROUTE.stops[0];
  return {
    tripId: uid('trip'), schoolId: 'school_001', busId: BUS_ID, driverId: 'driver_001',
    routeId: 'route_A', tripType: 'morning', status: 'NOT_STARTED',
    currentLatitude: start.lat, currentLongitude: start.lng, speed: 0, heading: 0,
    lastUpdated: Date.now(), nextStopIndex: 1, boarded: {},
  };
};

export function TripProvider({
  viewerUid, viewerRole, children,
}: { viewerUid: string; viewerRole: Role; children: ReactNode }) {
  const { push } = useNotifications();
  const [trip, setTrip] = useState<LiveTrip>(initialTrip);
  const [events, setEvents] = useState<GeofenceEvent[]>([]);
  const [students, setStudents] = useState<Student[]>(() =>
    demoDb.getStudents().filter((s) => s.busId === BUS_ID),
  );

  const progress = useRef(0); // continuous position along waypoints
  const fenceStates = useRef<Record<string, GeofenceState>>({});
  const timer = useRef<number | null>(null);

  const canNotifyStudent = useCallback(
    (s: Student) =>
      viewerRole === 'parent' ? s.parentUids.includes(viewerUid) : viewerRole !== 'driver',
    [viewerUid, viewerRole],
  );

  const logEvent = useCallback((eventType: string, pos: LatLng, studentId?: string) => {
    setEvents((prev) =>
      [{
        id: uid('gfe'), tripId: 'trip', schoolId: 'school_001', busId: BUS_ID,
        studentId, eventType, timestamp: Date.now(), lat: pos.lat, lng: pos.lng,
      }, ...prev].slice(0, 80),
    );
  }, []);

  const board = useCallback(
    (studentId: string) => {
      setTrip((t) => (t.boarded[studentId] ? t : { ...t, boarded: { ...t.boarded, [studentId]: true } }));
      setStudents((prev) => {
        const target = prev.find((s) => s.id === studentId);
        if (!target || target.transportStatus === 'BOARDED') return prev;
        demoDb.updateStudent(studentId, { transportStatus: 'BOARDED' });
        if (canNotifyStudent(target))
          push({ category: 'Safety', priority: 'SAFETY', prefKey: 'studentBoarded',
            title: 'Student boarded', body: `${target.firstName} boarded Bus 03 safely.` });
        logEvent(`${target.firstName} marked Boarded`, { lat: target.pickup.lat, lng: target.pickup.lng }, studentId);
        return prev.map((s) => (s.id === studentId ? { ...s, transportStatus: 'BOARDED' } : s));
      });
    },
    [push, logEvent, canNotifyStudent],
  );

  const drop = useCallback(
    (studentId: string) => {
      setStudents((prev) => {
        const target = prev.find((s) => s.id === studentId);
        if (!target || target.transportStatus === 'DROPPED') return prev;
        demoDb.updateStudent(studentId, { transportStatus: 'DROPPED' });
        if (canNotifyStudent(target))
          push({ category: 'Safety', priority: 'SAFETY', prefKey: 'studentDropped',
            title: 'Student dropped', body: `${target.firstName} was dropped safely at ${target.drop.name}.` });
        logEvent(`${target.firstName} marked Dropped`, { lat: target.drop.lat, lng: target.drop.lng }, studentId);
        return prev.map((s) => (s.id === studentId ? { ...s, transportStatus: 'DROPPED' } : s));
      });
    },
    [push, logEvent, canNotifyStudent],
  );

  // --- The simulation tick --------------------------------------------------
  const tick = useCallback(() => {
    setTrip((t) => {
      if (t.status === 'NOT_STARTED' || t.status === 'COMPLETED') return t;
      const path = waypoints(t.tripType);
      const maxProgress = path.length - 1;
      const prevPos: LatLng = { lat: t.currentLatitude, lng: t.currentLongitude };

      progress.current = Math.min(maxProgress, progress.current + STEP);
      const seg = Math.min(Math.floor(progress.current), maxProgress - 1);
      const frac = progress.current - seg;
      const pos = lerpLatLng(path[seg], path[seg + 1], frac);
      const stepDist = haversine(prevPos, pos);
      const speed = Math.round((stepDist / (TICK_MS / 1000)) * 3.6); // km/h

      const activeStudents = demoDb.getStudents().filter(
        (s) => s.busId === BUS_ID &&
          s.transportStatus !== 'SCHOOL_LEAVE' && s.transportStatus !== 'TRANSPORT_SKIP',
      );

      // Evaluate student pickup / drop geofences
      for (const s of activeStudents) {
        const isMorning = t.tripType === 'morning';
        const zonePoint = isMorning ? s.pickup : s.drop;
        const key = `${isMorning ? 'pickup' : 'drop'}:${s.id}`;
        const prev = fenceStates.current[key] ?? 'outside';
        const ev = evaluateGeofence(pos, {
          center: { lat: zonePoint.lat, lng: zonePoint.lng },
          radius: zonePoint.radius, approachDistance: DEMO_SCHOOL.settings.approachDistance,
        }, prev);
        fenceStates.current[key] = ev.state;
        if (!ev.changed) continue;

        if (ev.transition === 'enter-approach') {
          logEvent(`Bus 03 approaching ${zonePoint.name} (${s.firstName})`, pos, s.id);
          if (canNotifyStudent(s))
            push({
              category: 'Transport', priority: 'IMPORTANT',
              prefKey: isMorning ? 'busApproachingPickup' : 'busApproachingDrop',
              title: isMorning ? 'Bus approaching pickup' : 'Bus approaching drop',
              body: isMorning
                ? `Bus 03 is approaching ${s.firstName}'s pickup point.`
                : `${s.firstName}'s bus is approaching the drop point.`,
            });
        } else if (ev.transition === 'enter-inside') {
          logEvent(`Bus 03 entered ${zonePoint.name} geofence (${s.firstName})`, pos, s.id);
          if (canNotifyStudent(s))
            push({
              category: 'Transport', priority: 'IMPORTANT',
              prefKey: isMorning ? 'busArrived' : 'busApproachingDrop',
              title: isMorning ? 'Bus arrived nearby' : 'Bus arrived nearby',
              body: `${s.firstName}'s school bus has arrived near ${zonePoint.name}.`,
            });
          // Auto-board / auto-drop shortly after arrival so the demo completes hands-free.
          window.setTimeout(() => (isMorning ? board(s.id) : drop(s.id)), 1500);
        }
      }

      // Evaluate school geofence
      const schoolKey = 'school';
      const prevSchool = fenceStates.current[schoolKey] ?? 'outside';
      const sEv = evaluateGeofence(pos, {
        center: DEMO_SCHOOL.location, radius: DEMO_SCHOOL.settings.schoolGeofenceRadius,
        approachDistance: DEMO_SCHOOL.settings.approachDistance,
      }, prevSchool);
      fenceStates.current[schoolKey] = sEv.state;
      if (sEv.changed && t.tripType === 'morning') {
        if (sEv.transition === 'enter-approach') {
          logEvent('Bus 03 approaching school', pos);
          push({ category: 'Transport', priority: 'IMPORTANT', prefKey: 'reachedSchool',
            title: 'Bus approaching school', body: 'Bus 03 is approaching the school.' });
        } else if (sEv.transition === 'enter-inside') {
          logEvent('Bus 03 entered school geofence', pos);
          for (const s of activeStudents) {
            if (canNotifyStudent(s))
              push({ category: 'Safety', priority: 'SAFETY', prefKey: 'reachedSchool',
                title: 'Reached school safely', body: `${s.firstName} reached school safely.` });
            demoDb.updateStudent(s.id, { transportStatus: 'REACHED_SCHOOL' });
          }
          setStudents((prev) => prev.map((s) => ({ ...s, transportStatus: 'REACHED_SCHOOL' })));
        }
      }

      // Determine trip state
      let status: TripState = t.status;
      if (progress.current >= maxProgress) {
        status = 'COMPLETED';
        window.setTimeout(() => stop(), 50);
      } else if (sEv.state === 'inside') status = t.tripType === 'morning' ? 'AT_SCHOOL' : 'EN_ROUTE';
      else if (sEv.state === 'approaching' && t.tripType === 'morning') status = 'NEAR_SCHOOL';
      else status = 'EN_ROUTE';

      const heading = bearing(prevPos, pos);
      return {
        ...t, currentLatitude: pos.lat, currentLongitude: pos.lng, speed,
        heading, lastUpdated: Date.now(), status,
        nextStopIndex: Math.min(seg + 1, DEMO_ROUTE.stops.length - 1),
      };
    });
  }, [push, logEvent, board, drop, canNotifyStudent]);

  const stop = useCallback(() => {
    if (timer.current) window.clearInterval(timer.current);
    timer.current = null;
  }, []);

  const startTrip = useCallback(
    (type: 'morning' | 'return') => {
      stop();
      progress.current = 0;
      fenceStates.current = {};
      setEvents([]);
      const path = waypoints(type);
      setTrip({
        ...initialTrip(), tripType: type, status: 'STARTED',
        startedAt: Date.now(), currentLatitude: path[0].lat, currentLongitude: path[0].lng,
        boarded: {},
      });
      // reset transport status for a clean run
      demoDb.getStudents().forEach((s) => {
        if (s.busId === BUS_ID && s.transportStatus !== 'SCHOOL_LEAVE' && s.transportStatus !== 'TRANSPORT_SKIP')
          demoDb.updateStudent(s.id, { transportStatus: type === 'morning' ? 'PICKUP_REQUIRED' : 'RETURN_STARTED' });
      });
      setStudents(demoDb.getStudents().filter((s) => s.busId === BUS_ID));
      logEvent(`Trip started (${type})`, path[0]);
      if (type === 'return') {
        const onboard = demoDb.getStudents().filter(
          (s) => s.busId === BUS_ID && s.transportStatus === 'RETURN_STARTED',
        );
        onboard.forEach((s) => {
          if (canNotifyStudent(s))
            push({ category: 'Transport', priority: 'IMPORTANT', prefKey: 'returnStarted',
              title: 'Return trip started', body: `${s.firstName}'s return bus has started from school.` });
        });
      }
      timer.current = window.setInterval(tick, TICK_MS);
    },
    [tick, stop, logEvent, push, canNotifyStudent],
  );

  const endTrip = useCallback(() => {
    stop();
    setTrip((t) => ({ ...t, status: 'COMPLETED', endedAt: Date.now(), speed: 0 }));
    logEvent('Trip ended', { lat: trip.currentLatitude, lng: trip.currentLongitude });
  }, [stop, logEvent, trip.currentLatitude, trip.currentLongitude]);

  const resetDemo = useCallback(() => {
    stop();
    demoDb.reset();
    fenceStates.current = {};
    progress.current = 0;
    setEvents([]);
    setStudents(demoDb.getStudents().filter((s) => s.busId === BUS_ID));
    setTrip(initialTrip());
  }, [stop]);

  useEffect(() => () => stop(), [stop]);

  const distanceToStudentStop = useCallback(
    (studentId: string): number => {
      const s = students.find((x) => x.id === studentId);
      if (!s) return 0;
      const zone = trip.tripType === 'morning' ? s.pickup : s.drop;
      return haversine({ lat: trip.currentLatitude, lng: trip.currentLongitude }, { lat: zone.lat, lng: zone.lng });
    },
    [students, trip.currentLatitude, trip.currentLongitude, trip.tripType],
  );

  const value = useMemo<Ctx>(
    () => ({ trip, events, students, distanceToStudentStop, startTrip, endTrip, board, drop, resetDemo }),
    [trip, events, students, distanceToStudentStop, startTrip, endTrip, board, drop, resetDemo],
  );

  return <TripContext.Provider value={value}>{children}</TripContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useTrip(): Ctx {
  const ctx = useContext(TripContext);
  if (!ctx) throw new Error('useTrip must be used within <TripProvider>');
  return ctx;
}

// eslint-disable-next-line react-refresh/only-export-components
export { clockTimeSec };

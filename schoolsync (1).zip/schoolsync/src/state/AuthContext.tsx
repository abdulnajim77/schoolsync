import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AppUser, Role } from '@/types';
import { authService, type SignInInput } from '@/services/authService';

interface AuthContextValue {
  user: AppUser | null;
  loading: boolean;
  signIn: (input: SignInInput) => Promise<AppUser>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const homeForRole = (role: Role): string =>
  ({ admin: '/admin', parent: '/parent', driver: '/driver', teacher: '/teacher' })[role];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    authService
      .restore()
      .then(setUser)
      .finally(() => setLoading(false));
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      loading,
      signIn: async (input) => {
        const u = await authService.signIn(input);
        setUser(u);
        return u;
      },
      signOut: async () => {
        await authService.signOut();
        setUser(null);
      },
    }),
    [user, loading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within <AuthProvider>');
  return ctx;
}

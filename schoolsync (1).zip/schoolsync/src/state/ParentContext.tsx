import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';
import type { Student } from '@/types';
import { demoDb } from '@/data/demoDb';
import { useAuth } from './AuthContext';

interface Ctx {
  children: Student[];
  child: Student;
  childId: string;
  setChildId: (id: string) => void;
}

const ParentContext = createContext<Ctx | null>(null);

export function ParentProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const kids = useMemo(
    () => demoDb.getStudents().filter((s) => (user?.childIds ?? []).includes(s.id)),
    [user?.childIds],
  );
  const [childId, setChildId] = useState(kids[0]?.id ?? '');
  const child = kids.find((k) => k.id === childId) ?? kids[0];

  const value = useMemo<Ctx>(() => ({ children: kids, child, childId: child?.id ?? '', setChildId }), [kids, child]);
  return <ParentContext.Provider value={value}>{children}</ParentContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export function useParent(): Ctx {
  const ctx = useContext(ParentContext);
  if (!ctx) throw new Error('useParent must be used within <ParentProvider>');
  return ctx;
}

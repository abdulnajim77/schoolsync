// ---------------------------------------------------------------------------
// Geofencing engine
// Real geographic distance via the Haversine formula (not visual map circles).
// A small state machine per geofence prevents duplicate/spam notifications.
// ---------------------------------------------------------------------------
import type { GeofenceState, LatLng } from '@/types';

const EARTH_RADIUS_M = 6_371_000;
const toRad = (deg: number): number => (deg * Math.PI) / 180;

/** Great-circle distance in metres between two coordinates. */
export function haversine(a: LatLng, b: LatLng): number {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return 2 * EARTH_RADIUS_M * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Initial bearing (heading) from a → b, in degrees (0 = north). */
export function bearing(a: LatLng, b: LatLng): number {
  const dLng = toRad(b.lng - a.lng);
  const y = Math.sin(dLng) * Math.cos(toRad(b.lat));
  const x =
    Math.cos(toRad(a.lat)) * Math.sin(toRad(b.lat)) -
    Math.sin(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.cos(dLng);
  return (Math.atan2(y, x) * 180) / Math.PI;
}

/** Linear interpolation between two coordinates, t ∈ [0,1]. */
export function lerpLatLng(a: LatLng, b: LatLng, t: number): LatLng {
  return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
}

export interface GeofenceZone {
  center: LatLng;
  radius: number; // "inside" threshold in metres
  approachDistance: number; // "approaching" threshold in metres
}

export interface GeofenceEvaluation {
  distance: number;
  state: GeofenceState;
  /** True only on the tick where the state actually changed → send one notification. */
  changed: boolean;
  transition: 'enter-approach' | 'enter-inside' | 'exit' | null;
}

/**
 * Evaluate a single geofence against a live position.
 * `prevState` is the last stored state for this (bus,student,zone) tuple.
 * Notifications should only fire when `changed` is true, giving natural
 * de-duplication while the bus sits inside the same radius.
 */
export function evaluateGeofence(
  position: LatLng,
  zone: GeofenceZone,
  prevState: GeofenceState,
): GeofenceEvaluation {
  const distance = haversine(position, zone.center);

  let state: GeofenceState = 'outside';
  if (distance <= zone.radius) state = 'inside';
  else if (distance <= zone.approachDistance) state = 'approaching';
  else state = prevState === 'inside' || prevState === 'exited' ? 'exited' : 'outside';

  // Collapse "exited" back to "outside" once well clear so re-entry can retrigger.
  if (state === 'exited' && distance > zone.approachDistance * 1.2) state = 'outside';

  const changed = state !== prevState;
  let transition: GeofenceEvaluation['transition'] = null;
  if (changed) {
    if (state === 'approaching' && (prevState === 'outside' || prevState === 'exited'))
      transition = 'enter-approach';
    else if (state === 'inside') transition = 'enter-inside';
    else if (state === 'exited') transition = 'exit';
  }

  return { distance, state, changed, transition };
}

/** ETA in minutes given remaining distance (m) and speed (km/h). */
export function etaMinutes(distanceM: number, speedKmh: number): number {
  const speed = Math.max(speedKmh, 8); // floor to avoid absurd ETAs when idling
  return Math.max(1, Math.round((distanceM / 1000 / speed) * 60));
}

export function etaClock(distanceM: number, speedKmh: number): string {
  const mins = etaMinutes(distanceM, speedKmh);
  const t = new Date(Date.now() + mins * 60_000);
  return t.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
}

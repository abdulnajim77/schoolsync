// ---------------------------------------------------------------------------
// Firebase initialisation.
// Firebase is only initialised in PRODUCTION mode. In DEMO mode this module
// stays inert so the app runs with zero Firebase config (localStorage only).
// ---------------------------------------------------------------------------
import { initializeApp, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getDatabase, type Database } from 'firebase/database';
import { getStorage, type FirebaseStorage } from 'firebase/storage';
import { firebaseConfig, hasFirebaseConfig, IS_PRODUCTION } from './env';

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;
let rtdb: Database | null = null;
let storage: FirebaseStorage | null = null;

if (IS_PRODUCTION) {
  if (!hasFirebaseConfig) {
    // Fail loud & early — a production build must have real config.
    // eslint-disable-next-line no-console
    console.error(
      '[SchoolSync] VITE_APP_MODE=production but Firebase config is missing. ' +
        'Fill the VITE_FIREBASE_* variables in your .env file.',
    );
  } else {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
    rtdb = getDatabase(app);
    storage = getStorage(app);
  }
}

export { app, auth, db, rtdb, storage };

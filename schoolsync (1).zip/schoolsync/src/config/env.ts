// ---------------------------------------------------------------------------
// Central environment access. Never read import.meta.env directly elsewhere.
// ---------------------------------------------------------------------------
export const APP_MODE = (import.meta.env.VITE_APP_MODE ?? 'demo') as 'demo' | 'production';
export const IS_DEMO = APP_MODE !== 'production';
export const IS_PRODUCTION = APP_MODE === 'production';

export const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL,
};

export const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY ?? '';
export const FCM_VAPID_KEY = import.meta.env.VITE_FIREBASE_VAPID_KEY ?? '';

export const hasFirebaseConfig = Boolean(firebaseConfig.apiKey && firebaseConfig.projectId);
export const hasMapsKey = Boolean(GOOGLE_MAPS_API_KEY);

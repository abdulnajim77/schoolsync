// ---------------------------------------------------------------------------
// Demo dataset — "Little Star Kids Academy" (Hooghly, West Bengal).
// Coordinates trace a believable morning route toward the school so the
// simulated GPS + geofencing feels real when shown to school owners.
// ---------------------------------------------------------------------------
import type {
  AppNotification, AttendanceDay, Bus, BusRoute, Driver, ExamItem, FeeItem,
  Homework, LeaveRequest, Notice, ReportCardRow, School, Student,
} from '@/types';

export const DEMO_SCHOOL: School = {
  id: 'school_001',
  name: 'Little Star Kids Academy',
  address: 'GT Road, Chandannagar, Hooghly, West Bengal 712136',
  phone: '+91 90000 12345',
  email: 'office@littlestaracademy.in',
  academicYear: '2026–2027',
  primaryColor: '#253B80',
  location: { lat: 22.8712, lng: 88.3648 }, // school
  settings: {
    schoolGeofenceRadius: 200,
    pickupGeofenceRadius: 100,
    dropGeofenceRadius: 100,
    approachDistance: 500,
    transportSkipCutoff: '06:30',
    callDriverMode: 'active-trip-only',
  },
};

// --- Route A: stops from the far end of the line back to the school ---------
export const DEMO_ROUTE: BusRoute = {
  id: 'route_A',
  schoolId: 'school_001',
  name: 'Route A',
  stops: [
    { id: 'stop_start', name: 'Bus Depot', lat: 22.8531, lng: 88.3902, expectedTime: '7:30 AM', studentIds: [] },
    { id: 'stop_1', name: 'Station Road', lat: 22.8598, lng: 88.3811, expectedTime: '7:41 AM', studentIds: ['stu_2', 'stu_3'] },
    { id: 'stop_2', name: 'Jyoti More', lat: 22.8663, lng: 88.3742, expectedTime: '7:48 AM', studentIds: ['stu_1'] },
    { id: 'stop_3', name: 'College More', lat: 22.8697, lng: 88.3689, expectedTime: '7:55 AM', studentIds: ['stu_4', 'stu_5'] },
    { id: 'stop_school', name: 'Little Star Kids Academy', lat: 22.8712, lng: 88.3648, expectedTime: '8:05 AM', studentIds: [] },
  ],
};

export const DEMO_DRIVERS: Driver[] = [
  {
    id: 'driver_001', schoolId: 'school_001', name: 'Sanjay Das', phone: '+91 98300 55512',
    email: 'driver@demo.com', licence: 'WB-2019-0034512', licenceExpiry: '2028-06-30',
    busId: 'bus_03', routeId: 'route_A', emergencyContact: '+91 98300 55599', status: 'active',
  },
  {
    id: 'driver_002', schoolId: 'school_001', name: 'Rakesh Manna', phone: '+91 98301 22114',
    email: 'rakesh@demo.com', licence: 'WB-2020-0091233', licenceExpiry: '2027-03-15',
    busId: 'bus_01', routeId: 'route_A', emergencyContact: '+91 98301 22199', status: 'active',
  },
];

export const DEMO_BUSES: Bus[] = [
  {
    id: 'bus_03', schoolId: 'school_001', code: 'Bus 03', vehicleNumber: 'WB-16A-1234',
    vehicleType: 'Mini Bus (24 seat)', capacity: 24, driverId: 'driver_001', helperName: 'Mita Ghosh',
    routeId: 'route_A', insuranceExpiry: '2027-01-31', fitnessExpiry: '2026-12-15', status: 'active',
  },
  {
    id: 'bus_01', schoolId: 'school_001', code: 'Bus 01', vehicleNumber: 'WB-16B-8890',
    vehicleType: 'Mini Bus (24 seat)', capacity: 24, driverId: 'driver_002', helperName: 'Sova Pal',
    routeId: 'route_A', insuranceExpiry: '2026-11-10', fitnessExpiry: '2027-02-01', status: 'active',
  },
  {
    id: 'bus_02', schoolId: 'school_001', code: 'Bus 02', vehicleNumber: 'WB-16C-4521',
    vehicleType: 'Van (14 seat)', capacity: 14, driverId: 'driver_002', helperName: 'Anima Roy',
    routeId: 'route_A', insuranceExpiry: '2027-04-20', fitnessExpiry: '2026-10-30', status: 'maintenance',
  },
];

const mkStudent = (p: Partial<Student> & Pick<Student, 'id' | 'firstName' | 'lastName' | 'roll' | 'pickup' | 'drop' | 'parentName' | 'parentPhone'>): Student => ({
  schoolId: 'school_001', gender: 'female', className: 'LKG', section: 'A',
  dob: '2021-05-14', address: 'Chandannagar, Hooghly', emergencyContact: p.parentPhone,
  busId: 'bus_03', routeId: 'route_A', transportStatus: 'NORMAL', status: 'active',
  parentUids: [], photo: undefined, ...p,
} as Student);

export const DEMO_STUDENTS: Student[] = [
  mkStudent({
    id: 'stu_1', firstName: 'Riya', lastName: 'Das', roll: 12, className: 'LKG', section: 'A',
    parentName: 'Mrs. Das', parentPhone: '+91 98311 40012', parentUids: ['parent_001'],
    pickup: { name: 'Jyoti More', lat: 22.8663, lng: 88.3742, radius: 100 },
    drop: { name: 'Jyoti More', lat: 22.8663, lng: 88.3742, radius: 100 },
  }),
  mkStudent({
    id: 'stu_2', firstName: 'Arjun', lastName: 'Roy', roll: 4, gender: 'male', className: 'UKG', section: 'A',
    parentName: 'Mr. Roy', parentPhone: '+91 98311 40023', parentUids: ['parent_002'],
    pickup: { name: 'Station Road', lat: 22.8598, lng: 88.3811, radius: 100 },
    drop: { name: 'Station Road', lat: 22.8598, lng: 88.3811, radius: 100 },
  }),
  mkStudent({
    id: 'stu_3', firstName: 'Maya', lastName: 'Ghosh', roll: 9, className: 'UKG', section: 'A',
    parentName: 'Mrs. Ghosh', parentPhone: '+91 98311 40031',
    pickup: { name: 'Station Road', lat: 22.8598, lng: 88.3811, radius: 100 },
    drop: { name: 'Station Road', lat: 22.8598, lng: 88.3811, radius: 100 },
  }),
  mkStudent({
    id: 'stu_4', firstName: 'Ishaan', lastName: 'Pal', roll: 7, gender: 'male', className: 'Class 1', section: 'B',
    parentName: 'Mr. Pal', parentPhone: '+91 98311 40044',
    pickup: { name: 'College More', lat: 22.8697, lng: 88.3689, radius: 100 },
    drop: { name: 'College More', lat: 22.8697, lng: 88.3689, radius: 100 },
  }),
  mkStudent({
    id: 'stu_5', firstName: 'Ananya', lastName: 'Sen', roll: 15, className: 'Class 1', section: 'B',
    parentName: 'Mrs. Sen', parentPhone: '+91 98311 40055',
    pickup: { name: 'College More', lat: 22.8697, lng: 88.3689, radius: 100 },
    drop: { name: 'College More', lat: 22.8697, lng: 88.3689, radius: 100 },
  }),
];

// Riya's parent (parent_001) has a second child so "switch child" is demoable.
DEMO_STUDENTS.push(
  mkStudent({
    id: 'stu_6', firstName: 'Aarav', lastName: 'Das', roll: 3, gender: 'male', className: 'Class 2', section: 'A',
    parentName: 'Mrs. Das', parentPhone: '+91 98311 40012', parentUids: ['parent_001'],
    pickup: { name: 'Jyoti More', lat: 22.8663, lng: 88.3742, radius: 100 },
    drop: { name: 'Jyoti More', lat: 22.8663, lng: 88.3742, radius: 100 },
  }),
);

// --- Academic demo data (scoped to Riya / stu_1 for the parent view) --------
export const DEMO_FEES: FeeItem[] = [
  { id: 'fee_1', studentId: 'stu_1', title: 'September School Fee', amount: 2500, dueDate: '2026-09-10', status: 'pending' },
  { id: 'fee_2', studentId: 'stu_1', title: 'August School Fee', amount: 2500, dueDate: '2026-08-10', status: 'paid', receipt: 'SCH-2026-00821', paidOn: '2026-08-06' },
  { id: 'fee_3', studentId: 'stu_1', title: 'July School Fee', amount: 2500, dueDate: '2026-07-10', status: 'paid', receipt: 'SCH-2026-00644', paidOn: '2026-07-08' },
  { id: 'fee_4', studentId: 'stu_1', title: 'Transport Fee — Q2', amount: 3600, dueDate: '2026-10-05', status: 'pending' },
];

export const buildAttendance = (): AttendanceDay[] => {
  const days: AttendanceDay[] = [];
  const year = 2026, month = 8; // September (0-indexed)
  for (let d = 1; d <= 30; d++) {
    const date = new Date(year, month, d);
    const iso = date.toISOString().slice(0, 10);
    const dow = date.getDay();
    let mark: AttendanceDay['mark'] = 'present';
    if (dow === 0) mark = 'holiday';
    else if (d === 8 || d === 22) mark = 'absent';
    else if (d === 15) mark = 'leave';
    if (d > new Date().getDate() && month === new Date().getMonth()) mark = 'holiday';
    days.push({ date: iso, mark });
  }
  return days;
};

export const DEMO_HOMEWORK: Homework[] = [
  { id: 'hw_1', subject: 'English', title: 'Learn Pages 22–25', detail: 'Read aloud and practise the new sight words.', due: '2026-10-02', className: 'LKG' },
  { id: 'hw_2', subject: 'Mathematics', title: 'Complete Worksheet 5', detail: 'Numbers 1–20, tracing and counting.', due: '2026-10-03', className: 'LKG' },
  { id: 'hw_3', subject: 'EVS', title: 'Draw Five Fruits', detail: 'Colour and label five fruits you eat at home.', due: '2026-10-05', className: 'LKG', completed: true },
];

export const DEMO_EXAMS: ExamItem[] = [
  { id: 'ex_1', examName: 'Half Yearly Examination', subject: 'English', date: '2026-10-15', time: '10:00 AM', className: 'LKG' },
  { id: 'ex_2', examName: 'Half Yearly Examination', subject: 'Mathematics', date: '2026-10-17', time: '10:00 AM', className: 'LKG' },
  { id: 'ex_3', examName: 'Half Yearly Examination', subject: 'EVS', date: '2026-10-19', time: '10:00 AM', className: 'LKG' },
  { id: 'ex_4', examName: 'Half Yearly Examination', subject: 'Bengali', date: '2026-10-21', time: '10:00 AM', className: 'LKG' },
];

export const DEMO_NOTICES: Notice[] = [
  { id: 'nt_1', title: 'Durga Puja Holiday Notice', body: 'The school will remain closed from 8 October to 16 October for the Puja vacation. Classes resume on 17 October.', date: '2026-09-28', priority: 'IMPORTANT' },
  { id: 'nt_2', title: 'Annual Sports Day', body: 'Annual Sports Day is on 5 November. Parents are cordially invited. Reporting time 8:30 AM.', date: '2026-09-25', priority: 'INFO' },
  { id: 'nt_3', title: 'Parent–Teacher Meeting', body: 'PTM for LKG & UKG on 12 October, 11 AM–1 PM. Please carry the student diary.', date: '2026-09-20', priority: 'IMPORTANT' },
  { id: 'nt_4', title: 'Half Yearly Exam Routine Published', body: 'The Half Yearly examination routine is now available under Exam Routine.', date: '2026-09-18', priority: 'INFO' },
];

export const DEMO_LEAVE: LeaveRequest[] = [
  { id: 'lv_1', studentId: 'stu_1', parentUids: ['parent_001'], fromDate: '2026-10-02', toDate: '2026-10-02', reason: 'Family function', status: 'approved', createdAt: Date.now() - 86400000 * 2 },
];

export const DEMO_REPORT_CARD: ReportCardRow[] = [
  { subject: 'English', marks: 46, max: 50, grade: 'A', remark: 'Reads confidently.' },
  { subject: 'Mathematics', marks: 44, max: 50, grade: 'A', remark: 'Strong with numbers.' },
  { subject: 'EVS', marks: 42, max: 50, grade: 'A', remark: 'Curious and observant.' },
  { subject: 'Bengali', marks: 40, max: 50, grade: 'B+', remark: 'Improving steadily.' },
  { subject: 'Drawing', marks: 48, max: 50, grade: 'A+', remark: 'Very creative.' },
];

export const DEMO_ACTIVITIES = [
  { id: 'ac_1', title: 'Independence Day Celebration', category: 'Events', date: '2026-08-15', hue: '#3B82F6' },
  { id: 'ac_2', title: 'Clay Modelling Workshop', category: 'Art', date: '2026-09-05', hue: '#F59E0B' },
  { id: 'ac_3', title: 'Sports Practice', category: 'Sports', date: '2026-09-12', hue: '#22C55E' },
  { id: 'ac_4', title: 'Story Telling Day', category: 'Class Activities', date: '2026-09-19', hue: '#253B80' },
  { id: 'ac_5', title: 'Fancy Dress', category: 'Celebrations', date: '2026-09-24', hue: '#EF4444' },
  { id: 'ac_6', title: 'Rhymes Competition', category: 'Events', date: '2026-09-27', hue: '#3B82F6' },
];

export const seedNotifications = (toUid: string, schoolId: string): AppNotification[] => [
  { id: 'n1', toUid, schoolId, category: 'Academic', priority: 'INFO', title: 'New homework assigned', body: 'Mathematics — Complete Worksheet 5, due 03 October.', createdAt: Date.now() - 3600_000 * 3, read: false },
  { id: 'n2', toUid, schoolId, category: 'Notice', priority: 'IMPORTANT', title: 'Durga Puja Holiday Notice', body: 'School closed 8–16 October for Puja vacation.', createdAt: Date.now() - 3600_000 * 20, read: false },
  { id: 'n3', toUid, schoolId, category: 'Fee', priority: 'IMPORTANT', title: 'Fee reminder', body: 'September School Fee ₹2,500 is due on 10 September.', createdAt: Date.now() - 3600_000 * 26, read: true },
];

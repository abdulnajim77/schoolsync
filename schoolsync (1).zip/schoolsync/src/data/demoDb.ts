// ---------------------------------------------------------------------------
// Demo persistence layer — a thin localStorage store so the app behaves like a
// real backend (data survives refresh) with zero Firebase dependency.
// ---------------------------------------------------------------------------
import type { AppUser, LeaveRequest, Student } from '@/types';
import { DEMO_LEAVE, DEMO_STUDENTS } from './demoData';

export interface DemoAccount extends AppUser {
  password: string;
}

export const DEMO_ACCOUNTS: DemoAccount[] = [
  {
    uid: 'admin_001', schoolId: 'school_001', role: 'admin', name: 'School Office',
    email: 'admin@demo.com', phone: '+91 90000 12345', password: 'demo123',
  },
  {
    uid: 'parent_001', schoolId: 'school_001', role: 'parent', name: 'Mrs. Das',
    email: 'parent@demo.com', phone: '+91 98311 40012', password: 'demo123',
    childIds: ['stu_1', 'stu_6'],
  },
  {
    uid: 'driver_001', schoolId: 'school_001', role: 'driver', name: 'Sanjay Das',
    email: 'driver@demo.com', phone: '+91 98300 55512', password: 'demo123', busId: 'bus_03',
  },
  {
    uid: 'teacher_001', schoolId: 'school_001', role: 'teacher', name: 'Ms. Sarkar',
    email: 'teacher@demo.com', phone: '+91 98322 71100', password: 'demo123',
    classIds: ['LKG-A', 'UKG-A'],
  },
];

const KEY = {
  session: 'schoolsync.session',
  students: 'schoolsync.students',
  leave: 'schoolsync.leave',
} as const;

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage may be unavailable (private mode) — degrade gracefully */
  }
}

export const demoDb = {
  // session ----------------------------------------------------------------
  getSession: (): AppUser | null => read<AppUser | null>(KEY.session, null),
  setSession: (u: AppUser | null) =>
    u ? write(KEY.session, u) : localStorage.removeItem(KEY.session),

  // students ---------------------------------------------------------------
  getStudents: (): Student[] => read<Student[]>(KEY.students, DEMO_STUDENTS),
  setStudents: (s: Student[]) => write(KEY.students, s),
  updateStudent: (id: string, patch: Partial<Student>): Student[] => {
    const next = demoDb.getStudents().map((s) => (s.id === id ? { ...s, ...patch } : s));
    demoDb.setStudents(next);
    return next;
  },

  // leave ------------------------------------------------------------------
  getLeave: (): LeaveRequest[] => read<LeaveRequest[]>(KEY.leave, DEMO_LEAVE),
  setLeave: (l: LeaveRequest[]) => write(KEY.leave, l),
  addLeave: (req: LeaveRequest): LeaveRequest[] => {
    const next = [req, ...demoDb.getLeave()];
    demoDb.setLeave(next);
    return next;
  },
  setLeaveStatus: (id: string, status: LeaveRequest['status']): LeaveRequest[] => {
    const next = demoDb.getLeave().map((l) => (l.id === id ? { ...l, status } : l));
    demoDb.setLeave(next);
    return next;
  },

  reset: () => {
    localStorage.removeItem(KEY.students);
    localStorage.removeItem(KEY.leave);
  },
};

import type { ReactNode } from 'react';
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';

import { AuthProvider, homeForRole, useAuth } from '@/state/AuthContext';
import { NotificationProvider } from '@/state/NotificationContext';
import { TripProvider } from '@/state/TripContext';
import { ToastHost } from '@/components/layout/ToastHost';
import { RoleGuard } from '@/layouts/RoleGuard';

import { ParentLayout } from '@/layouts/ParentLayout';
import { AdminLayout } from '@/layouts/AdminLayout';
import { DriverLayout } from '@/layouts/DriverLayout';
import { TeacherLayout } from '@/layouts/TeacherLayout';

import { Login } from '@/pages/auth/Login';
import { ForgotPassword } from '@/pages/auth/ForgotPassword';

import { ParentDashboard } from '@/pages/parent/Dashboard';
import { LiveTracking } from '@/pages/parent/LiveTracking';
import { Fees } from '@/pages/parent/Fees';
import { Attendance } from '@/pages/parent/Attendance';
import { Homework } from '@/pages/parent/Homework';
import { ExamRoutine } from '@/pages/parent/ExamRoutine';
import { Notices } from '@/pages/parent/Notices';
import { Leave } from '@/pages/parent/Leave';
import { ReportCard } from '@/pages/parent/ReportCard';
import { Activities } from '@/pages/parent/Activities';
import { ParentSettings } from '@/pages/parent/Settings';

import { AdminDashboard } from '@/pages/admin/Dashboard';
import { AdminStudents } from '@/pages/admin/Students';
import { AdminParents } from '@/pages/admin/Parents';
import { AdminTeachers } from '@/pages/admin/Teachers';
import { AdminBuses } from '@/pages/admin/Buses';
import { AdminDrivers } from '@/pages/admin/Drivers';
import { AdminRoutes } from '@/pages/admin/Routes';
import { AdminLiveTracking } from '@/pages/admin/LiveTracking';
import { AdminAttendance } from '@/pages/admin/Attendance';
import { AdminFees } from '@/pages/admin/Fees';
import { AdminExams } from '@/pages/admin/Exams';
import { AdminHomework } from '@/pages/admin/Homework';
import { AdminNotices } from '@/pages/admin/Notices';
import { AdminLeave } from '@/pages/admin/Leave';
import { AdminReports } from '@/pages/admin/Reports';
import { AdminSettings } from '@/pages/admin/Settings';

import { DriverDashboard } from '@/pages/driver/Dashboard';
import { DriverRoute } from '@/pages/driver/Route';
import { DriverEmergency } from '@/pages/driver/Emergency';

import { TeacherDashboard } from '@/pages/teacher/Dashboard';
import { TeacherAttendance } from '@/pages/teacher/Attendance';

/**
 * Makes the live-trip simulation available to a role subtree. It reads the
 * signed-in user (guaranteed present because RoleGuard renders it) and scopes
 * the trip context to that viewer.
 */
function TripBoundary({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  if (!user) return <>{children}</>;
  return (
    <TripProvider viewerUid={user.uid} viewerRole={user.role}>
      {children}
    </TripProvider>
  );
}

/** Sends "/" and unknown paths to the right home, or to login. */
function RootRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  return <Navigate to={user ? homeForRole(user.role) : '/login'} replace />;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/forgot" element={<ForgotPassword />} />

      {/* Parent -------------------------------------------------------- */}
      <Route
        path="/parent"
        element={
          <RoleGuard role="parent">
            <TripBoundary>
              <ParentLayout />
            </TripBoundary>
          </RoleGuard>
        }
      >
        <Route index element={<ParentDashboard />} />
        <Route path="track" element={<LiveTracking />} />
        <Route path="fees" element={<Fees />} />
        <Route path="attendance" element={<Attendance />} />
        <Route path="homework" element={<Homework />} />
        <Route path="exams" element={<ExamRoutine />} />
        <Route path="notices" element={<Notices />} />
        <Route path="leave" element={<Leave />} />
        <Route path="report" element={<ReportCard />} />
        <Route path="activities" element={<Activities />} />
        <Route path="settings" element={<ParentSettings />} />
      </Route>

      {/* Admin --------------------------------------------------------- */}
      <Route
        path="/admin"
        element={
          <RoleGuard role="admin">
            <TripBoundary>
              <AdminLayout />
            </TripBoundary>
          </RoleGuard>
        }
      >
        <Route index element={<AdminDashboard />} />
        <Route path="students" element={<AdminStudents />} />
        <Route path="parents" element={<AdminParents />} />
        <Route path="teachers" element={<AdminTeachers />} />
        <Route path="buses" element={<AdminBuses />} />
        <Route path="drivers" element={<AdminDrivers />} />
        <Route path="routes" element={<AdminRoutes />} />
        <Route path="tracking" element={<AdminLiveTracking />} />
        <Route path="attendance" element={<AdminAttendance />} />
        <Route path="fees" element={<AdminFees />} />
        <Route path="exams" element={<AdminExams />} />
        <Route path="homework" element={<AdminHomework />} />
        <Route path="notices" element={<AdminNotices />} />
        <Route path="leave" element={<AdminLeave />} />
        <Route path="reports" element={<AdminReports />} />
        <Route path="settings" element={<AdminSettings />} />
      </Route>

      {/* Driver -------------------------------------------------------- */}
      <Route
        path="/driver"
        element={
          <RoleGuard role="driver">
            <TripBoundary>
              <DriverLayout />
            </TripBoundary>
          </RoleGuard>
        }
      >
        <Route index element={<DriverDashboard />} />
        <Route path="route" element={<DriverRoute />} />
        <Route path="emergency" element={<DriverEmergency />} />
      </Route>

      {/* Teacher ------------------------------------------------------- */}
      <Route
        path="/teacher"
        element={
          <RoleGuard role="teacher">
            <TeacherLayout />
          </RoleGuard>
        }
      >
        <Route index element={<TeacherDashboard />} />
        <Route path="attendance" element={<TeacherAttendance />} />
      </Route>

      <Route path="/" element={<RootRedirect />} />
      <Route path="*" element={<RootRedirect />} />
    </Routes>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AuthProvider>
        <NotificationProvider>
          <AppRoutes />
          <ToastHost />
        </NotificationProvider>
      </AuthProvider>
    </HashRouter>
  );
}

# SchoolSync

Live school-bus tracking, student pickup and drop safety, attendance, fees and academics — one portal for parents, drivers, teachers and the school office.

SchoolSync runs in two modes. **Demo mode** needs no accounts and no keys: it uses a built-in dataset and a simulated GPS bus so you can show the whole product on a laptop in minutes. **Production mode** connects to your own Firebase project and (optionally) Google Maps for real logins, real data and real live tracking.

---

## Table of contents

1. [What's inside](#whats-inside)
2. [Tech stack](#tech-stack)
3. [Before you start](#before-you-start)
4. [Download the project](#download-the-project)
5. [Install](#install)
6. [Run it locally](#run-it-locally)
7. [Build for production](#build-for-production)
8. [What the `dist` folder is](#what-the-dist-folder-is)
9. [Demo mode](#demo-mode)
10. [Demo logins](#demo-logins)
11. [Switching to production mode](#switching-to-production-mode)
12. [Environment variables](#environment-variables)
13. [Firebase setup, step by step](#firebase-setup-step-by-step)
14. [Google Maps setup](#google-maps-setup)
15. [Deploy to Firebase Hosting](#deploy-to-firebase-hosting)
16. [Deploy to Vercel](#deploy-to-vercel)
17. [Deploy to Netlify](#deploy-to-netlify)
18. [Custom domain](#custom-domain)
19. [Install as an app (PWA)](#install-as-an-app-pwa)
20. [Project structure](#project-structure)
21. [How the live tracking works](#how-the-live-tracking-works)
22. [Troubleshooting](#troubleshooting)
23. [What's fully wired vs scaffolded](#whats-fully-wired-vs-scaffolded)

---

## What's inside

Four roles, each with its own portal:

- **Parent** — home dashboard, live bus tracking with a safety timeline, fees, attendance, homework, exam routine, notices, report card, activity gallery, and a "skip the bus today" / leave request flow. Parents with more than one child can switch between them from the top bar.
- **Driver** — a mobile-first trip screen: start the morning or return trip, see who's expected at each stop, mark students boarded or dropped, and a one-tap emergency panel.
- **Teacher** — class overview and quick attendance marking.
- **Admin** — school-wide dashboard with charts, plus management for students, parents, teachers, buses, drivers, routes, live fleet tracking, attendance, fees, exams, homework, notices, leave approvals, reports and settings.

The safety flow is the point of the product: when the bus enters a pickup zone the parent is notified, again when the child is boarded, when the bus reaches school, and the same in reverse on the way home. Safety and emergency alerts always go through, regardless of a parent's notification preferences.

## Tech stack

- **React 18** + **TypeScript**
- **Vite 6** for dev server and builds
- **Tailwind CSS 3** for styling
- **React Router 6** for navigation
- **Firebase 11** (Auth, Firestore, Realtime Database, Cloud Messaging, Storage) — used only in production mode
- **lucide-react** for icons
- A PWA service worker for offline fallback and install

No CSS framework beyond Tailwind, no component library — the UI is hand-built and lives in `src/components/ui`.

## Before you start

You need **Node.js 18 or newer** (20 LTS is a safe choice) and npm, which comes with Node.

Check what you have:

```bash
node -v
npm -v
```

If `node -v` prints nothing or a version below 18, install it from <https://nodejs.org> (pick the LTS build). On Windows, the installer sets up npm too. On macOS you can also use Homebrew (`brew install node`), and on Ubuntu/Debian use `nvm` or the NodeSource packages.

## Download the project

If you were handed a zip, unzip it somewhere sensible and open a terminal in that folder — the one that contains `package.json`.

```bash
cd path/to/schoolsync
```

## Install

From the project folder:

```bash
npm install
```

This pulls the dependencies into `node_modules`. It takes a minute or two the first time and needs an internet connection. You only do this once (and again whenever dependencies change).

## Run it locally

```bash
npm run dev
```

Vite prints a local address, usually <http://localhost:5173>. Open it in your browser. The app starts in **demo mode**, so you can log in immediately with the demo accounts below — no setup required.

The dev server hot-reloads: save a file and the browser updates on its own.

## Build for production

```bash
npm run build
```

This type-checks the code and produces an optimised, minified bundle in a new `dist` folder. To preview that production build locally before you deploy:

```bash
npm run preview
```

## What the `dist` folder is

`dist` is the finished website — plain HTML, CSS and JavaScript, ready to host anywhere. Nothing in it needs Node to run; any static host will serve it. The deploy sections below all boil down to "put the contents of `dist` on a host". You don't edit files in `dist` by hand — you change the source and rebuild.

## Demo mode

Demo mode is the default and is what runs when no Firebase configuration is present. In this mode:

- Logins are checked against a small built-in list of accounts (see below).
- All data — students, buses, fees, attendance and so on — comes from a fixed dataset in `src/data/demoData.ts`. A few things you change (adding a student, requesting leave, paying a fee) are saved to your browser's local storage so they survive a refresh.
- The bus GPS is **simulated**: a fake bus drives along the demo route, crossing real geofence zones and firing the same notifications a real trip would.

This is the mode to use for sales demos and for exploring the product. To reset any demo changes, clear the site's local storage in your browser, or use the "Reset demo" control on the driver screen.

## Demo logins

The password for every demo account is `demo123`.

| Role    | Email             |
| ------- | ----------------- |
| Admin   | `admin@demo.com`  |
| Parent  | `parent@demo.com` |
| Driver  | `driver@demo.com` |
| Teacher | `teacher@demo.com`|

To see the live-tracking story end to end: log in as the **parent**, press **Play live demo** (or open Live Tracking and start the trip), and watch the bus approach the pickup stop and the safety timeline update. Or log in as the **driver**, start the morning trip, and board students as the bus reaches each stop — the parent side reacts to it.

## Switching to production mode

Production mode turns on automatically once you provide a Firebase configuration through environment variables. Concretely:

1. Copy the example env file:
   ```bash
   cp .env.example .env
   ```
2. Fill in your Firebase values (next sections explain where they come from).
3. Set the mode explicitly if you want to be sure:
   ```
   VITE_APP_MODE=production
   ```
4. Restart `npm run dev`, or rebuild for deployment.

If the Firebase values are missing, the app quietly falls back to demo mode, so a half-finished `.env` won't crash anything.

## Environment variables

All variables are read at build time and must start with `VITE_` (that's a Vite rule). Copy `.env.example` to `.env` and fill in what you need.

| Variable                             | Needed for                     | Notes                                             |
| ------------------------------------ | ------------------------------ | ------------------------------------------------- |
| `VITE_APP_MODE`                      | choosing the mode              | `demo` or `production`. Optional.                 |
| `VITE_FIREBASE_API_KEY`              | Firebase                       | From your Firebase web app config.                |
| `VITE_FIREBASE_AUTH_DOMAIN`          | Firebase                       |                                                   |
| `VITE_FIREBASE_PROJECT_ID`           | Firebase                       |                                                   |
| `VITE_FIREBASE_STORAGE_BUCKET`       | Firebase                       |                                                   |
| `VITE_FIREBASE_MESSAGING_SENDER_ID`  | Firebase                       |                                                   |
| `VITE_FIREBASE_APP_ID`               | Firebase                       |                                                   |
| `VITE_FIREBASE_DATABASE_URL`         | live tracking                  | Realtime Database URL.                            |
| `VITE_GOOGLE_MAPS_API_KEY`           | real map tiles                 | Optional. Without it, a built-in SVG map is used. |
| `VITE_FIREBASE_VAPID_KEY`                 | push notifications             | Optional. From Cloud Messaging settings.          |

Never commit your real `.env` — it's already listed in `.gitignore`. The keys above are safe to expose in a browser bundle (that's normal for Firebase web apps); your data is protected by the security rules, not by hiding the config.

## Firebase setup, step by step

You need a free Google account. This walk-through gets you from nothing to a working production backend.

**1. Create a project**

- Go to <https://console.firebase.google.com> and click **Add project**.
- Name it (for example `schoolsync-live`), accept the defaults, and finish.

**2. Register a web app**

- In the project, click the **</>** (web) icon to add a web app.
- Give it a nickname. You don't need Firebase Hosting yet — you can add it later.
- Firebase shows you a `firebaseConfig` object. Copy those values into the matching `VITE_FIREBASE_*` variables in your `.env`.

**3. Turn on Authentication**

- Open **Build → Authentication → Get started**.
- Enable **Email/Password**.
- Add your first users under the **Users** tab, or build a sign-up flow later. Each user's role (admin, parent, driver, teacher) is stored in Firestore against their UID.

**4. Create Firestore**

- Open **Build → Firestore Database → Create database**.
- Start in production mode and pick a region close to you (for India, `asia-south1` — Mumbai).
- Deploy the security rules and indexes included in this project (see below).

**5. Create the Realtime Database**

- Open **Build → Realtime Database → Create database**, same region.
- This holds the live bus location during a trip — it's built for many small, fast updates, which suits GPS pings.
- Copy its URL into `VITE_FIREBASE_DATABASE_URL`.
- Deploy the RTDB rules included here.

**6. Cloud Messaging (optional, for push)**

- Open **Project settings → Cloud Messaging**.
- Under Web configuration, generate a **Web Push certificate** (VAPID key) and put it in `VITE_FIREBASE_VAPID_KEY`.

**7. Storage (optional, for photos and documents)**

- Open **Build → Storage → Get started** if you want to store student photos, notices or attachments.

**8. Deploy the rules and indexes**

The `firebase/` folder holds `firestore.rules`, `database.rules.json` and `firestore.indexes.json`, all scoped so a school only ever sees its own data. Install the CLI and push them:

```bash
npm install -g firebase-tools
firebase login
cp .firebaserc.example .firebaserc      # then edit it to use your project id
firebase deploy --only firestore:rules,firestore:indexes,database
```

## Google Maps setup

The live map works without Google — the app falls back to a clean built-in SVG map that's fine for demos. For real street tiles:

- In the [Google Cloud Console](https://console.cloud.google.com), create (or reuse) a project and enable the **Maps JavaScript API**.
- Create an API key, and restrict it: limit it to your domain(s) under **HTTP referrers**, and to the Maps JavaScript API under **API restrictions**. This stops other sites using your key.
- Put the key in `VITE_GOOGLE_MAPS_API_KEY` and rebuild.

## Deploy to Firebase Hosting

```bash
npm run build
firebase deploy --only hosting
```

`firebase.json` is already set up to serve the `dist` folder and to route every path back to `index.html` (needed for a single-page app). The first `firebase deploy` will prompt you to pick the Hosting site if you haven't set one up.

## Deploy to Vercel

- Push the project to a Git repo (GitHub, GitLab or Bitbucket) and import it at <https://vercel.com>, **or** use the CLI:
  ```bash
  npm install -g vercel
  vercel
  ```
- Build command: `npm run build`. Output directory: `dist`.
- Add your `VITE_*` environment variables in the Vercel project settings before building.
- `vercel.json` already rewrites all routes to `index.html`.

## Deploy to Netlify

- Import the repo at <https://netlify.com>, **or** drag the `dist` folder onto the Netlify dashboard for a one-off deploy.
- Build command: `npm run build`. Publish directory: `dist`.
- Add your `VITE_*` variables under **Site settings → Environment variables**.
- `netlify.toml` already handles the single-page-app redirect.

## Custom domain

Each host has a **Domains** (or **Custom domain**) section. Add your domain there, then create the DNS records they give you at your registrar — usually a `CNAME` for `www` and either an `A` record or the host's nameservers for the root. HTTPS certificates are issued automatically once DNS resolves, which can take anywhere from a few minutes to a few hours.

## Install as an app (PWA)

SchoolSync ships a web manifest and a service worker, so parents can install it to their home screen. On Android/Chrome they'll see an **Install app** prompt; on iPhone/Safari they use **Share → Add to Home Screen**. Once installed it opens full-screen like a native app, and shows a friendly offline page if the network drops. Note that the service worker only registers in a production build, not during `npm run dev`.

## Project structure

```
schoolsync/
├─ public/            # static assets, icons, manifest, service worker, offline page
├─ firebase/          # Firestore + RTDB security rules and indexes
├─ src/
│  ├─ components/
│  │  ├─ ui/          # buttons, cards, inputs, modals — the design system
│  │  ├─ layout/      # notification bell, toast host
│  │  ├─ transport/   # live map, route timelines, bus status card
│  │  └─ admin/       # shared admin data table
│  ├─ config/         # env reading + Firebase init (production only)
│  ├─ data/           # demo dataset and the local-storage demo store
│  ├─ layouts/        # per-role shells (parent, admin, driver, teacher) + route guard
│  ├─ lib/            # helpers: formatting, geo/geofencing maths, ids
│  ├─ pages/          # every screen, grouped by role
│  ├─ services/       # auth service (demo vs Firebase)
│  ├─ state/          # React context: auth, notifications, live trip, parent/child
│  ├─ types/          # shared TypeScript types
│  ├─ App.tsx         # router and providers
│  └─ main.tsx        # entry point
├─ .env.example
└─ package.json
```

## How the live tracking works

The geofencing logic lives in `src/lib/geo.ts` and the trip engine in `src/state/TripContext.tsx`. In demo mode the engine moves the bus along the route a step at a time, works out its distance to each zone (pickup, drop, school), and runs a small state machine so a parent gets one "bus approaching" alert rather than a dozen as the bus jitters around the edge of a zone. When the bus enters a stop's zone the matching students are auto-boarded a moment later, which mirrors what a driver tap would do in production. Swapping the simulated position for real GPS writes from the driver's device is the main change needed to go live — the notification and safety logic stays the same.

## Troubleshooting

**`npm install` fails.** Check your Node version is 18+ (`node -v`) and that you have internet access. If it's stuck on a half-download, delete `node_modules` and `package-lock.json` and run it again.

**Port 5173 is already in use.** Another Vite app is probably running. Stop it, or run `npm run dev -- --port 5174`.

**The app loads but stays in demo mode after I added Firebase keys.** Restart the dev server — env changes are only read on start. Make sure every variable starts with `VITE_` and that there are no quotes or trailing spaces in `.env`. Setting `VITE_APP_MODE=production` makes the intent explicit.

**Blank page after deploying.** This is almost always the single-page-app redirect. The included `firebase.json` / `vercel.json` / `netlify.toml` handle it — make sure you deployed with them and that your publish directory is `dist`.

**The map is a simple line drawing, not Google Maps.** That's the built-in fallback and it means no valid `VITE_GOOGLE_MAPS_API_KEY` was found. Add the key (and enable the Maps JavaScript API) to get street tiles.

**Login fails in production.** The user must exist in Firebase Authentication *and* have a matching profile document with a role in Firestore. A user with no role record can authenticate but has nowhere to land.

**Notifications don't appear on the deployed site.** Web push needs HTTPS (all three hosts give you that), a VAPID key, and the visitor granting permission when the browser asks.

## What's fully wired vs scaffolded

Being straight about this so there are no surprises:

**Fully working in demo mode, end to end:**

- Login and role-based routing for all four roles
- Parent live tracking: simulated GPS, geofencing, the safety timeline, and the notification flow
- Driver trip control: start/return/end, boarding and dropping students, emergency alerts
- Admin dashboard with charts, and the students screen (search, filter, add/edit) and leave approvals, both of which persist to local storage

**Built as clean, real screens on live demo data, ready to wire to Firestore:**

- The remaining admin management pages (parents, teachers, buses, drivers, routes, attendance, fees, exams, homework, notices, reports, settings)
- The academic parent pages (fees payment, attendance calendar, homework, exams, report card, activities)

Every route in the app resolves to a real screen — nothing is a dead link. The production data layer (reading and writing these screens to Firestore) is the natural next step, and the types and service structure are already in place for it.

---

Built by VK Creatives. Questions or changes — reach us at contact@vkcreativesagency.com.

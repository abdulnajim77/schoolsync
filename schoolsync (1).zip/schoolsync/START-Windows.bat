@echo off
cd /d "%~dp0"
echo ========================================
echo   SchoolSync - starting local server
echo ========================================
echo.

where npm >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed on this computer.
  echo Please install it from https://nodejs.org  ^(pick the LTS version^),
  echo then double-click this file again.
  echo.
  pause
  exit /b
)

if not exist node_modules (
  echo First-time setup: installing dependencies. This takes a minute...
  echo.
  call npm install
)

echo.
echo Opening http://localhost:5173 in your browser...
start "" http://localhost:5173
echo.
echo Keep this window OPEN while you use the app.
echo To stop the app later, close this window or press Ctrl + C.
echo.
call npm run dev
pause
